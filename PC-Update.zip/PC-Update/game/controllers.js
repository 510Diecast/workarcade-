'use strict';
const controllerDefaults={interact:2,melee:11,reload:2,switch:3,aim:6,shoot:7,sprint:10,jump:0,crouch:1,tactical:4,grenade:5,pause:9,flashlight:12};
let controllerPrefs={layoutVersion:2,layout:'cod',deadzone:.16,sensitivity:1.8,invert:false,rightY:3,bindings:{...controllerDefaults}},controllerCurrent=null,controllerLastId='',controllerPrevious={},controllerCalibration=null,controllerWasPresent=false,controllerIgnoreUntilRelease=false;
try{let prefs=JSON.parse(localStorage.getItem('dead-frequency-controller')||'null');if(prefs)controllerPrefs={...controllerPrefs,...prefs,layoutVersion:2,bindings:prefs.layoutVersion===2?{...controllerDefaults,...prefs.bindings}:{...controllerDefaults}}}catch(e){}
saveControllerPrefs();
function saveControllerPrefs(){try{localStorage.setItem('dead-frequency-controller',JSON.stringify(controllerPrefs))}catch(e){}}
function controllerFamily(gp){return /sony|playstation|dualshock|dualsense|054c|wireless controller/i.test(gp.id)?'PlayStation':/8bitdo/i.test(gp.id)?'8BitDo':'Xbox'}
function controllerLabel(action){const ps=controllerCurrent&&controllerFamily(controllerCurrent)==='PlayStation';return (ps?{interact:'□',melee:'R3',reload:'□',switch:'△',aim:'L2',shoot:'R2',sprint:'L3',jump:'✕',crouch:'○',tactical:'L1',grenade:'R1',pause:'Options',flashlight:'D-pad ↑'}:{interact:'X',melee:'RS',reload:'X',switch:'Y',aim:'LT',shoot:'RT',sprint:'LS',jump:'A',crouch:'B',tactical:'LB',grenade:'RB',pause:'Menu',flashlight:'D-pad ↑'})[action]}
function sampleController(){let list=[];try{list=Array.from(navigator.getGamepads?.()||[]).filter(g=>g&&g.connected)}catch(e){}return list.find(g=>g.id===controllerLastId)||list[0]||null}
function controllerAxis(v){let dz=controllerPrefs.deadzone;return Math.abs(v)<=dz?0:Math.sign(v)*(Math.abs(v)-dz)/(1-dz)}
function controllerAction(g,action){const n=controllerPrefs.bindings[action];return Number.isInteger(n)&&n>=0&&(g.buttons[n]?.pressed||g.buttons[n]?.value>.5)||false}
function pollController(){const gp=sampleController();controllerCurrent=gp;if(!gp){if(controllerWasPresent){controllerWasPresent=false;controllerPrevious={};if(mode==='playing'){pause();tell('Controller disconnected — reconnect or use keyboard and mouse')}}const status=document.getElementById('controller-status');if(status)status.textContent='No controller detected · Connect it, then press any button';return null}
const newDevice=gp.id!==controllerLastId||!controllerWasPresent;controllerLastId=gp.id;controllerWasPresent=true;const family=controllerFamily(gp),status=document.getElementById('controller-status');if(status)status.textContent=`${family} connected · ${gp.mapping==='standard'?'standard layout':'use button setup if controls differ'}`;
const help=document.getElementById('controller-help');if(help)help.textContent=`Controller: left stick move · right stick aim · ${controllerLabel('shoot')} shoot · ${controllerLabel('aim')} aim · ${controllerLabel('reload')} tap reload / hold interact · ${controllerLabel('melee')} melee · ${controllerLabel('switch')} switch · ${controllerLabel('sprint')} sprint · ${controllerLabel('jump')} jump · ${controllerLabel('crouch')} crouch / hold prone · ${controllerLabel('grenade')} frag · ${controllerLabel('tactical')} tactical · ${controllerLabel('pause')} pause / resume`;
const now={};for(const action of Object.keys(controllerDefaults))now[action]=controllerAction(gp,action);const pressed={};for(const action of Object.keys(now))pressed[action]=now[action]&&!controllerPrevious[action];controllerPrevious=now;
if(controllerIgnoreUntilRelease){if(gp.buttons.some(b=>b.pressed||b.value>.6))return null;controllerIgnoreUntilRelease=false;controllerPrevious={};return null}if(controllerCalibration){calibrateController(gp);return null}
if(newDevice&&mode==='playing')tell(`${family} controller connected`);
return {gp,held:now,pressed,x:controllerAxis(gp.axes[0]||0),y:-controllerAxis(gp.axes[1]||0),lookX:controllerAxis(gp.axes[2]||0),lookY:-controllerAxis(gp.axes[controllerPrefs.rightY]||0)*(controllerPrefs.invert?-1:1)}}
function calibrateController(gp){const c=controllerCalibration,active=gp.buttons.findIndex(b=>b.pressed||b.value>.6);if(c.release){if(active<0)c.release=false;return}if(active<0)return;c.bindings[c.steps[c.index]]=active;c.index++;c.release=true;if(c.index>=c.steps.length){controllerPrefs.bindings=c.bindings;saveControllerPrefs();controllerCalibration=null;controllerIgnoreUntilRelease=true;document.getElementById('controller-calibration').textContent='Buttons saved. Press Enter the Factory / Resume to play.';return}document.getElementById('controller-calibration').textContent=`Press the button for: ${c.steps[c.index].toUpperCase()} (${c.index+1}/${c.steps.length})`}
function setupControllers(){const el=id=>document.getElementById(id);el('controller-deadzone').value=controllerPrefs.deadzone;el('controller-speed').value=controllerPrefs.sensitivity;el('controller-invert').checked=controllerPrefs.invert;el('controller-axis').value=controllerPrefs.rightY;
for(const [id,key,isBool] of [['controller-deadzone','deadzone'],['controller-speed','sensitivity'],['controller-axis','rightY'],['controller-invert','invert',true]])el(id).onchange=()=>{controllerPrefs[key]=isBool?el(id).checked:Number(el(id).value);saveControllerPrefs()};
el('controller-setup').onclick=()=>{if(mode==='playing')pause();if(!sampleController()){el('controller-calibration').textContent='Connect a controller and press any button first.';return}controllerCalibration={steps:['shoot','aim','reload','interact','melee','switch','sprint','jump','crouch','tactical','grenade','pause','flashlight'],index:0,release:true,bindings:{}};el('controller-calibration').textContent='Release all buttons, then press the button for SHOOT (1/13)'};
el('controller-reset').onclick=()=>{controllerCalibration=null;controllerPrefs.bindings={...controllerDefaults};saveControllerPrefs();el('controller-calibration').textContent='Call of Duty Default layout restored.'};}

// Standard menu buttons are independent of remapped combat actions.
let menuSelection=null,menuPrevious={},menuRepeat=0,menuDirection='',menuWasOpen=false;
function menuControls(){return Array.from(document.querySelectorAll(ui.dialog?'#dialog-screen button':'#overlay button,#overlay select,#overlay input,#overlay summary')).filter(el=>{if(el.disabled||el.hidden)return false;let details=el.closest('details');return (!details||details.open||el.tagName==='SUMMARY')&&el.getClientRects().length>0})}
function menuHighlight(el){if(menuSelection)menuSelection.classList.remove('controller-focus');menuSelection=el;if(el){el.classList.add('controller-focus');el.focus({preventScroll:true});el.scrollIntoView({block:'nearest',behavior:'smooth'})}}
function menuChange(el,direction){if(!el)return;if(el.tagName==='SELECT'){let i=el.selectedIndex,n=el.options.length;el.selectedIndex=(i+direction+n)%n;}else if(el.type==='range'){let step=Number(el.step)||1;el.value=Math.max(Number(el.min),Math.min(Number(el.max),Number(el.value)+direction*step));}else if(el.type==='checkbox')el.checked=!el.checked;else if(el.tagName==='SUMMARY'){el.parentElement.open=direction>0;return}else return;el.dispatchEvent(new Event('change',{bubbles:true}))}
function menuNavigate(direction){
 let controls=menuControls();if(!controls.length)return;let current=controls.includes(menuSelection)?menuSelection:controls.find(el=>el.id===uiDefaultControl())||controls[0];
 if(current!==menuSelection)menuHighlight(current);
 if((direction==='left'||direction==='right')&&(current.tagName==='SELECT'||['range','checkbox'].includes(current.type)||current.tagName==='SUMMARY')){menuChange(current,direction==='right'?1:-1);return}
 let candidates=[];
 if(current.getBoundingClientRect){let r=current.getBoundingClientRect(),cx=(r.left+r.right)/2,cy=(r.top+r.bottom)/2;
  for(let el of controls){if(el===current||!el.getBoundingClientRect)continue;let b=el.getBoundingClientRect(),dx=(b.left+b.right)/2-cx,dy=(b.top+b.bottom)/2-cy,horizontal=direction==='left'||direction==='right',primary=horizontal?(direction==='right'?dx:-dx):(direction==='down'?dy:-dy),cross=horizontal?Math.abs(dy):Math.abs(dx);
   if(primary<1)continue;if(horizontal&&cross>Math.max(r.height,b.height)*.60+12)continue;
   let overlap=horizontal?Math.min(r.bottom,b.bottom)-Math.max(r.top,b.top):Math.min(r.right,b.right)-Math.max(r.left,b.left);
   candidates.push({el,score:primary+cross*(overlap>0?.35:2.8)});
  }
 }
 if(candidates.length)menuHighlight(candidates.sort((a,b)=>a.score-b.score)[0].el);
 else if(direction==='up'||direction==='down'){let i=controls.indexOf(current);menuHighlight(controls[(i+(direction==='down'?1:-1)+controls.length)%controls.length])}
}

function updateControllerMenu(ci,dt){
 if(!ci){menuWasOpen=false;menuPrevious={};return false}let gp=ci.gp,down=n=>!!(gp.buttons[n]?.pressed||gp.buttons[n]?.value>.5),state={up:down(12)||(gp.axes[1]||0)<-.55,down:down(13)||(gp.axes[1]||0)>.55,left:down(14)||(gp.axes[0]||0)<-.55,right:down(15)||(gp.axes[0]||0)>.55,accept:down(0),back:down(1),pause:down(9)},edge=k=>state[k]&&!menuPrevious[k];
 if(mode==='playing'){menuWasOpen=false;menuPrevious=state;return false}let before=mode;if(typeof document.querySelectorAll!=='function'){if(edge('back')||edge('pause'))uiBack(true);menuPrevious=state;return mode!==before}
 let controls=menuControls();if(!menuWasOpen||!controls.includes(menuSelection))menuHighlight(controls.find(e=>e.id===uiDefaultControl())||controls[0]);menuWasOpen=true;let dir=['up','down','left','right'].find(k=>state[k])||'';menuRepeat-=dt;
 if(dir&&(dir!==menuDirection||menuRepeat<=0)){menuRepeat=dir===menuDirection?.14:.38;menuNavigate(dir);menuTone()}menuDirection=dir;
 if(edge('accept')){let el=menuSelection;if(el?.tagName==='BUTTON'){if(!activateMenu(el.id,true))el.click()}else if(el?.tagName==='SUMMARY')el.parentElement.open=!el.parentElement.open;else menuChange(el,1)}
 if(edge('back')||edge('pause')){let details=menuSelection?.closest('details');if(details?.open&&edge('back')){details.open=false;menuHighlight(details.querySelector('summary'))}else uiBack(true)}menuPrevious=state;
 let changed=mode!==before;if(changed){menuHighlight(null);menuWasOpen=false;fire=mouseFire=false;aim=mouseAim=false;keys={}}return changed;
}
