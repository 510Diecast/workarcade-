'use strict';
const GAME_VERSION='5.3';
const $=id=>document.getElementById(id),cv=$('view'),ctx=cv.getContext('2d',{alpha:true}),mini=$('mini').getContext('2d');
let fovDegrees=92;try{let fovStored=Number(localStorage.getItem('dead-regiment-fov'));if(Number.isFinite(fovStored)&&fovStored>=70&&fovStored<=110)fovDegrees=fovStored}catch{}
let flashlightOn=true;
function toggleFlashlight(){flashlightOn=!flashlightOn;tell(flashlightOn?'FLASHLIGHT ON':'FLASHLIGHT OFF')}
let adsBlend=0,radarPulseUntil=0,radarLastAlert=-100;
let weaponShotTime=-100,weaponMuzzleScreen=null;
let meleePendingHit=false;
let W=720,H=450,last=0,time=0,mode='menu',locked=false,aim=false,fire=false,keys={},ac,noiseBuffer,flash=0,hurt=0,hitmark=0,bannerTime=0,toastTime=0,nextRound=0,spawnClock=0,remaining=0,killCount=0,round=0,points=500,power=false,boost=false,reloading=0,shotClock=0,attackClock=0,repairClock=0,high=0,gamepadPrev=[],world=[],zombies=[],drops=[],particles=[],flow=[],pathClock=0;
try{high=Number(localStorage.getItem('dead-frequency-best'))||0}catch(e){}
// Three production wings connect to the starting courtyard through purchased gates.
const legacyTemplate=(()=>{let m=Array.from({length:28},()=>Array(32).fill(1));
function room(x0,y0,x1,y1){for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)m[y][x]=0}
room(10,15,21,26);room(1,12,8,25);room(23,12,30,25);room(7,1,24,8);room(7,18,9,20);room(22,18,24,20);room(15,9,16,14);room(5,8,9,8);room(5,9,5,11);room(22,8,27,8);room(27,9,27,11);m[10][5]=2;m[10][27]=2;
for(let y=18;y<=20;y++){m[y][9]=y===19?2:1;m[y][22]=y===19?2:1;}m[11][15]=2;m[11][16]=2;
for(let [x,y] of [[6,22],[27,15],[18,7],[19,7],[12,21],[19,21]])m[y][x]=1;
return m.map(r=>r.join(''))})();
// Insert floor space inside rooms; retain human-scale fixtures and door apertures.
const mapExpansion={x:[[4,4],[17,6],[26,4]],y:[[4,4],[10,2],[16,4],[21,6]]};
function expandAxis(v,axis){return v+mapExpansion[axis].reduce((n,[at,amount])=>n+(v>=at?amount:0),0)}
function originalAxis(v,axis){let offset=0;for(const [at,amount] of mapExpansion[axis]){if(v<at+offset)return v-offset;if(v<at+offset+amount)return at-.001;offset+=amount}return v-offset}
function expandPoint(o){o.x=expandAxis(o.x,'x');o.y=expandAxis(o.y,'y')}
let template=(()=>{let rows=[];for(let y=0;y<legacyTemplate.length;y++){let row=[];for(let x=0;x<legacyTemplate[y].length;x++){let extra=mapExpansion.x.find(e=>e[0]===x)?.[1]||0;for(let i=0;i<extra;i++)row.push(legacyTemplate[y][x-1]);row.push(legacyTemplate[y][x])}let extra=mapExpansion.y.find(e=>e[0]===y)?.[1]||0;for(let i=0;i<extra;i++)rows.push(rows[rows.length-1]);rows.push(row.join(''))}return applyDistrictGrid(rows)})();
let controllerFrame=null,mouseFire=false,mouseAim=false;
let stance=0,stanceEye=.82,controllerSprint=false,useHoldTime=0,useHoldConsumed=false,crouchHoldTime=0,proneConsumed=false,fragCount=4,tacticalCount=2,grenades=[],blasts=[];
let jumpHeight=0,jumpVelocity=0,jumpCooldown=0,stamina=6,sprintBlend=0,sprintExhausted=false,staminaRecoveryDelay=0,landingKick=0,motionPhase=0,playerMoving=false;
let hitRegion='',hitRegionTime=0;
let linked=[false,false,false],linking=-1,linkTime=0,teleCooldown=0,fastReload=false,doubleTap=false,trapTime=0,trapCooldown=0,boxTime=0,boxOffer=null,boxLife=0,boxSpins=0,boxIndex=0,dogRound=false,lightning=0,actionCooldown=0;
const trapZone={x0:15,x1:17,y0:14.75,y1:15.25};
function inTrap(x,y){return x>trapZone.x0&&x<trapZone.x1&&y>trapZone.y0&&y<trapZone.y1}
function crossesTrap(x,y,tx,ty){let lo=0,hi=1;for(let [a,b,min,max] of [[x,tx,trapZone.x0,trapZone.x1],[y,ty,trapZone.y0,trapZone.y1]]){let d=b-a;if(Math.abs(d)<1e-8){if(a<=min||a>=max)return false;continue}let t0=(min-a)/d,t1=(max-a)/d;if(t0>t1)[t0,t1]=[t1,t0];lo=Math.max(lo,t0);hi=Math.min(hi,t1);if(lo>hi)return false}return hi>=0&&lo<=1}
const base={x:15.5,y:24.5};
const gates=[{x:9.5,y:19.5,type:'gate',label:'OPEN WEST BARRACKS',cost:750,cells:[[9,19]]},{x:22.5,y:19.5,type:'gate',label:'OPEN BIORESEARCH WING',cost:750,cells:[[22,19]]},{x:15.5,y:11.5,type:'gate',label:'OPEN REACTOR BLOCK',cost:1250,cells:[[15,11],[16,11]]}];
gates.push({x:5.5,y:10.5,type:'gate',label:'OPEN BARRACKS SERVICE TUNNEL',cost:1000,cells:[[5,10]]},{x:27.5,y:10.5,type:'gate',label:'OPEN RESEARCH SERVICE TUNNEL',cost:1000,cells:[[27,10]]});
const boxLocations=[{x:5.5,y:18.5},{x:27.5,y:18.5},{x:20.5,y:4.5}];
const guns={arc:{name:'ARC PROJECTOR',cap:3,max:24,damage:340,rate:.8,reload:2.6,range:18,color:'#68b9be'},pistol:{name:'SERVICE PISTOL',cap:8,max:80,damage:42,rate:.29,reload:1.3,range:16,color:'#87897d'},smg:{name:'TRENCH SMG',cap:30,max:180,damage:34,rate:.085,reload:1.65,range:16,color:'#a1a092'},shotgun:{name:'PUMP SHOTGUN',cap:6,max:48,damage:170,rate:.8,reload:2,range:9,color:'#aa8660'},lmg:{name:'BUNKER LMG',cap:60,max:300,damage:65,rate:.12,reload:2.7,range:20,color:'#7f9581'}};
Object.assign(guns,{
rifle:{name:'WARDEN SERVICE RIFLE',cap:30,max:210,damage:55,rate:.12,reload:2.1,range:22,color:'#8b9e91',shape:'rifle',weight:18},
carbine:{name:'GUARD SEMI-AUTO CARBINE',cap:15,max:150,damage:110,rate:.32,reload:1.8,range:25,color:'#b29a74',shape:'rifle',weight:16},
revolver:{name:'WARDEN MAGNUM',cap:6,max:72,damage:155,rate:.48,reload:2.5,range:18,color:'#c1b8a0',shape:'revolver',weight:14},
autosg:{name:'BREACHER AUTO SHOTGUN',cap:10,max:80,damage:200,rate:.3,reload:2.8,range:12,color:'#919d88',shape:'shotgun',pellets:true,weight:12},
sniper:{name:'LONGWATCH BOLT RIFLE',cap:5,max:60,damage:310,rate:1.05,reload:2.7,range:32,color:'#a49a82',shape:'sniper',pierce:3,weight:10},
heavy:{name:'SENTINEL HEAVY MACHINE GUN',cap:100,max:400,damage:70,rate:.105,reload:4,range:24,color:'#a6a795',shape:'heavy',weight:8}
});
Object.assign(guns,{
doublebarrel:{name:'BREACH DOUBLE BARREL',cap:2,max:40,damage:245,rate:.38,reload:2.3,range:8,color:'#b29369',shape:'doublebarrel',pellets:true,weight:13},
compact:{name:'VIPER COMPACT SMG',cap:24,max:192,damage:29,rate:.065,reload:1.45,range:14,color:'#778f89',shape:'compact',weight:17},
marksman:{name:'WATCHMAN MARKSMAN RIFLE',cap:10,max:100,damage:150,rate:.42,reload:2.3,range:30,color:'#9eae95',shape:'marksman',pierce:2,weight:12},
silenced:{name:'SHADE SUPPRESSED PISTOL',cap:12,max:120,damage:60,rate:.23,reload:1.35,range:18,color:'#77867e',shape:'silenced',weight:15},
drumrifle:{name:'RAIDER DRUM RIFLE',cap:50,max:250,damage:48,rate:.1,reload:2.85,range:21,color:'#a38d69',shape:'drumrifle',weight:14}
});
Object.assign(guns,{
 scout:{name:'RAVEN SCOUT SNIPER',cap:7,max:84,damage:235,rate:.82,reload:2.45,range:40,color:'#9ba2a5',shape:'sniper',scope:3.5,pierce:2,weight:13,semi:true,barrel:.43},
 interceptor:{name:'INTERCEPTOR SEMI-AUTO SNIPER',cap:10,max:80,damage:210,rate:.49,reload:2.8,range:42,color:'#868d92',shape:'sniper',scope:4,pierce:2,weight:9,semi:true,barrel:.49}
});guns.sniper.scope=5;guns.marksman.scope=2.75;
Object.assign(guns,districtWeapons);
guns.signal={name:'SIGNAL DISRUPTOR',cap:6,max:48,damage:180,rate:.72,reload:2.65,range:24,color:'#75cddc',shape:'signal',weight:3};
weaponMotionProfiles.signal={reload:'cell',kick:22,roll:-.025,drop:27,tilt:-.31};
const boxPool=['smg','shotgun','lmg','rifle','carbine','revolver','autosg','sniper','heavy','arc','doublebarrel','compact','marksman','silenced','drumrifle'];
boxPool.push('scout','interceptor',...Object.keys(districtWeapons),'signal');
let burstRemaining=0,burstTimer=0,burstType=null,semiLatch=false;
let boxPending=null,boxPreview=null,boxShuffle=0,boxLast=null;
function rollBox(random=Math.random){let pool=boxPool.filter(type=>!inventory.some(w=>w.type===type)&&type!==boxLast);if(!pool.length)pool=boxPool;let weights=pool.map(type=>guns[type].weight||(type==='arc'?4:14)),r=random()*weights.reduce((a,b)=>a+b,0);for(let i=0;i<pool.length;i++){r-=weights[i];if(r<0)return pool[i]}return pool[pool.length-1]}
function shuffleBox(){let pool=boxPool.filter(type=>type!==boxPreview);boxPreview=pool[Math.floor(Math.random()*pool.length)]}
let player={x:22,y:41,level:0,cameraBase:0,a:-Math.PI/2,pitch:0,hp:100,maxhp:100,lastHit:0},inventory=[],slot=0;
const stations=[
{x:11.5,y:25.5,type:'smg',label:'TRENCH SMG',cost:700},
{x:7.5,y:13.5,type:'shotgun',label:'PUMP SHOTGUN',cost:1000},
{x:29.5,y:13.5,type:'lmg',label:'GARRISON LMG',cost:2200},
{x:15.5,y:3.5,type:'power',label:'RESTORE BASE POWER',cost:0},
{x:2.5,y:20.5,type:'health',label:'IRON HEART • 200 HEALTH',cost:2500},
{x:29.5,y:20.5,type:'speed',label:'QUICK HANDS • FAST RELOAD',cost:2000},
{x:10.5,y:7.5,type:'double',label:'RAPID FIRE • FASTER SHOOTING',cost:2000},
{x:18.5,y:25.5,type:'upgrade',label:'FORGE-A-PUNCH • UPGRADE HELD WEAPON',cost:5000},
{x:20.5,y:17.5,type:'ammo',label:'AMMUNITION CACHE',cost:350},
{x:5.5,y:18.5,type:'box',label:'MYSTERY CRATE',cost:950},
{x:15.5,y:24.5,type:'base',label:'COMMAND RELAY • CONFIRM TELEPORTER LINK',cost:0},
{x:3.5,y:13.5,type:'tele',id:0,label:'TELEPORTER A',cost:0},
{x:28.5,y:13.5,type:'tele',id:1,label:'TELEPORTER B',cost:0},
{x:20.5,y:2.5,type:'tele',id:2,label:'TELEPORTER C',cost:0},
{x:14.5,y:15.5,wallDX:0,wallDY:-1,rotation:0,mounted:true,type:'trap',label:'ELECTRIC TRAP • 15 SECONDS',cost:750}];
const fuseStations=[{x:2.5,y:22.5,type:'fuse',id:0,label:'SALVAGE BANK FUSE',cost:0},{x:29.5,y:22.5,type:'fuse',id:1,label:'SALVAGE GARAGE FUSE',cost:0},{x:21.5,y:5.5,type:'fuse',id:2,label:'SALVAGE GENERATOR FUSE',cost:0}];stations.push(...fuseStations);
const windows=[{x:10.5,y:18.5,boards:6,timer:0},{x:21.5,y:23.5,boards:6,timer:0},{x:15.5,y:26.5,boards:6,timer:0},{x:1.5,y:13.5,boards:6,timer:0},{x:1.5,y:24.5,boards:6,timer:0},{x:30.5,y:13.5,boards:6,timer:0},{x:30.5,y:24.5,boards:6,timer:0},{x:9.5,y:2.5,boards:6,timer:0},{x:22.5,y:8.5,boards:6,timer:0}];
// Wall fixtures share the raycast wall surface, rather than camera-facing billboards.
const wallFixtures=[];
function mountFixture(o,kind){let bounds=o.x<9?[1,8,12,25]:o.x>22?[23,30,12,25]:o.y<11?[7,24,1,8]:[10,21,15,26],candidates=[];
for(let y=bounds[2];y<=bounds[3];y++)for(let x=bounds[0];x<=bounds[1];x++){if(legacyTemplate[y][x]!=='0')continue;for(let [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]]){if(x+dx>=bounds[0]&&x+dx<=bounds[1]&&y+dy>=bounds[2]&&y+dy<=bounds[3])continue;if(legacyTemplate[y+dy]?.[x+dx]!=='1')continue;candidates.push({x:x+.5,y:y+.5,mx:x+dx,my:y+dy,dx,dy,d:Math.hypot(x+.5-o.x,y+.5-o.y)})}}
candidates.sort((a,b)=>a.d-b.d);let n=candidates.find(n=>!wallFixtures.some(f=>f.mx===n.mx&&f.my===n.my))||candidates[0];if(!n)return;o.x=n.x;o.y=n.y;o.mounted=true;wallFixtures.push({...n,kind,object:o,height:kind==='window'?1.12:kind==='sign'?.24:.48,bottom:kind==='window'?.12:kind==='sign'?1.05:.65,width:kind==='window'?.84:.82})}
const trapSwitch=stations.find(s=>s.type==='trap');wallFixtures.push({x:14.5,y:15.5,mx:14,my:14,dx:0,dy:-1,kind:'trap-switch',object:trapSwitch,height:.34,bottom:.58,width:.24});
fuseStations.forEach(f=>mountFixture(f,'fuse'));windows.forEach(w=>mountFixture(w,'window'));stations.filter(s=>guns[s.type]).forEach(s=>mountFixture(s,'weapon'));
// Place large equipment against room boundaries with fixed cabinets and bases.
for(const s of stations.filter(s=>['health','speed','double','power','upgrade','ammo'].includes(s.type))){mountFixture(s,'machine');s.mounted=false;let f=wallFixtures.pop();if(f){s.wallDX=f.dx;s.wallDY=f.dy;s.rotation=Math.atan2(f.dx,f.dy);s.x+=f.dx*.32;s.y+=f.dy*.32}}
// Reserve clear approach zones before scene props and collision geometry are used.
const accessClearances=[...wallFixtures.map(f=>({x:f.x,y:f.y,r:1.25})),...gates.map(g=>({x:g.x,y:g.y,r:1.35}))];
function blocksAccess(p){return accessClearances.some(a=>Math.hypot(p.x-a.x,p.y-a.y)<a.r+Math.max(p.ex||.3,p.ey||.3))}
for(let i=factoryProps.length-1;i>=0;i--)if(blocksAccess(factoryProps[i]))factoryProps.splice(i,1);
for(let i=mapObstacles.length-1;i>=0;i--)if(['pipe','gantry-post','column'].includes(mapObstacles[i].type)||blocksAccess(mapObstacles[i]))mapObstacles.splice(i,1);
const movedMapObjects=new Set();
function translateMapObject(o){if(movedMapObjects.has(o))return;movedMapObjects.add(o);expandPoint(o)}
function translateFixture(f){expandPoint(f);f.mx=expandAxis(f.mx,'x');f.my=expandAxis(f.my,'y');translateMapObject(f.object)}
[base,...stations,...boxLocations,...factoryProps,...mapObstacles,...architectureProps,...gates].forEach(translateMapObject);
// Bank Mainframe Link Pad is clear of the reception desk and the entry corridor.
Object.assign(stations.find(s=>s.type==='tele'&&s.id===0),{x:8.25,y:23.25});
wallFixtures.forEach(translateFixture);
gates.forEach(g=>g.cells=g.cells.map(([x,y])=>[expandAxis(x,'x'),expandAxis(y,'y')]));
for(const k of ['x0','x1'])trapZone[k]=expandAxis(trapZone[k],'x');for(const k of ['y0','y1'])trapZone[k]=expandAxis(trapZone[k],'y');
installDistrict();installEquipment();
function giveGun(type){cancelSignalCharge(true);weaponMuzzleWorld=null;if(runChallenge==='pistol'&&type!=='pistol'){tell('Pistol-only challenge: keep your service pistol');return}let nw={type,mag:guns[type].cap,reserve:reserveCapacity(type),upgraded:false};if(inventory.length<2){inventory.push(nw);slot=inventory.length-1}else inventory[slot]=nw;reloading=0;shotClock=.3;tell(guns[type].name+' EQUIPPED')}
function updateHudAppearance(w,g){updateSignalHud(w);
 let category=g.sidearm||['pistol','silenced','revolver'].includes(w.type)?'SIDEARM':g.pellets||w.type==='shotgun'?'SHOTGUN':['lmg','heavy'].includes(w.type)?'SUPPORT':(g.scope||w.type==='lever')?'PRECISION':['arc','signal'].includes(w.type)?'ENERGY':['smg','compact','pdw'].includes(w.type)?'SUBMACHINE GUN':'ASSAULT RIFLE';
 $('weapon-class').textContent=(w.upgraded?'FORGED · ':'')+category+(w.upgraded?' · '+attachmentLabel(w):'');$('ammo-panel').setAttribute?.('data-upgraded',String(!!w.upgraded));$('ammo-panel').setAttribute?.('data-state',reloading?'reload':w.mag===0?'empty':w.mag<=Math.ceil(magazineCapacity(w)*.20)?'low':'ready');$('vitals-panel').setAttribute?.('data-critical',String(player.hp<player.maxhp*.30));
 $('reload-track').hidden=reloading<=0;$('reload-progress').style.width=Math.max(0,Math.min(100,(1-reloading/reloadDuration(w.type))*100))+'%';$('reload').textContent=reloading?(g.shellTime?'LOADING SHELL':'RELOADING'):w.mag===0?'RELOAD REQUIRED':'R / '+controllerLabel('reload')+' · RELOAD';
 for(let i=0;i<3;i++)$('fuse-'+i).style.background=(activeMapId==='railyard'?depotState.valves[i]:fuses[i])?'#e8ca83':'#738c8640';
}
function objective(){if(activeMapId==='railyard')return mapObjective();let quest=fuses.every(Boolean)&&!questDone?' · 3 FUSES READY: USE POWER CABINET':questDone?' · AUXILIARY SHIELD ONLINE':'';if(power&&!linked.every(Boolean)&&linking<0)return `LINK TELEPORTERS · ${linked.filter(Boolean).length}/3${quest}`;if(power&&linked.every(Boolean))return 'FORGE ONLINE'+quest;if(!power&&fuses.every(Boolean))return 'RESTORE POWER · INSTALL SALVAGED FUSES';if(!power)return 'OPEN THE UTILITY BLOCK · RESTORE POWER';if(linking>=0)return `LINK ${'ABC'[linking]}: RETURN TO COMMAND RELAY · ${Math.ceil(linkTime)}s`;if(!linked.every(Boolean))return `LINK TELEPORTERS TO COMMAND RELAY · ${linked.filter(Boolean).length}/3`;return 'FORGE-A-PUNCH ONLINE · UPGRADE YOUR WEAPONS'}
try{let pref=localStorage.getItem('dead-frequency-renderer');$('renderer-mode').value=pref==='classic'?'classic':'3d'}catch(e){$('renderer-mode').value='3d'}$('renderer-mode').onchange=()=>{try{localStorage.setItem('dead-frequency-renderer',$('renderer-mode').value)}catch(e){}};
let zbuffer=new Float32Array(1);
function renderDimensions(quality,width,height,dpr=1){
 width=Math.max(1,width);height=Math.max(1,height);
 let target=Number(quality),scale=target>0?target/width:Math.min(2,Math.max(1,dpr));
 // Preserve the viewport aspect ratio, including portrait and ultrawide PCs.
 scale=Math.min(scale,2560/width,1440/height,Math.sqrt(3686400/(width*height)));
 return [Math.max(2,Math.round(width*scale)),Math.max(2,Math.round(height*scale))];
}
function resize(){[W,H]=renderDimensions($('quality').value,innerWidth,innerHeight,window.devicePixelRatio||1);cv.width=W;cv.height=H;if(zbuffer.length!==W+4)zbuffer=new Float32Array(W+4)}resize();addEventListener('resize',resize);$('quality').onchange=()=>{resize();try{localStorage.setItem('dead-regiment-quality',$('quality').value)}catch{}};
try{let savedQuality=localStorage.getItem('dead-regiment-quality');if(['480','800','1280','1920','0'].includes(savedQuality)){$('quality').value=savedQuality;resize()}}catch{}
function cell(x,y){return world[Math.floor(y)]?.[Math.floor(x)]??1}function solid(x,y){return cell(x,y)!==0}function groundCanMove(x,y,r=.22){for(let st of stations){if(st.mounted)continue;let ex,ey;if(st.type==='box'){ex=.48;ey=.28}else if(perkDefinitions[st.type]||['power','upgrade','ammo'].includes(st.type)){let f=stationFootprint(st);ex=f.ex;ey=f.ey}else continue;if(Math.abs(x-st.x)<ex+r&&Math.abs(y-st.y)<ey+r)return false;}for(let p of mapObstacles){if(livingPropGone53(p))continue;if(p.only3d&&$('renderer-mode').value!=='3d')continue;if(Math.abs(x-p.x)<p.ex+r&&Math.abs(y-p.y)<p.ey+r)return false;}return !solid(x-r,y-r)&&!solid(x+r,y-r)&&!solid(x-r,y+r)&&!solid(x+r,y+r)}function canMove(x,y,r=.22,o=player){
 if(o===player&&$('renderer-mode').value!=='3d'&&inFireEscape(x,y)){if(!o.stairHint){tell('Select Enhanced 3D to use the fire escape');o.stairHint=true}return false}let level=actorLevelAt(o,x,y),height=inFireEscape(x,y)?stairHeight(x,y):level*UPPER_HEIGHT;if(Math.abs(height-actorElevation(o))>.221)return false;
 if(level===1){for(const p of upperProps)if(Math.abs(x-p.x)<p.ex+r&&Math.abs(y-p.y)<p.ey+r)return false;return [[-r,-r],[r,-r],[-r,r],[r,r]].every(([dx,dy])=>(upperCellOpen(x+dx,y+dy)||(inFireEscape(x+dx,y+dy)&&stairHeight(x+dx,y+dy)>1.59)))}
 if(inFireEscape(x,y)){if(x-r<20.04||x+r>21.96)return false;if(y-r<34&&!upperCellOpen(x,y-r))return false;return groundCanMove(x,y,r)}
 return groundCanMove(x,y,r)
}
// Shared player/enemy contact layer. Static map navigation remains separate.
let playerMotionStart=null,playerHitGraceUntil=0;
function enemyBodyRadius(z){return z.dog?.24:z.crippled?.18:.20}
function enemyBodyHeight(z){return z.dog?.58:z.crippled?.43:1.03}
function enemyContactEligible(z){
 if(z.dead||z.wait)return false;let base=actorElevation(z),feet=actorElevation(player)+jumpHeight;
 return feet<base+enemyBodyHeight(z)&&feet+Math.max(.32,stanceEye+.10)>base+.04;
}
function enemyBodyOpen(x,y,r=.22){
 for(let z of zombies){if(!enemyContactEligible(z))continue;let radius=r+enemyBodyRadius(z),before=Math.hypot(player.x-z.x,player.y-z.y),after=Math.hypot(x-z.x,y-z.y);
  if(after<radius-.0001&&after<before-.00001)return false;
  if(before>=radius-.0001&&after<radius-.0001)return false;
 }return true;
}
function contactMotion(dx,dy,r=.22){
 let x=player.x,y=player.y;
 // Each static-motion substep is <= .08; earliest circle sweep prevents tunneling.
 for(let pass=0;pass<3;pass++){
  let hit=null,first=1;
  for(let z of zombies){if(!enemyContactEligible(z))continue;let radius=r+enemyBodyRadius(z),ox=x-z.x,oy=y-z.y,a=dx*dx+dy*dy,b=2*(ox*dx+oy*dy),c=ox*ox+oy*oy-radius*radius;
   if(a<1e-12)break;if(c<0){if(ox*dx+oy*dy<0){let len=Math.hypot(ox,oy)||1;hit={z,t:0,nx:ox/len,ny:oy/len};first=0}continue}
   let discriminant=b*b-4*a*c;if(discriminant<0)continue;let t=(-b-Math.sqrt(discriminant))/(2*a);if(t>=0&&t<first){let hx=ox+dx*t,hy=oy+dy*t,len=Math.hypot(hx,hy)||1;hit={z,t,nx:hx/len,ny:hy/len};first=t}
  }
  if(!hit)break;let t=Math.max(0,hit.t-.001),slideX=dx*(1-t),slideY=dy*(1-t),inward=Math.min(0,slideX*hit.nx+slideY*hit.ny);
  dx=dx*t+slideX-hit.nx*inward;dy=dy*t+slideY-hit.ny*inward;
 }return [dx,dy];
}
function resolveEnemyContact(dt){
 // Bound recovery for pre-existing overlaps (old saves/spawns); never teleport.
 let remaining=Math.min(.035,.55*dt),x=player.x,y=player.y;
 for(let z of zombies){if(!enemyContactEligible(z))continue;let dx=x-z.x,dy=y-z.y,length=Math.hypot(dx,dy),penetration=.22+enemyBodyRadius(z)-length;if(penetration<=.001)continue;
  if(length<.001){dx=-Math.cos(player.a);dy=-Math.sin(player.a);length=1}let step=Math.min(remaining,penetration+.001),nx=x+dx/length*step,ny=y+dy/length*step;
  if(canMove(nx,ny,.22,player)&&enemyBodyOpen(nx,ny)){player.x=x=nx;player.y=y=ny;remaining-=step}
  if(remaining<.0001)break;
 }
}
function attackHitsMotion(z,dt,from,to){
 if(Math.abs(actorElevation(z)-actorElevation(player))>=.48)return null;
 let reach=z.dog?.88:z.crippled?.78:.92,old=playerMotionStart||player;
 let a={x:old.x+(player.x-old.x)*from,y:old.y+(player.y-old.y)*from},b={x:old.x+(player.x-old.x)*to,y:old.y+(player.y-old.y)*to},dx=b.x-a.x,dy=b.y-a.y,len=dx*dx+dy*dy;
 let t=len>1e-12?Math.max(0,Math.min(1,((z.x-a.x)*dx+(z.y-a.y)*dy)/len)):0;
 for(let u of[t,0,1]){let point={x:a.x+dx*u,y:a.y+dy*u,level:player.level},distance=Math.hypot(point.x-z.x,point.y-z.y),bearing=Math.atan2(point.y-z.y,point.x-z.x),turn=Math.atan2(Math.sin(bearing-z.attackHeading),Math.cos(bearing-z.attackHeading));
  if(distance<reach&&Math.abs(turn)<1.1&&rayClear3D(z.x,z.y,actorElevation(z)+.45,point.x,point.y,actorElevation(player)+.45))return bearing;
 }return null;
}
function enemyAttack(z,dt){
 if(z.attackElapsed==null)return false;let previous=z.attackElapsed,duration=z.attackDuration||.9;z.attackElapsed+=dt;
 let start=duration*.42,end=duration*.54;
 if(!z.attackContact&&z.attackElapsed>=start&&previous<=end){let from=Math.max(0,Math.min(1,(start-previous)/dt)),to=Math.max(from,Math.min(1,(end-previous)/dt)),bearing=attackHitsMotion(z,dt,from,to);
  if(bearing!==null){z.attackContact=true;if(time>=playerHitGraceUntil){playerHitGraceUntil=time+.16;damageBearing=bearing+Math.PI;damageBearingTime=1.2;player.hp-=(z.damage||25)*(questDone?.85:1);player.lastHit=time;hurt=.9;sound(55,.3,.15,'sawtooth',true);if(player.hp<=0)die()}}
 }
 if(z.attackElapsed>end)z.attackContact=true;
 if(z.attackElapsed>=duration){z.attackElapsed=null;z.cooldown=z.dog?.25:.35}return true;
}

function move(o,dx,dy,r=.22){let distance=Math.hypot(dx,dy),steps=Math.max(1,Math.ceil(distance/.08));for(let i=0;i<steps;i++){let mx=dx/steps,my=dy/steps;if(o===player)[mx,my]=contactMotion(mx,my,r);let x=o.x+mx,y=o.y+my;if(canMove(x,o.y,r,o)&&(o!==player||enemyBodyOpen(x,o.y,r))){o.level=actorLevelAt(o,x,o.y);o.x=x}if(canMove(o.x,y,r,o)&&(o!==player||enemyBodyOpen(o.x,y,r))){o.level=actorLevelAt(o,o.x,y);o.y=y}}}

// Cached offline gun reports: individual crack/body/tail spectra per weapon.
const gunReports={scout:[.44,74,.033,.94,.65],interceptor:[.40,86,.029,.96,.58],burst:[.21,146,.023,.89,.41],lever:[.39,92,.043,.87,.63],pdw:[.13,211,.015,.79,.25],combatsg:[.40,61,.064,.96,.69],battlerifle:[.33,106,.037,.95,.60],machinepistol:[.14,238,.014,.73,.31],pistol:[.17,195,.018,.58,.42],smg:[.12,170,.014,.76,.23],shotgun:[.39,67,.062,.94,.65],lmg:[.26,95,.031,.87,.53],rifle:[.23,132,.023,.90,.40],carbine:[.28,117,.031,.80,.49],revolver:[.34,82,.042,.89,.72],autosg:[.31,75,.054,.96,.55],sniper:[.49,58,.036,1,.70],heavy:[.30,71,.039,.90,.64],arc:[.43,430,.12,.10,.80],doublebarrel:[.43,52,.069,1,.79],compact:[.10,225,.011,.71,.18],marksman:[.36,92,.029,.96,.57],silenced:[.14,275,.012,.16,.19],drumrifle:[.25,106,.028,.82,.45]};
let gunReportBuffers={},gunSoundVoices=[];
function makeGunReport(type){let [duration,pitch,decay,crack,body]=gunReports[type]||gunReports.rifle,b=ac.createBuffer(1,Math.ceil(ac.sampleRate*duration),ac.sampleRate),a=b.getChannelData(0),low=0,phase=0;for(let i=0;i<a.length;i++){let t=i/ac.sampleRate,n=Math.random()*2-1;low+=.13*(n-low);phase+=2*Math.PI*pitch*Math.exp(-t*5)/ac.sampleRate;let attack=Math.min(1,t/.0007),v=(n-low)*crack*Math.exp(-t/decay)+low*.9*Math.exp(-t/(duration*.22))+Math.sin(phase)*body*Math.exp(-t/(duration*.18));if(type==='arc')v=Math.sin(phase)*Math.exp(-t*7)*(.75+.25*Math.sin(t*180));v*=attack;let fade=Math.min(1,(duration-t)/.025);a[i]=Math.tanh(v*1.7)*fade*.85}return b}
function gunReport(type){if(!$('sound').checked||!ac)return;try{let src=ac.createBufferSource(),g=ac.createGain();src.buffer=gunReportBuffers[type]||(gunReportBuffers[type]=makeGunReport(type));src.playbackRate.value=.98+Math.random()*.04;g.gain.setValueAtTime(type==='silenced'?.16:.24,ac.currentTime);src.connect(g);g.connect(ac.destination);if(roomEcho&&roomAt(player.x,player.y)!=='outdoors')g.connect(roomEcho);if(gunSoundVoices.length>=8){let old=gunSoundVoices.shift();old.src.stop();old.src.disconnect();old.g.disconnect()}let v={src,g};gunSoundVoices.push(v);src.onended=()=>{gunSoundVoices=gunSoundVoices.filter(q=>q!==v);src.disconnect();g.disconnect()};src.start();src.stop(ac.currentTime+src.buffer.duration/src.playbackRate.value+.01)}catch(e){}}
function stopGunReports(){for(let v of gunSoundVoices){try{v.src.stop()}catch(e){}v.src.disconnect();v.g.disconnect()}gunSoundVoices=[]}
let incidentalVoices=[];
function stopIncidentalAudio(){stopSignalChargeAudio();for(let v of incidentalVoices){try{v.src.stop()}catch{}v.src.disconnect();v.g.disconnect()}incidentalVoices=[]}
function sound(freq,duration=.1,volume=.07,type='sawtooth',noise=false){if(!$('sound').checked||!ac)return;if(incidentalVoices.length>=12){let old=incidentalVoices.shift();try{old.src.stop()}catch{}old.src.disconnect();old.g.disconnect()}try{let src=noise?ac.createBufferSource():ac.createOscillator(),g=ac.createGain();if(noise)src.buffer=noiseBuffer;else{src.type=type;src.frequency.setValueAtTime(freq,ac.currentTime);src.frequency.exponentialRampToValueAtTime(Math.max(25,freq*.35),ac.currentTime+duration)}g.gain.setValueAtTime(volume,ac.currentTime);g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+duration);src.connect(g);g.connect(ac.destination);let v={src,g};incidentalVoices.push(v);src.onended=()=>{incidentalVoices=incidentalVoices.filter(q=>q!==v);src.disconnect();g.disconnect()};src.start();src.stop(ac.currentTime+duration)}catch(e){}}
let groanBuffers=[],groanVoices=[],groanClock=0;
// Irregular glottal pulses and filtered breath replace the old 23Hz engine buzz.
function makeGroanBuffer(seed){
 const duration=1.75+seed*.19,rate=ac.sampleRate,b=ac.createBuffer(1,Math.ceil(rate*duration),rate),out=b.getChannelData(0);let rng=7417+seed*991,phase=0,jitter=0,drift=0,breath=0;
 const random=()=>{rng=(Math.imul(rng,1664525)+1013904223)|0;return (rng>>>0)/4294967296};
 const resonator=(freq,bw)=>({r:Math.exp(-Math.PI*bw/rate),c:Math.cos(2*Math.PI*freq/rate),a:0,b:0});
 const filters=[resonator(430+seed*27,130),resonator(1080-seed*43,180),resonator(2300+seed*61,310)];
 for(let i=0;i<out.length;i++){
  let t=i/rate,u=t/duration;drift+=((random()-.5)*.09-drift)*.0007;let f=(100+seed*13)*(1-u*.24)+8*Math.sin(u*4.1)+drift*35;
  phase+=f/rate;if(phase>=1){phase-=1;jitter=(random()-.5)*.18}let cycle=phase*(1+jitter),pulse=cycle<.42?Math.sin(Math.PI*cycle/.42)**2:cycle<.67?-.23*Math.sin(Math.PI*(cycle-.42)/.25):0;
  let n=random()*2-1;breath+=.19*(n-breath);let dropout=1-.66*Math.exp(-Math.pow((u-(.39+seed*.035))/.055,2)),env=Math.min(1,u/.10)*Math.max(0,1-u)**.65*(.68+.32*Math.sin(Math.PI*u));let source=pulse*dropout+breath*(.24+.5*u)+n*.025,v=0;
  for(let k=0;k<filters.length;k++){let q=filters[k],y=2*q.r*q.c*q.a-q.r*q.r*q.b+(1-q.r)*source;q.b=q.a;q.a=y;v+=y*[1,.58,.19][k]}
  out[i]=Math.tanh(v*7)*env*.78;
 }
 return b;
}
let spatialVoices=[],spatialBuffers={},roomEcho=null,roomEchoGain=null,environmentStepClock=0,atmosphereClock=2;
function roomAt(x,y){return interiorZones.find(r=>x>r.x0&&x<r.x1+1&&y>r.y0&&y<r.y1+1)?.id||'outdoors'}
function initAtmosphereAudio(){if(!ac||roomEcho)return;try{roomEcho=ac.createConvolver();roomEchoGain=ac.createGain();let b=ac.createBuffer(2,Math.floor(ac.sampleRate*.65),ac.sampleRate);for(let ch=0;ch<2;ch++){let a=b.getChannelData(ch);for(let i=0;i<a.length;i++){let t=i/ac.sampleRate;a[i]=(Math.random()*2-1)*Math.exp(-t*13)*.075;for(let delay of[.047,.083,.137])if(Math.abs(t-delay-ch*.004)<1/ac.sampleRate)a[i]+=.18*Math.exp(-delay*5)}}roomEcho.buffer=b;roomEchoGain.gain.value=.13;roomEcho.connect(roomEchoGain);roomEchoGain.connect(ac.destination)}catch{roomEcho=null;roomEchoGain=null}}
function spatialBuffer(kind){if(spatialBuffers[kind])return spatialBuffers[kind];let duration=kind==='hound'?.65:kind==='metal'?.35:kind==='impact'?.18:.14,b=ac.createBuffer(1,Math.ceil(ac.sampleRate*duration),ac.sampleRate),a=b.getChannelData(0),low=0,phase=0;for(let i=0;i<a.length;i++){let t=i/ac.sampleRate,n=Math.random()*2-1;low+=.09*(n-low);phase+=2*Math.PI*(kind==='hound'?135:kind==='metal'?185:65)*Math.exp(-t*3)/ac.sampleRate;let v=kind==='hound'?(Math.sin(phase)+Math.sin(phase*2.13)*.23+low*.8)*Math.exp(-t*6):kind==='metal'?(Math.sin(phase)*.30+Math.sin(phase*2.7)*.14+n*.08)*Math.exp(-t*12):kind==='impact'?low*Math.exp(-t*25)+n*.13*Math.exp(-t*45):low*Math.exp(-t*42)+Math.sin(phase)*.20*Math.exp(-t*35)+n*.055*Math.exp(-t*60);a[i]=v*Math.min(1,t/.003)*Math.min(1,(duration-t)/.02)*.9}return spatialBuffers[kind]=b}
function positionVoice(v){let dx=v.actor.x-player.x,dy=v.actor.y-player.y,d=Math.hypot(dx,dy),blocked=!visibleBetween(player.x,player.y,v.actor.x,v.actor.y);v.g.gain.value=v.volume/(1+d*.5)*(blocked?.3:1);if(v.pan)v.pan.pan.value=Math.max(-1,Math.min(1,(-dx*Math.sin(player.a)+dy*Math.cos(player.a))/Math.max(.1,d)));if(v.filter)v.filter.frequency.value=blocked?650:5200}
function playSpatial(buffer,actor,volume=.12,pitch=1){if(!ac||!$('sound').checked||spatialVoices.length>=12)return false;try{let src=ac.createBufferSource(),g=ac.createGain(),pan=ac.createStereoPanner?ac.createStereoPanner():null,filter=ac.createBiquadFilter?ac.createBiquadFilter():null;src.buffer=buffer;src.playbackRate.value=pitch;let v={src,g,pan,filter,actor,volume};src.connect(filter||g);if(filter){filter.type='lowpass';filter.connect(g)}g.connect(pan||ac.destination);if(pan)pan.connect(ac.destination);if(roomEcho&&roomAt(player.x,player.y)!=='outdoors')g.connect(roomEcho);positionVoice(v);spatialVoices.push(v);src.onended=()=>{spatialVoices=spatialVoices.filter(q=>q!==v);src.disconnect();g.disconnect();pan?.disconnect();filter?.disconnect()};src.start();return true}catch{return false}}
function zombieGroan(z){if(!ac||!$('sound').checked||mode!=='playing'||groanVoices.length>=3||!groanBuffers.length||z.dead||Math.hypot(z.x-player.x,z.y-player.y)>12)return false;let buffer=z.dog?spatialBuffer('hound'):groanBuffers[Math.floor(Math.random()*groanBuffers.length)],ok=playSpatial(buffer,z,z.dog?.15:.24,.95+Math.random()*.10);if(ok){let v=spatialVoices[spatialVoices.length-1];groanVoices.push(v);let ended=v.src.onended;v.src.onended=()=>{groanVoices=groanVoices.filter(q=>q!==v);ended()}}return ok}
function stopAtmosphere(){for(let v of spatialVoices){try{v.src.stop()}catch{}v.src.disconnect();v.g.disconnect();v.pan?.disconnect();v.filter?.disconnect()}spatialVoices=[];groanVoices=[]}
function updateAtmosphere(dt){if(!ac||!$('sound').checked){if(spatialVoices.length)stopAtmosphere();return}initAtmosphereAudio();for(let v of spatialVoices)positionVoice(v);if(roomEchoGain)roomEchoGain.gain.value=roomAt(player.x,player.y)==='outdoors'?.025:.13;environmentStepClock-=dt;if(playerMoving&&jumpHeight===0&&environmentStepClock<=0){environmentStepClock=sprintBlend>.5?.26:stance===0?.39:.62;playSpatial(spatialBuffer('step'),player,.08,sprintBlend>.5?1.12:.96)}let footBudget=3;for(let z of zombies){if(!z.moving||z.wait||z.dead||Math.hypot(z.x-player.x,z.y-player.y)>9)continue;let step=Math.floor((z.walk||0)/Math.PI);if(z.audioStep!==step){z.audioStep=step;if(footBudget-->0)playSpatial(spatialBuffer('step'),z,z.dog?.10:.08,z.dog?1.35:.8+z.speed*.1)}}atmosphereClock-=dt;if(power&&atmosphereClock<=0){atmosphereClock=5+Math.random()*8;let nearLamp=factoryProps.find(p=>p.type==='lamp'&&Math.hypot(p.x-player.x,p.y-player.y)<8);if(nearLamp)playSpatial(spatialBuffer('metal'),nearLamp,.055,.7+Math.random()*.3)}}

function stopGroans(){stopAtmosphere()}
function updateGroans(dt){if(!$('sound').checked){stopGroans();return}groanClock-=dt;if(groanClock>0)return;groanClock=.9+Math.random()*.9;let candidates=zombies.filter(z=>!z.dead&&Math.hypot(z.x-player.x,z.y-player.y)<12&&(z.nextGroan||0)<=time);if(candidates.length){let z=candidates[Math.floor(Math.random()*candidates.length)];if(zombieGroan(z))z.nextGroan=time+4+Math.random()*5}}
$('sound').addEventListener?.('change',()=>{if(!$('sound').checked){stopGroans();stopGunReports();stopSignalChargeAudio()}});
function initAudio(){if(ac){ac.resume();return}try{ac=new(window.AudioContext||window.webkitAudioContext)();noiseBuffer=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);let a=noiseBuffer.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;groanBuffers=Array.from({length:4},(_,i)=>makeGroanBuffer(i))}catch(e){}}
// Forge upgrades belong to weapon instances: base wall buys and box stats stay intact.
function magazineCapacity(w=weapon()) {return guns[w.type].cap+(w.upgraded?Math.max(2,Math.ceil(guns[w.type].cap*.5)):0)}
function forgeAttachments(w=weapon()) {
 const g=guns[w.type],redDot=!!w.upgraded&&!g.scope&&['smg','compact','pdw','rifle','carbine','burst','battlerifle','drumrifle','lmg'].includes(w.type);
 return {redDot,laser:!!w.upgraded&&['pistol','silenced','machinepistol','revolver','shotgun','autosg','combatsg','heavy','compact','pdw'].includes(w.type),extended:!!w.upgraded};
}
function forgeSightProfile(w=weapon()){let a=forgeAttachments(w);return {replacement:a.redDot,axis:a.redDot?(w.type==='pdw'?.092:.070):.044,raise:a.redDot&&w.type==='pdw'?.022:0}}
function forgeWeapon(w=weapon()) {w.upgraded=true;w.mag=magazineCapacity(w);w.reserve=reserveCapacity(w.type,w);reloading=0;cancelSignalCharge(true);let a=forgeAttachments(w);if(w.type==='signal'){tell('FREQUENCY ZERO · 9 CELLS · FASTER CHARGE · SEVEN-TARGET CHAIN');lightning=$('reduced-flashes').checked?.06:.18;return}tell('FORGED · 2.5× DAMAGE · '+w.mag+' ROUND CAPACITY'+(a.redDot?' · RED DOT':'')+(a.laser?' · LASER':''));lightning=.35}
function laserDistance(){let distance=Math.min(24,lineDist(player.a));for(let z of zombies)if(!z.dead&&Math.hypot(z.x-player.x,z.y-player.y)<distance&&aimedRegion(z)&&shotVisible(z))distance=Math.max(.20,Math.hypot(z.x-player.x,z.y-player.y)-.06);return Math.max(.20,distance)}
function attachmentLabel(w=weapon()){let a=forgeAttachments(w);return [a.redDot?'RED DOT':null,a.laser?'LASER':null,a.extended?'EXTENDED AMMO':null].filter(Boolean).join(' · ')}

// Optional timed field repair: existing mounted control cabinets, no new blockers.
let fieldTask={target:-1,remaining:0,progress:0,completed:0,available:0},fieldTaskClock=0;
function fieldTaskSites(){return stations.filter(s=>activeMapId==='railyard'?s.type==='coolant':s.type==='tele')}
function fieldTaskTarget(){return fieldTaskSites()[fieldTask.target]}
function fieldTaskLabel(){if(fieldTask.target<0)return fieldTask.completed?'FIELD RELAYS RESTORED · '+fieldTask.completed:'OPTIONAL: POWER CABINET · FIELD RELAY CONTRACT';let n=fieldTaskTarget();return 'OPTIONAL: '+(n?.label||'FIELD RELAY')+' · HOLD AREA '+Math.floor(fieldTask.progress)+'/18s · '+Math.ceil(fieldTask.remaining)+'s LEFT'}
function beginFieldTask(){if(!power){tell('Restore power before accepting a field repair');return false}if(fieldTask.target>=0){tell(fieldTaskLabel());return true}if(round<fieldTask.available){tell('Next field repair available in round '+fieldTask.available);return true}let sites=fieldTaskSites();if(!sites.length)return false;fieldTask.target=fieldTask.completed%sites.length;fieldTask.remaining=90;fieldTask.progress=0;banner('FIELD RELAY CONTRACT');tell(fieldTaskLabel());return true}
function updateFieldTask(dt){if(fieldTask.target<0)return;fieldTask.remaining-=dt;let n=fieldTaskTarget();if(n&&Math.hypot(player.x-n.x,player.y-n.y)<2.6&&(player.level||0)===0)fieldTask.progress=Math.min(18,fieldTask.progress+dt);if(fieldTask.progress>=18-1e-6){points+=750;inventory.forEach(w=>w.reserve=Math.min(reserveCapacity(w.type,w),w.reserve+magazineCapacity(w)*2));fragCount=Math.min(4,fragCount+1);fieldTask.completed++;fieldTask.available=round+3;fieldTask.target=-1;banner('FIELD RELAY RESTORED · +750');tell('Repair reward: reserve ammo and one frag. Next contract in round '+fieldTask.available)}else if(fieldTask.remaining<=0){fieldTask.target=-1;fieldTask.available=round+1;tell('Field repair expired. Retry at the power cabinet next round.')}}

// One browser/PC-local resume slot. Serialize plain state, not GL/audio/DOM objects.
const RUN_SAVE_KEY='dead-regiment-resume-v1';let runSaveClock=15,runSaveNotice='';
function runSnapshot(){
 let values={flashlightOn,time,round,points,killCount,power,boost,linked,linking,linkTime,teleCooldown,fastReload,doubleTap,trapTime,trapCooldown,boxTime,boxLife,boxSpins,boxIndex,boxOffer,boxPending,boxPreview,boxLast,boxShuffle,dogRound,nextRound,remaining,spawnClock,fragCount,tacticalCount,stamina,stance,upperUnlocked,fuses,questDone,runChallenge,runStats,depotState,fieldTask};
 for(let k of ['nextRound','spawnClock','boxTime','boxLife','boxShuffle'])values[k]=Math.max(0,values[k]);values.fieldTask={...fieldTask,remaining:Math.max(0,fieldTask.remaining)};
 let numericActor=z=>{let q={};for(let[k,v]of Object.entries(z))if((typeof v==='number'&&Number.isFinite(v))||typeof v==='string'||typeof v==='boolean')q[k]=v;return q};
 return {schema:1,version:GAME_VERSION,savedAt:Date.now(),map:activeMapId,living:livingSnapshot53(),world:world.map(r=>r.slice()),player:numericActor(player),inventory:inventory.map(w=>({...w})),slot,perks:[...ownedPerks],values,windows:windows.map(w=>({boards:w.boards,timer:w.timer})),box:{x:stations.find(s=>s.type==='box').x,y:stations.find(s=>s.type==='box').y},zombies:zombies.filter(z=>!z.dead).map(z=>({...numericActor(z),waitIndex:z.wait?windows.indexOf(z.wait):-1})),drops:drops.map(d=>({...d})),grenades:grenades.map(g=>({...g}))};
}
function validRunSnapshot(s){
 const finite=(n,min,max)=>typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max,int=(n,min,max)=>Number.isInteger(n)&&finite(n,min,max),plain=o=>o&&typeof o==='object'&&!Array.isArray(o),finiteTree=(o,depth=0)=>depth<8&&(o===null||typeof o==='boolean'||typeof o==='string'&&o.length<120||typeof o==='number'&&Number.isFinite(o)||Array.isArray(o)&&o.length<220&&o.every(v=>finiteTree(v,depth+1))||plain(o)&&Object.keys(o).length<100&&Object.values(o).every(v=>finiteTree(v,depth+1)));
 if(!plain(s)||s.schema!==1||!mapCatalog[s.map]||!finite(s.savedAt,0,1e16)||!plain(s.values)||!finiteTree(s.values)||!plain(s.player)||!finiteTree(s.player))return false;
 let w=s.world;if(!Array.isArray(w)||w.length!==44||![46,LIVING_WIDTH53].includes(w[0]?.length)||w.some(r=>!Array.isArray(r)||r.length!==w[0].length||r.some(n=>!int(n,0,2))))return false;
 if(!finite(s.player.x,1,w[0].length-1)||!finite(s.player.y,1,43)||!finite(s.player.hp,.001,1000)||!finite(s.player.maxhp,1,1000)||!int(s.player.level||0,0,1)||!finite(s.player.a,-1e8,1e8)||!finite(s.player.pitch,-.65,.65))return false;
 if(!Array.isArray(s.inventory)||s.inventory.length<1||s.inventory.length>2||!int(s.slot,0,s.inventory.length-1)||s.inventory.some(a=>!plain(a)||!guns[a.type]||typeof a.upgraded!=='boolean'&&a.upgraded!=null||!int(a.mag,0,magazineCapacity(a))||!int(a.reserve,0,Math.ceil(guns[a.type].max*2.25))))return false;
 if(!Array.isArray(s.perks)||s.perks.length>7||s.perks.some(p=>!perkDefinitions[p])||new Set(s.perks).size!==s.perks.length)return false;
 let v=s.values;for(let k of ['time','round','points','killCount','nextRound','remaining','spawnClock','fragCount','tacticalCount','stamina','stance','trapTime','trapCooldown','boxTime','boxLife','boxSpins','boxIndex','linkTime','teleCooldown','boxShuffle'])if(!finite(v[k],0,1e9))return false;
 if(!int(v.round,0,9999)||!int(v.remaining,0,500)||!int(v.fragCount,0,4)||!int(v.tacticalCount,0,2)||!int(v.stance,0,2)||!int(v.boxIndex,0,s.map==='railyard'?3:2)||!int(v.linking,-1,2)||!['standard','pistol','no-perks'].includes(v.runChallenge))return false;
 for(let k of ['flashlightOn','power','boost','fastReload','doubleTap','dogRound','upperUnlocked','questDone'])if(typeof v[k]!=='boolean')return false;
 for(let k of ['linked','fuses'])if(!Array.isArray(v[k])||v[k].length!==3||v[k].some(b=>typeof b!=='boolean'))return false;
 for(let k of ['boxOffer','boxPending','boxPreview','boxLast'])if(v[k]!==null&&!guns[v[k]])return false;
 if(!plain(v.depotState)||!Array.isArray(v.depotState.valves)||v.depotState.valves.length!==3||v.depotState.valves.some(b=>typeof b!=='boolean')||!finite(v.depotState.charge,0,40)||typeof v.depotState.ready!=='boolean'||typeof v.depotState.charging!=='boolean')return false;
 if(!plain(v.fieldTask)||!int(v.fieldTask.target,-1,2)||!finite(v.fieldTask.remaining,0,90)||!finite(v.fieldTask.progress,0,18)||!int(v.fieldTask.completed,0,1e6)||!int(v.fieldTask.available,0,9999)||!plain(v.runStats)||!plain(v.runStats.weaponKills))return false;
 if(!Array.isArray(s.windows)||s.windows.length!==(s.map==='railyard'?8:9)||s.windows.some(o=>!int(o.boards,0,6)||!finite(o.timer,0,100)))return false;
 if(!plain(s.box)||!finite(s.box.x,1,w[0].length-1)||!finite(s.box.y,1,43))return false;
 if(!Array.isArray(s.zombies)||s.zombies.length>160||s.zombies.some(z=>!plain(z)||!finiteTree(z)||!finite(z.x,0,w[0].length)||!finite(z.y,0,44)||!finite(z.hp,.001,1e9)||!finite(z.max,.001,1e9)||!int(z.waitIndex,-1,s.windows.length-1)||!int(z.level||0,0,1)))return false;
 if(!Array.isArray(s.drops)||s.drops.length>300||s.drops.some(d=>!finiteTree(d)||!finite(d.x,0,w[0].length)||!finite(d.y,0,44)||!finite(d.life,0,20)||!['ammo','health'].includes(d.type)))return false;
 if(!Array.isArray(s.grenades)||s.grenades.length>6||s.grenades.some(g=>!finiteTree(g)||!['frag','tactical'].includes(g.type)||!finite(g.x,0,w[0].length)||!finite(g.y,0,44)||!finite(g.z,0,6)||!finite(g.fuse,0,2)||!['vx','vy','vz'].every(k=>finite(g[k],-20,20))))return false;
 return validLivingSnapshot53(s.living,s.map);
}
function readSavedRun(){try{let raw=localStorage.getItem(RUN_SAVE_KEY);if(!raw||raw.length>250000)return null;let s=JSON.parse(raw);return validRunSnapshot(s)?s:null}catch{return null}}
function refreshSaveMenu(){let s=readSavedRun();$('continue-run').hidden=!s;$('main-continue').hidden=!s;$('save-quit').hidden=true;$('main-save-info').textContent=s?'SAVED OPERATION · '+mapCatalog[s.map].name+' · ROUND '+s.values.round:'';$('save-status').textContent=s?'SAVED · '+mapCatalog[s.map].name+' · ROUND '+s.values.round+' · '+s.values.points.toLocaleString()+' PTS':runSaveNotice||'Runs save automatically, and when you pause.'}
function saveCurrentRun(){runSaveClock=15;if(!['playing','paused'].includes(mode)||player.hp<=0)return false;try{let s=runSnapshot();if(!validRunSnapshot(s))throw Error('state');let previous=localStorage.getItem(RUN_SAVE_KEY);if(previous&&!localStorage.getItem(RUN_SAVE_KEY+'-before-v53')){let old=JSON.parse(previous);if(!old.living)localStorage.setItem(RUN_SAVE_KEY+'-before-v53',previous);}localStorage.setItem(RUN_SAVE_KEY,JSON.stringify(s));runSaveClock=15;runSaveNotice='';return true}catch{runSaveNotice='Unable to save on this device. Keep this tab open.';return false}}
function restoreSavedRun(fromController=false,defer=false){
 let s=readSavedRun();if(!s){tell('No compatible saved run found');refreshSaveMenu();return false}
 activeMapId=s.map;$('challenge').value=s.values.runChallenge;reset();refreshMapArt();world=migrateLivingGrid53(s.world);restoreLivingWorld53(s.living);player={...s.player};inventory=s.inventory.map(w=>({...w}));slot=s.slot;ownedPerks.clear();s.perks.forEach(p=>ownedPerks.add(p));renderPerkHud.key=null;
 ({flashlightOn,time,round,points,killCount,power,boost,linked,linking,linkTime,teleCooldown,fastReload,doubleTap,trapTime,trapCooldown,boxTime,boxLife,boxSpins,boxIndex,boxOffer,boxPending,boxPreview,boxLast,boxShuffle,dogRound,nextRound,remaining,spawnClock,fragCount,tacticalCount,stamina,stance,upperUnlocked,fuses,questDone,runChallenge,runStats,depotState,fieldTask}=s.values);
 s.windows.forEach((w,i)=>Object.assign(windows[i],w));Object.assign(stations.find(n=>n.type==='box'),s.box);zombies=s.zombies.map(({waitIndex,...z})=>({...z,wait:waitIndex>=0?windows[waitIndex]:null,nextGroan:time+Math.random()*3,attackElapsed:null,attackContact:false}));drops=s.drops.map(d=>({...d}));grenades=s.grenades.map(g=>({...g}));
 playerMotionStart=null;playerHitGraceUntil=0;stanceEye=stance===2?.28:stance===1?.53:.82;player.cameraBase=actorElevation(player);reloading=0;attackClock=shotClock=0;burstRemaining=0;meleePendingHit=false;fire=mouseFire=false;aim=mouseAim=false;keys={};navCache=null;navDistances=null;pathClock=0;mapRevision++;reconcileFlowSave();runSaveClock=15;$('map-choice').value=activeMapId;$('lobby-region').textContent=mapCatalog[activeMapId].region;$('map-description').textContent=mapCatalog[activeMapId].description;$('map-forge').textContent=mapCatalog[activeMapId].forge;$('lobby-route').textContent=mapCatalog[activeMapId].forge;$('map-doors').textContent=mapCatalog[activeMapId].doors;$('challenge').disabled=true;mode='paused';syncSignalLobby();signalSeen={power,forge:forgeReady(),round};if(!defer){uiShow(Screens.PAUSED);start(fromController)}updateHud();banner('RUN RESTORED · ROUND '+round);return true;
}
function saveAndQuit(){if(mode==='playing')pause();if(mode!=='paused')return;if(!saveCurrentRun()){tell(runSaveNotice);return}reset();returnMain()}


function weapon(){return inventory[slot]}function tell(t){$('toast').textContent=t;toastTime=2.5}function banner(t,d=3){$('banner').textContent=t;bannerTime=d}

// Explicit presentation state, separate from the preserved match simulation mode.
const Screens=Object.freeze({MAIN:'MAIN_MENU',LOBBY:'SINGLE_PLAYER_LOBBY',LOADING:'LOADING',PLAYING:'PLAYING',PAUSED:'PAUSED',OVER:'GAME_OVER'});
const ui={screen:Screens.MAIN,layer:'root',returnTo:Screens.MAIN,dialog:null,loading:null,serial:0,clock:0,renderKey:'',lastLobbyRender:-1,inputController:false,exiting:false};
const screenIds={[Screens.MAIN]:'main-screen',[Screens.LOBBY]:'lobby-screen',[Screens.LOADING]:'loading-screen',[Screens.PAUSED]:'pause-screen',[Screens.OVER]:'gameover-screen'};
let menuAudioVoice=null,menuAudioScreen='',menuAudioClock=0,menuNavClock=0;
function clearGameplayInput(){keys={};fire=mouseFire=false;aim=mouseAim=false;controllerSprint=false;useHoldTime=0;useHoldConsumed=false;controllerFrame=null;controllerPrevious={};controllerIgnoreUntilRelease=!!sampleController()?.buttons.some(b=>b.pressed||b.value>.5)}
function stopMenuAudio(){if(menuAudioVoice){try{menuAudioVoice.src.stop()}catch{}menuAudioVoice.src.disconnect();menuAudioVoice.g.disconnect();menuAudioVoice=null}menuAudioScreen=''}
function menuTone(){if(ac&&$('sound').checked&&ui.clock-menuNavClock>.09){menuNavClock=ui.clock;sound(430,.035,.008,'sine')}}
function startMenuAudio(){if(!ac||!$('sound').checked||![Screens.MAIN,Screens.LOBBY].includes(ui.screen)){stopMenuAudio();return}if(menuAudioVoice&&menuAudioScreen===ui.screen)return;stopMenuAudio();try{let duration=4,b=ac.createBuffer(1,Math.floor(ac.sampleRate*duration),ac.sampleRate),a=b.getChannelData(0),base=ui.screen===Screens.MAIN?47:63;for(let i=0;i<a.length;i++){let t=i/ac.sampleRate;a[i]=Math.sin(t*2*Math.PI*base)*.19+Math.sin(t*2*Math.PI*(base*2))*.025+(Math.random()-.5)*.045}let src=ac.createBufferSource(),g=ac.createGain();src.buffer=b;src.loop=true;g.gain.value=ui.screen===Screens.MAIN?.018:.012;src.connect(g);g.connect(ac.destination);src.start();menuAudioVoice={src,g};menuAudioScreen=ui.screen;menuAudioClock=18}catch{stopMenuAudio()}}
function updateMenuAudio(dt){if(!ac||!$('sound').checked||document.hidden||ui.exiting||![Screens.MAIN,Screens.LOBBY].includes(ui.screen)){stopMenuAudio();return}startMenuAudio();menuAudioClock-=dt;if(menuAudioClock<=0){menuAudioClock=20+Math.random()*12;if(spatialVoices.length===0)playSpatial(signalRadioBuffer(),player,.013,ui.screen===Screens.MAIN?.82:1.05)}}
function uiShow(screen,layer='root'){
 ui.screen=screen;ui.layer=layer;ui.exiting=false;ui.renderKey='';ui.lastLobbyRender=-1;ui.dialog=null;mode=screen===Screens.PLAYING?'playing':screen===Screens.PAUSED?'paused':screen===Screens.OVER?'dead':screen===Screens.LOADING?'loading':'menu';
 for(let[id,element]of Object.entries(screenIds)){$(element).hidden=screen!==id||layer!=='root';$(element).inert=false}$('settings-screen').hidden=layer==='root';$('menu-play-panel').hidden=screen!==Screens.LOBBY||layer!=='root';$('dialog-screen').hidden=true;$('overlay').style.display=screen===Screens.PLAYING?'none':'flex';$('overlay').setAttribute?.('data-screen',screen);$('overlay').setAttribute?.('data-layer',layer);$('hud').style.display=screen===Screens.PLAYING?'block':'none';
 menuHighlight(null);menuWasOpen=false;menuPrevious={};menuRepeat=.2;if(screen!==Screens.PLAYING)clearGameplayInput();stopMenuAudio();if([Screens.MAIN,Screens.LOBBY].includes(screen))startMenuAudio();else stopAtmosphere();refreshSaveMenu();if(screen===Screens.LOBBY){$('challenge').disabled=false;refreshPreparation();}
}
function openSinglePlayer(){if(mode==='playing')return;uiShow(Screens.LOBBY);syncSignalLobby()}
function returnMain(){if(mode==='dead')reset();ui.serial++;ui.loading=null;stopGunReports();stopGroans();stopMenuAudio();clearGameplayInput();document.exitPointerLock?.();uiShow(Screens.MAIN)}
function refreshPreparation(){
 const map=mapCatalog[activeMapId];$('map-choice').value=activeMapId;for(let id of['blackridge','railyard'])$('map-'+id).setAttribute?.('aria-pressed',String(id===activeMapId));$('operation-preview').setAttribute?.('data-map',activeMapId);$('operation-preview').setAttribute?.('aria-label',map.name+' actual map preview');$('lobby-region').textContent=map.region;$('lobby-state').textContent='Prepare for deployment';$('intro').textContent=signalLore[activeMapId].intro;$('map-description').textContent=map.description;$('map-forge').textContent=map.forge;$('lobby-route').textContent=map.forge;$('map-doors').textContent=map.doors;$('start').textContent='START GAME →';$('starter-name').textContent=guns.pistol.name;$('starter-ammo').textContent=guns.pistol.cap+' / '+guns.pistol.max;showRecords();
}
function chooseOperation(id){if(ui.screen!==Screens.LOBBY||ui.layer!=='root'||!mapCatalog[id])return;selectMap(id);uiShow(Screens.LOBBY);syncSignalLobby();menuTone()}
function openSettings(tab='graphics'){
 if(mode==='playing')pause();if(ui.screen===Screens.LOADING)return;ui.returnTo=ui.screen;ui.layer=tab;$('overlay').setAttribute?.('data-layer',tab);for(let id of Object.values(screenIds))$(id).hidden=true;$('settings-screen').hidden=false;$('settings-screen').setAttribute?.('data-origin',ui.screen);for(let key of['play','briefing','graphics','controller'])$('menu-'+key+'-panel').hidden=key!==tab;for(let key of['briefing','graphics','controller'])$('menu-'+key).setAttribute?.('aria-selected',String(key===tab));$('settings-title').textContent=tab==='briefing'?'Operation briefing':tab==='controller'?'Controls':'Settings';$('dialog-screen').hidden=true;menuHighlight(null);menuWasOpen=false;
}
function closeSettings(){uiShow(ui.returnTo);if(ui.returnTo===Screens.PAUSED)updatePauseInfo()}
function sessionTime(){let secs=Math.max(0,Math.floor(time));return Math.floor(secs/60).toString().padStart(2,'0')+':'+(secs%60).toString().padStart(2,'0')}
function uiDefaultControl(){return ui.dialog?'dialog-cancel':ui.layer!=='root'?'settings-back':ui.screen===Screens.MAIN?'main-single':ui.screen===Screens.LOBBY?'start':ui.screen===Screens.PAUSED?'resume-game':ui.screen===Screens.OVER?'over-restart':null}
function menuKeyboard(e){
 if(typeof document.querySelectorAll!=='function'||!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Enter','Space','Tab'].includes(e.code))return false;let controls=menuControls();if(!controls.length)return false;
 if(e.code==='Tab'&&!ui.dialog)return false;if(controls.includes(document.activeElement))menuSelection=document.activeElement;if(!controls.includes(menuSelection))menuHighlight(controls.find(el=>el.id===uiDefaultControl())||controls[0]);
 if(['Enter','Space'].includes(e.code)&&menuSelection?.tagName==='SELECT')return false;e.preventDefault();
 if(e.code==='Tab'){let i=controls.indexOf(menuSelection),dir=e.shiftKey?-1:1;menuHighlight(controls[(i+dir+controls.length)%controls.length]);menuTone()}
 else if(e.code.startsWith('Arrow')){menuNavigate(e.code.slice(5).toLowerCase());menuTone()}
 else if(menuSelection?.tagName==='BUTTON'){if(!activateMenu(menuSelection.id,false))menuSelection.click()}
 else if(menuSelection?.tagName==='SUMMARY')menuSelection.parentElement.open=!menuSelection.parentElement.open;else menuChange(menuSelection,1);return true;
}
function updatePauseInfo(){for(let prefix of['pause','over']){$(prefix+'-map').textContent=mapCatalog[activeMapId].name;$(prefix+'-round').textContent=round;$(prefix+'-kills').textContent=killCount;$(prefix+'-points').textContent=Math.floor(points).toLocaleString();$(prefix+'-time').textContent=sessionTime()}}
function showConfirm(action){if(ui.screen!==Screens.PAUSED&&ui.screen!==Screens.OVER)return;ui.dialog=action;for(let id of Object.values(screenIds))$(id).inert=true;$('dialog-title').textContent=action==='restart'?'RESTART MATCH?':'QUIT TO MAIN MENU?';$('dialog-copy').textContent=action==='restart'?'This run will end. A fresh match starts on '+mapCatalog[activeMapId].name+'.':mode==='paused'?'Your current run will be saved on this device so you can continue later.':'Return to the main menu. Your run record has been saved.';$('dialog-confirm').textContent=action==='restart'?'RESTART MATCH':'QUIT TO MAIN MENU';$('dialog-screen').hidden=false;menuHighlight(null);menuWasOpen=false;}
function cancelConfirm(){ui.dialog=null;for(let id of Object.values(screenIds))$(id).inert=false;$('dialog-screen').hidden=true;menuHighlight(null);menuWasOpen=false}
function confirmAction(fromController=false){let action=ui.dialog;if(!action)return;cancelConfirm();if(action==='restart'){try{localStorage.removeItem(RUN_SAVE_KEY)}catch{}beginMatchLoad({map:activeMapId,controller:fromController,restart:true})}else{if(mode==='paused'&&!saveCurrentRun()){showConfirm('quit');$('dialog-copy').textContent=runSaveNotice+' Your run is still paused.';return}saveRunRecord();reset();returnMain()}}
function requestGamePointer(){try{let r=cv.requestPointerLock();r?.catch?.(()=>tell('Mouse capture unavailable — drag to look, or use a controller.'))}catch{tell('Drag to look, or use a controller.')}}
function beginMatchLoad({map=activeMapId,restore=false,controller=false,restart=false}={}){
 if(ui.loading||mode==='playing'||(!restart&&ui.screen!==Screens.LOBBY&&ui.screen!==Screens.MAIN&&ui.screen!==Screens.OVER))return false;let snapshot=restore?readSavedRun():null;if(restore&&!snapshot){tell('No compatible saved run found');refreshSaveMenu();return false}
 ui.inputController=controller;ui.loading={token:++ui.serial,map:snapshot?.map||map,restore,phase:0,clock:0};stopGunReports();stopGroans();stopIncidentalAudio();stopMenuAudio();uiShow(Screens.LOADING);$('loading-map').textContent=mapCatalog[ui.loading.map].name;$('loading-caption').textContent='Receiving operation data';$('loading-fill').style.width='0%';$('loading-track').setAttribute?.('aria-valuetext','Receiving operation data');initAudio();if(!controller)requestGamePointer();return true;
}
function updateLoading(dt){
 let load=ui.loading;if(!load||ui.screen!==Screens.LOADING)return;load.clock+=dt;
 if(load.phase===0){load.phase=1;return}
 if(load.phase===1){
  if(load.restore){if(!restoreSavedRun(load.controller,true)){ui.loading=null;returnMain();return}}else{activeMapId=load.map;reset();refreshMapArt()}
  mode='loading';calcFlow();pathClock=.45;$('loading-caption').textContent='Preparing '+mapCatalog[activeMapId].name;$('loading-fill').style.width='66%';$('loading-track').setAttribute?.('aria-valuetext','Map and navigation initialized; preparing renderer');load.phase=2;renderGameplay();return;
 }
 if(load.phase===2&&(!solidRenderer||solidRenderer.ready?.()!==false||load.clock>8)){load.phase=3;$('loading-caption').textContent='Operation ready';$('loading-fill').style.width='100%';$('loading-track').setAttribute?.('aria-valuetext','Operation ready');return}
 if(load.phase===3){ui.loading=null;clearGameplayInput();uiShow(Screens.PLAYING);last=0;signalSeen={power,forge:forgeReady(),round};updateHud();banner(load.restore?'RUN RESTORED · ROUND '+round:mapCatalog[activeMapId].region);}
}
function uiBack(fromController=false){
 if(ui.dialog){cancelConfirm();return}if(ui.layer!=='root'){if(controllerCalibration){controllerCalibration=null;$('controller-calibration').textContent='Button setup cancelled; previous buttons kept.'}closeSettings();return}
 if(ui.screen===Screens.PAUSED){resumeGame(fromController);return}if(ui.screen===Screens.LOBBY){returnMain();return}if(ui.screen===Screens.LOADING){let loaded=ui.loading?.phase>1;ui.serial++;ui.loading=null;if(loaded)reset();document.exitPointerLock?.();uiShow(Screens.LOBBY);return}if(ui.screen===Screens.OVER)returnMain();
}
function activateMenu(id,fromController=false){
 ui.inputController=fromController;if(id!=='main-exit')ui.exiting=false;initAudio();menuTone();switch(id){case'main-single':openSinglePlayer();break;case'main-continue':case'continue-run':beginMatchLoad({restore:true,controller:fromController});break;case'start':beginMatchLoad({controller:fromController});break;case'resume-game':resumeGame(fromController);break;case'pause-restart':case'over-restart':showConfirm('restart');break;case'pause-quit':showConfirm('quit');break;case'over-main':returnMain();break;case'dialog-confirm':confirmAction(fromController);break;case'dialog-cancel':cancelConfirm();break;case'lobby-back':returnMain();break;case'settings-back':uiBack(fromController);break;case'main-settings':case'pause-settings':case'lobby-settings':case'menu-graphics':openSettings('graphics');break;case'main-controls':case'pause-controls':case'lobby-controls':case'menu-controller':openSettings('controller');break;case'lobby-briefing':case'menu-briefing':openSettings('briefing');break;case'menu-play':closeSettings();break;case'map-blackridge':chooseOperation('blackridge');break;case'map-railyard':chooseOperation('railyard');break;case'main-exit':ui.exiting=true;stopMenuAudio();stopAtmosphere();stopIncidentalAudio();$('main-exit-note').hidden=false;$('main-exit-note').textContent='Close this browser tab or app window to exit. Saved runs and settings remain on this device.';break;default:return false}return true;
}
function resumeGame(fromController=false){if(mode!=='paused'||ui.dialog||ui.layer!=='root')return false;stopMenuAudio();clearGameplayInput();uiShow(Screens.PLAYING);initAudio();last=0;if(!fromController&&!locked)requestGamePointer();return true}
let weatherAudioBuffer=null,weatherAudioNext=26;
function weatherRumbleBuffer(){
 if(weatherAudioBuffer)return weatherAudioBuffer;let duration=3.8,b=ac.createBuffer(1,Math.ceil(ac.sampleRate*duration),ac.sampleRate),samples=b.getChannelData(0),low=0;
 for(let i=0;i<samples.length;i++){let t=i/ac.sampleRate;low=low*.985+(Math.random()-.5)*.015;samples[i]=low*Math.sin(Math.PI*t/duration)**2*.70}weatherAudioBuffer=b;return b;
}
function updateWeatherAudio(dt){
 if(!ac||ui.exiting||ui.layer!=='root'||!$('sound').checked||!$('weather').checked||Number($('cinematic-effects').value)<1||document.hidden||![Screens.MAIN,Screens.PLAYING].includes(ui.screen))return;
 if(ui.screen===Screens.PLAYING&&[...districtRooms,...interiorZones].some(r=>player.x>=r.x0&&player.x<=r.x1+1&&player.y>=r.y0&&player.y<=r.y1+1))return;
 weatherAudioNext-=dt;if(weatherAudioNext<=0){weatherAudioNext=26+Math.random()*18;if(spatialVoices.length<4)playSpatial(weatherRumbleBuffer(),{x:player.x+8,y:player.y+5},.025,1)}
}
function updateScreens(dt){ui.clock+=dt;updateLoading(dt);updateMenuAudio(dt);updateWeatherAudio(dt)}
function renderScreen(){
 if(ui.screen===Screens.LOADING){ctx.clearRect(0,0,W,H);return}
 if(ui.screen===Screens.MAIN){ctx.clearRect(0,0,W,H);if(ui.clock-ui.lastLobbyRender<.05)return;ui.lastLobbyRender=ui.clock;ensureRenderer();let rendered=false;if($('renderer-mode').value==='3d'&&solidRenderer?.drawTitleScene)try{rendered=solidRenderer.drawTitleScene(ui.clock)}catch{}$('overlay').setAttribute?.('data-renderer',rendered?'3d':'fallback');return}
 if(ui.screen===Screens.LOBBY){$('overlay').setAttribute?.('data-renderer',$('renderer-mode').value==='3d'?'3d':'fallback');if(ui.clock-ui.lastLobbyRender<.05)return;ui.lastLobbyRender=ui.clock;ensureRenderer();if(!solidRenderer)$('overlay').setAttribute?.('data-renderer','fallback');if($('renderer-mode').value==='3d'&&solidRenderer?.drawLobby){try{solidRenderer.drawLobby(ui.clock)}catch{}}return}
 let key=ui.screen+':'+W+':'+H+':'+fovDegrees+':'+$('renderer-mode').value;if(ui.screen!==Screens.PLAYING&&ui.renderKey===key)return;ui.renderKey=key;renderGameplay();
}
function setupCinematicSettings(){for(let id of ['cinematic-effects','weather','reduced-flashes','visual-preset']){let element=$(id),key='dead-signal-visual-'+id,value=localStorage.getItem(key);if(value!==null){if(id==='cinematic-effects')element.value=['0','1','2'].includes(value)?value:'1';else if(id==='visual-preset')element.value=['0','1','2','3'].includes(value)?value:'2';else element.checked=value==='true'}element.addEventListener?.('change',()=>{localStorage.setItem(key,['cinematic-effects','visual-preset'].includes(id)?element.value:String(element.checked));ui.renderKey=''})}}
function setupGameScreens(){setupCinematicSettings();setupMinimapSettings();
 for(let id of['main-single','main-continue','main-settings','main-controls','main-exit','start','continue-run','resume-game','pause-settings','pause-controls','pause-restart','pause-quit','over-restart','over-main','dialog-confirm','dialog-cancel','lobby-back','settings-back','lobby-settings','lobby-controls','lobby-briefing','menu-briefing','menu-graphics','menu-controller','menu-play','map-blackridge','map-railyard'])$(id).onclick=()=>activateMenu(id,false);
 $('map-choice').onchange=()=>chooseOperation($('map-choice').value);$('sound').addEventListener?.('change',()=>{if(!$('sound').checked){stopMenuAudio();stopAtmosphere()}else startMenuAudio()});document.addEventListener?.('visibilitychange',()=>{if(document.hidden){stopMenuAudio();stopAtmosphere()}});uiShow(Screens.MAIN);
}

const fieldReports={
 blackridge:[{room:'cafe',title:'EVACUATION INTERRUPTED',kind:'notice',text:'Civil Defense / 02:17: The evacuation order ended mid-sentence. Witnesses reported the same voice coming from disconnected receivers. Stay off the emergency band.'},{room:'hardware',title:'MISSING / LAST CONTACT',kind:'missing',text:'Blackridge clinic: staff vanished after answering a broadcast addressed to them by name. The receiver log contains no incoming station identifier.'},{room:'courier',title:'RESTRICTED BROADCAST',kind:'monitor',text:'Parcel exchange / incident fragment: The research courier arrived before the blackout. The sealed case was never collected. Its radio remained active after its battery was removed.'}],
 railyard:[{room:'cargo',title:'SIGNAL EVENT ZERO',kind:'report',text:'Research Division / fragment 04: The carrier responds to recorded speech with unfamiliar replies. Cause, origin and relationship to the infected remain unconfirmed.'},{room:'dispatch',title:'NO OUTBOUND TRAFFIC',kind:'monitor',text:'Dispatch log / 02:19: Evacuation train held. All outbound orders replaced by the same repeating transmission. No operator admits sending it.'},{room:'induction',title:'CONTAINMENT FAILURE',kind:'warning',text:'Induction maintenance / unsigned: Do not bypass cooling during carrier synchronization. Last recorded personnel count is incomplete. The containment order ends with an unknown callsign.'}]
};
let reportPlanCache={key:'',items:[]};
function environmentReports(){
 let key=activeMapId+':'+mapRevision;if(reportPlanCache.key===key)return reportPlanCache.items;let items=[];
 for(let report of fieldReports[activeMapId]){let r=districtRooms.find(r=>r.id===report.room);if(!r)continue;let dx=r.front==='east'?1:-1,cx=dx>0?r.x1:r.x0,candidates=[];
  for(let cy=r.y0+1;cy<r.y1;cy++){if(world[cy]?.[cx]!==1)continue;let x=dx>0?cx+1.025:cx-.025,y=cy+.5,approach={x:x+dx*.65,y};if(inFireEscape(approach.x,y)||!groundCanMove(approach.x,y,.22)||stations.some(n=>Math.hypot(n.x-approach.x,n.y-approach.y)<1.7)||gates.some(g=>Math.hypot(g.x-approach.x,g.y-approach.y)<1.8))continue;if(gates.some(g=>g.cells.some(([a,b])=>Math.hypot(a-cx,b-cy)<1.45))||wallFixtures.some(f=>f.mx===cx&&Math.abs(f.my-cy)<1.1))continue;candidates.push({x,y,dx,dy:0,cx,cy,approach,score:Math.abs(cy-(r.y0+r.y1)/2)})}
  // Tight urban facades keep their door/window clearances. Use a backed interior
  // wall instead when no exterior face has a clear approach.
  if(!candidates.length)for(let side of ['west','east','north','south'])for(let i=1;i<(side==='west'||side==='east'?r.y1-r.y0:r.x1-r.x0);i++){
   let vertical=side==='west'||side==='east',cx=vertical?(side==='west'?r.x0:r.x1):r.x0+i,cy=vertical?r.y0+i:(side==='north'?r.y0:r.y1),nx=side==='west'?1:side==='east'?-1:0,ny=side==='north'?1:side==='south'?-1:0;
   if(world[cy]?.[cx]!==1)continue;let x=nx>0?cx+1.025:nx<0?cx-.025:cx+.5,y=ny>0?cy+1.025:ny<0?cy-.025:cy+.5,approach={x:x+nx*.65,y:y+ny*.65};
   if(!groundCanMove(approach.x,approach.y,.22)||stations.some(n=>Math.hypot(n.x-approach.x,n.y-approach.y)<1.7)||gates.some(g=>Math.hypot(g.x-approach.x,g.y-approach.y)<1.8)||gates.some(g=>g.cells.some(([a,b])=>Math.hypot(a-cx,b-cy)<1.45))||wallFixtures.some(f=>Math.hypot(f.mx-cx,f.my-cy)<1.1))continue;candidates.push({x,y,dx:nx,dy:ny,cx,cy,approach,score:i});
  }
  candidates.sort((a,b)=>a.score-b.score);if(candidates[0])items.push({...report,...candidates[0],type:'intel',label:'READ '+report.title,cost:0});
 }
 reportPlanCache={key,items};return items;
}
function nearestIntelClue(){if(actorElevation(player)>.3)return null;return environmentReports().filter(p=>Math.hypot(p.approach.x-player.x,p.approach.y-player.y)<1.25&&visibleBetween(player.x,player.y,p.approach.x,p.approach.y)).sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y))[0]||null}
function reportGraphic(p){
 let key='report:'+activeMapId+':'+p.title;if(equipmentArt.has(key))return equipmentArt.get(key);let c=document.createElement('canvas');c.width=400;c.height=560;let t=c.getContext('2d'),monitor=p.kind==='monitor';t.fillStyle=monitor?'#101e22':p.kind==='warning'?'#423b30':'#a6a28f';t.fillRect(0,0,400,560);t.strokeStyle=monitor?'#67868b':'#565a52';t.lineWidth=7;t.strokeRect(5,5,390,550);t.fillStyle=monitor?'#92b4b0':'#253237';t.font='bold 17px Arial';t.fillText(monitor?'EMERGENCY RX / CARRIER LOST':'WARDEN / FIELD RECORD',22,42);t.fillStyle=p.kind==='warning'?'#e0b88b':monitor?'#cfdbd7':'#17272d';t.font='bold 27px Arial';let words=p.title.split(' '),line='',y=94;for(let word of words){let next=line+(line?' ':'')+word;if(next.length>19){t.fillText(line,22,y);line=word;y+=36}else line=next}t.fillText(line,22,y);
 if(p.kind==='missing'){t.fillStyle='#5e645f';t.beginPath();t.arc(200,233,45,0,Math.PI*2);t.fill();t.fillRect(150,280,100,84);t.strokeStyle='#676b5f';t.lineWidth=3;t.strokeRect(108,172,184,213)}else if(monitor){t.strokeStyle='#91bcb1';t.lineWidth=3;t.beginPath();for(let x=28;x<370;x++){let yy=268+Math.sin(x*.14)*Math.cos(x*.051)*29;x===28?t.moveTo(x,yy):t.lineTo(x,yy)}t.stroke();t.fillStyle='#719799';t.font='19px Arial';t.fillText('STATION ID: UNKNOWN',28,365)}else{t.fillStyle='#384845';t.font='bold 17px Arial';t.fillText('INCIDENT / 02:17',24,220);for(let i=0;i<6;i++){t.fillStyle=i===2||i===4?'#263733':'#6c776c';t.fillRect(25,258+i*25,i===2?264:320-i*11,8)}}
 t.fillStyle=monitor?'#83a4ad':'#293c41';t.font='16px Arial';t.fillText('READ FIELD REPORT / E',22,510);equipmentArt.set(key,c);return c;
}

// Cosmetic narrative cues read existing progression; they never unlock doors or grant rewards.
let signalRadioClock=18,signalMessageTime=0,signalSeen={power:false,forge:false,round:0};
function syncSignalLobby(){
 const lore=signalLore[activeMapId];$('signal-frequency').textContent=lore.frequency;$('signal-band-status').textContent=lore.band+' / CARRIER UNIDENTIFIED';$('briefing-map-name').textContent=mapCatalog[activeMapId].name+' / '+lore.band;$('briefing-map-story').textContent=lore.story;$('briefing-map-route').textContent=lore.route;
 if(mode==='menu')$('intro').textContent=lore.intro;
}
function resetSignalAtmosphere(){signalRadioClock=18;signalMessageTime=0;signalSeen={power:false,forge:false,round:0};$('signal-transmission').style.opacity='0';$('signal-message').textContent='';}
function signalDispatch(text,duration=6){$('signal-channel').textContent='RX '+signalLore[activeMapId].frequency+' MHz / '+signalLore[activeMapId].band;$('signal-message').textContent=text;signalMessageTime=duration;$('signal-transmission').style.opacity='1';}
function signalRadioBuffer(){
 if(spatialBuffers.radio)return spatialBuffers.radio;let duration=.82,b=ac.createBuffer(1,Math.ceil(ac.sampleRate*duration),ac.sampleRate),a=b.getChannelData(0),low=0,phase=0;
 for(let i=0;i<a.length;i++){let t=i/ac.sampleRate,n=Math.random()*2-1;low+=.13*(n-low);let index=Math.floor(t/.11),pulse=index<6&&t%(.11)<.058,frequency=[620,790,620,510,790,510][index]||620;phase+=2*Math.PI*frequency/ac.sampleRate;let envelope=Math.min(1,t/.015)*Math.min(1,(duration-t)/.07);a[i]=((n-low)*.15*Math.exp(-t*2)+Math.sin(phase)*(pulse?.15:.012))*envelope*.38;}return spatialBuffers.radio=b;
}
function updateSignalAtmosphere(dt){
 signalMessageTime=Math.max(0,signalMessageTime-dt);$('signal-transmission').style.opacity=signalMessageTime>0?String(Math.min(1,signalMessageTime)):'0';
 let ready=forgeReady();
 if(power&&!signalSeen.power)signalDispatch(activeMapId==='railyard'?'Relay power restored. Open the three coolant lines, then synchronize the induction hall.':'Civil band recovered. Link the three teleporters at the command relay.');
 else if(ready&&!signalSeen.forge)signalDispatch('Carrier synchronized. Forge-a-Punch is online. The source is still transmitting.');
 else if(round!==signalSeen.round&&round>0){if(dogRound)signalDispatch('Perimeter alert: hound wave incoming.',4);else if(round===1)signalDispatch(signalLore[activeMapId].firstTransmission,7)}
 signalSeen={power,forge:ready,round};signalRadioClock-=dt;
 if(signalRadioClock<=0){signalRadioClock=22+Math.random()*13;if(ac&&power&&$('sound').checked&&groanVoices.length<2){let receiver=stations.find(s=>s.type==='power'),d=receiver?Math.hypot(receiver.x-player.x,receiver.y-player.y):99;if(d<5&&(player.level||0)===0)playSpatial(signalRadioBuffer(),receiver,.035,1)}}
}
function communicationPanel(type='power'){
 const key='comms-panel:'+activeMapId+':'+type;if(equipmentArt.has(key))return equipmentArt.get(key);
 const c=document.createElement('canvas');c.width=512;c.height=192;let t=c.getContext('2d');t.fillStyle='#0c171c';t.fillRect(0,0,512,192);t.strokeStyle='#738c94';t.lineWidth=3;t.strokeRect(3,3,506,186);t.textAlign='left';t.fillStyle='#d7c09b';t.font='bold 18px Arial';t.fillText(type==='power'?'WARDEN SIGNAL CORPS':'UPLINK / CARRIER SYNC',22,31);t.fillStyle='#8da8ac';t.font='12px Arial';t.fillText('DEAD SIGNAL · '+signalLore[activeMapId].frequency+' MHz',22,53);t.strokeStyle='#8ec0b5';t.lineWidth=2;t.beginPath();for(let x=20;x<491;x++){let amplitude=6+17*Math.exp(-Math.pow((x-260)/65,2)),y=117+Math.sin(x*.085)*Math.sin(x*.021)*amplitude;x===20?t.moveTo(x,y):t.lineTo(x,y)}t.stroke();t.fillStyle='#657f89';t.font='11px Arial';t.fillText('RX / MONITORING CARRIER',22,171);equipmentArt.set(key,c);return c;
}

// Bounded combat effects and browser-local run records.
let corpses=[],impactMarks=[],muzzleSmoke=[],damageBearing=0,damageBearingTime=0,reloadStage=-1,ambientClock=3,heartbeatClock=0;
let runChallenge='standard',runStats={},records={},fuses=[false,false,false],questDone=false;
try{let saved=JSON.parse(localStorage.getItem('dead-frequency-records-v1')||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))records=saved}catch(e){}
function resetEnhancements(){clearCombat52();radarPulseUntil=0;radarLastAlert=-100;adsBlend=0;corpses=[];impactMarks=[];muzzleSmoke=[];damageBearingTime=0;reloadStage=-1;ambientClock=3;runChallenge=['standard','pistol','no-perks'].includes($('challenge').value)?$('challenge').value:'standard';runStats={shots:0,hits:0,headshots:0,kills:0,weaponKills:{}};fuses=[false,false,false];questDone=false;$('challenge').disabled=true}
function favoriteWeapon(stats){let pairs=Object.entries(stats.weaponKills||{}).filter(([type,n])=>guns[type]&&Number.isFinite(n));pairs.sort((a,b)=>b[1]-a[1]);return pairs.length?guns[pairs[0][0]].name:'—'}
function saveRunRecord(){let recordKey=activeMapId==='blackridge'?runChallenge:activeMapId+':'+runChallenge,old=records[recordKey]||{};records[recordKey]={bestRound:Math.max(Number(old.bestRound)||0,round),bestKills:Math.max(Number(old.bestKills)||0,killCount),bestHeadshots:Math.max(Number(old.bestHeadshots)||0,runStats.headshots),last:{round,kills:killCount,headshots:runStats.headshots,accuracy:runStats.shots?Math.min(100,Math.round(runStats.hits/runStats.shots*100)):0,favorite:favoriteWeapon(runStats)}};try{localStorage.setItem('dead-frequency-records-v1',JSON.stringify(records))}catch(e){}showRecords()}
function showRecords(){let modeName=$('challenge').value||'standard',r=records[activeMapId==='blackridge'?modeName:activeMapId+':'+modeName];$('run-records').textContent=r?`BEST ${r.bestRound} ROUNDS · ${r.bestKills} KILLS · ${r.bestHeadshots} HEADSHOT KILLS\nLAST RUN: ${r.last?.accuracy||0}% ACCURACY · FAVORITE: ${r.last?.favorite||'—'}`:'No records yet for this mode. Your progress is saved on this PC.'}
// Original Signal Disruptor simulation. Transient flights/charge are deliberately not saved.
let signalCharge=0,signalCharging=false,signalHeld=false,signalBlocked=false,signalChargeVoice=null;
let signalFlights=[],signalArcs=[],signalImpacts=[],casings52=[],handlingKick=0,combatNotice='',combatNoticeTime=0;
let weaponMuzzleWorld=null,signalAudioBuffers={};
function weaponDisplayName(w=weapon()){return w.type==='signal'&&w.upgraded?'FREQUENCY ZERO':guns[w.type].name}
function signalChargeDuration(w=weapon()){return w.upgraded?1.05:1.4}
function stopSignalChargeAudio(){if(signalChargeVoice){let v=signalChargeVoice;signalChargeVoice=null;try{v.src.stop()}catch{}v.src.disconnect();v.g.disconnect()}}
function cancelSignalCharge(block=true){let held=signalHeld||signalCharging||aim;signalCharge=0;signalCharging=false;signalBlocked=!!block&&held;stopSignalChargeAudio()}
function clearCombat52(){cancelSignalCharge(false);signalHeld=false;signalFlights=[];signalArcs=[];signalImpacts=[];casings52=[];handlingKick=0;weaponMuzzleWorld=null;combatNoticeTime=0}
function signalAudio(kind){
 if(signalAudioBuffers[kind]||!ac)return signalAudioBuffers[kind];
 let duration=kind==='charge'?1:kind==='zero'?.62:kind==='pulse'?.36:.19,b=ac.createBuffer(1,Math.ceil(ac.sampleRate*duration),ac.sampleRate),a=b.getChannelData(0),phase=0,low=0;
 for(let i=0;i<a.length;i++){let t=i/ac.sampleRate,n=Math.random()*2-1;low+=(n-low)*.08;let f=kind==='charge'?120+120*t:kind==='zero'?570*Math.exp(-t*6)+75:kind==='pulse'?870*Math.exp(-t*13)+90:360*Math.exp(-t*9);phase+=2*Math.PI*f/ac.sampleRate;let env=kind==='charge'?.40+.10*Math.sin(t*6.283):Math.exp(-t/(duration*.22));let edge=kind==='charge'?1:Math.min(1,t/.003)*Math.min(1,(duration-t)/.025);a[i]=Math.tanh((Math.sin(phase)*.62+Math.sin(phase*2.013)*.12+low*.28+n*.035)*env)*edge*.65}
 return signalAudioBuffers[kind]=b;
}
function beginSignalChargeAudio(){
 if(!ac||!$('sound').checked||signalChargeVoice)return;
 try{let src=ac.createBufferSource(),g=ac.createGain();src.buffer=signalAudio('charge');src.loop=true;src.playbackRate.value=.8;g.gain.value=.035;src.connect(g);g.connect(ac.destination);signalChargeVoice={src,g};src.start()}catch{stopSignalChargeAudio()}
}
function updateSignalCharge(dt,held){
 let w=weapon(),eligible=w?.type==='signal'&&mode==='playing'&&!reloading&&attackClock<=0&&shotClock<=0;
 if(!held)signalBlocked=false;
 if(!eligible){cancelSignalCharge(!!held);signalHeld=!!held;return}
 if(held&&!signalHeld&&!signalBlocked){if(w.mag<2){tell('CHARGE NEEDS TWO CELLS');signalBlocked=true}else{signalCharging=true;signalCharge=0;beginSignalChargeAudio()}}
 if(held&&signalCharging){let ceiling=w.mag>=(w.upgraded?2:3)?1:.85;signalCharge=Math.min(ceiling,signalCharge+dt/signalChargeDuration(w));if(!$('sound').checked)stopSignalChargeAudio();if(signalChargeVoice){signalChargeVoice.src.playbackRate.value=.8+signalCharge*.65;signalChargeVoice.g.gain.value=.035+signalCharge*.025}}
 if(!held&&signalCharging){let strength=signalCharge;cancelSignalCharge(false);if(strength>=.25)fireSignalPulse(strength)}
 signalHeld=!!held;
}
function signalPoint(z,region='BODY'){return {x:z.x,y:z.y,z:actorElevation(z)+(z.dog?.28:z.crippled?.26:region==='HEAD'?.86:region==='LEGS'?.22:.57)}}
function signalLinkVisible(a,b){return rayClear3D(a.x,a.y,a.z,b.x,b.y,b.z)}
function fireSignalPulse(strength=0){
 let w=weapon(),g=guns[w.type];if(w.type!=='signal'||mode!=='playing'||attackClock>0||reloading||shotClock>0||signalCharging)return false;
 let full=strength>=.99,cost=strength>0?(full&&!w.upgraded?3:2):1;
 if(w.mag<cost){if(strength===0&&w.mag===0&&w.reserve>0)reload();else tell('INSUFFICIENT CELLS');return false}
 let origin=weaponMuzzleWorld&&Math.hypot(weaponMuzzleWorld.x-player.x,weaponMuzzleWorld.y-player.y)<1.5&&Number.isFinite(weaponMuzzleWorld.x+weaponMuzzleWorld.y+weaponMuzzleWorld.z)?{...weaponMuzzleWorld}:{x:player.x+Math.cos(player.a)*.62,y:player.y+Math.sin(player.a)*.62,z:eyeHeight()-.07};
 let candidates=zombies.filter(z=>!z.dead&&!z.wait).map(z=>({z,d:Math.hypot(z.x-player.x,z.y-player.y),region:aimedRegion(z)})).filter(q=>q.region&&q.d<g.range&&shotVisible(q.z)).sort((a,b)=>a.d-b.d);const prop53=traceLivingShot53(g.range);let hit=candidates[0];if(prop53&&(!hit||prop53.distance<hit.d))hit=null;
 let d=hit?hit.d:Math.min(g.range,lineDist(player.a)),end=hit?signalPoint(hit.z,hit.region):prop53?prop53.point:{x:player.x+Math.cos(player.a)*d,y:player.y+Math.sin(player.a)*d,z:Math.max(.03,eyeHeight()+Math.tan(player.pitch||0)*d)};
 w.mag-=cost;runStats.shots++;shotClock=strength>0?1.05:g.rate;weaponShotTime=time;handlingKick=Math.min(1.5,handlingKick+.55);flash=$('reduced-flashes').checked?.02:.05;
 let flight={origin,end,hit:hit?.z,region:hit?.region||'BODY',age:0,duration:Math.max(.045,Math.hypot(end.x-origin.x,end.y-origin.y,end.z-origin.z)/36),strength,full,livingHit53:!hit?prop53?.object.id:null,upgraded:!!w.upgraded,damage:g.damage*(w.upgraded?2.5:1)*(1+strength*2)};
 signalFlights.push(flight);if(signalFlights.length>8)signalFlights.shift();if(ac)playSpatial(signalAudio(w.upgraded&&strength>0?'zero':'pulse'),player,.19,w.upgraded?.83:1);
 return true;
}
function resolveSignalPulse(f){
 let z=f.hit,end=f.end,hit=z&&!z.dead&&!z.wait&&Math.hypot(z.x-end.x,z.y-end.y)<.6&&signalLinkVisible(f.origin,signalPoint(z,f.region));
 signalImpacts.push({x:end.x,y:end.y,z:end.z,age:0,strength:f.strength,upgraded:f.upgraded});if(signalImpacts.length>12)signalImpacts.shift();
 if(f.livingHit53){const prop=livingPlan53().props.find(d=>d.id===f.livingHit53);if(prop&&!livingState53.props[prop.id].destroyed)damageLivingProp53(prop,f.damage,'signal');}
 if(!hit)return;
 runStats.hits++;damageZombie(z,f.damage*(f.region==='HEAD'?1.8:f.region==='LEGS'?.8:1),f.region,'signal');
 hitRegion=f.region==='HEAD'?'SIGNAL HEADSHOT':'SIGNAL HIT';hitRegionTime=.65;
 if(!f.full)return;
 let seen=new Set([z]),previous=signalPoint(z),limit=f.upgraded?7:4,radius=f.upgraded?4.2:3.2;
 for(let hop=1;hop<limit;hop++){
  let next=null,best=radius;
  for(let n of zombies){if(n.dead||n.wait||seen.has(n)||Math.abs(actorElevation(n)-actorElevation(z))>.45)continue;let target=signalPoint(n),d=Math.hypot(target.x-previous.x,target.y-previous.y);if(d<best&&signalLinkVisible(previous,target)){next=n;best=d}}
  if(!next)break;let target=signalPoint(next);seen.add(next);signalArcs.push({a:{...previous},b:{...target},age:0,upgraded:f.upgraded});damageZombie(next,f.damage*Math.pow(.76,hop),'BODY','signal');previous=target;
 }
 if(signalArcs.length>28)signalArcs.splice(0,signalArcs.length-28);
 if(ac)playSpatial(signalAudio('impact'),z,.11,.84);
}
function ejectCasing52(type){
 if(['arc','signal','doublebarrel'].includes(type))return;
 let g=guns[type],side=player.a+Math.PI/2,origin=weaponMuzzleWorld||{x:player.x+Math.cos(player.a)*.35,y:player.y+Math.sin(player.a)*.35,z:eyeHeight()-.11};
 casings52.push({...origin,z:Math.max(.12,origin.z),vx:Math.cos(side)*1.05,vy:Math.sin(side)*1.05,vz:.65,age:0,bounced:false,shell:!!g.pellets||type==='shotgun',seed:Math.random()*6.28,floor:actorElevation(player)});if(casings52.length>24)casings52.shift();
}
function updateCombat52(dt){
 handlingKick*=Math.exp(-dt*10);combatNoticeTime=Math.max(0,combatNoticeTime-dt);
 signalArcs=signalArcs.filter(a=>(a.age+=dt)<.26);signalImpacts=signalImpacts.filter(a=>(a.age+=dt)<.42);
 signalFlights=signalFlights.filter(f=>{f.age+=dt;if(f.age>=f.duration){resolveSignalPulse(f);return false}return true});
 casings52=casings52.filter(c=>{c.age+=dt;if(c.age>2.2)return false;let x=c.x+c.vx*dt,y=c.y+c.vy*dt;c.vz-=3.7*dt;let z=c.z+c.vz*dt;if(worldPointSolid(x,y,z)){c.vx*=-.25;c.vy*=-.25}else{c.x=x;c.y=y}c.z=z;if(c.z<=c.floor+.008){c.z=c.floor+.008;c.vx*=.38;c.vy*=.38;c.vz=c.bounced?0:.23;c.bounced=true}return true});
}
function updateSignalHud(w){
 let shown=w.type==='signal';$('signal-charge').hidden=!shown;$('signal-charge-fill').style.width=(signalCharge*100)+'%';
 $('signal-charge-label').textContent=signalCharging?(signalCharge>=.99?'FULL CHARGE · RELEASE TO CHAIN':Math.round(signalCharge*100)+'% · HOLD TO CHARGE'):reloading?'REPLACING POWER CELL':'RIGHT MOUSE / LT · CHARGE & RELEASE';
 $('signal-charge').setAttribute?.('data-ready',String(signalCharge>=.99));$('combat-pop').textContent=combatNoticeTime>0?combatNotice:'';
}

// Existing Canvas fallback receives the same simulation and an original energy-weapon silhouette.
function signalFallbackGraphic52(){
 let w=weapon(),scale=Math.min(W/720,H/450),anim=weaponMotion('signal',reloading>0?1-reloading/reloadDuration('signal'):-1,time-weaponShotTime),view=weaponViewPose(W,H,scale,false,anim.x,anim.y+anim.kick*8);
 ctx.save();ctx.translate(view.x,view.y);ctx.scale(scale,scale);ctx.rotate(view.angle+anim.angle);
 let metal=ctx.createLinearGradient(-45,0,40,0);for(let[t,c]of[[0,'#172024'],[.25,'#667074'],[.6,'#303b3e'],[1,'#111b1e']])metal.addColorStop(t,c);
 polygon(ctx,[[20,-80],[65,-48],[130,240],[25,240]],'#303d37');polygon(ctx,[[-22,-57],[-58,-25],[-120,240],[-31,240]],'#303d37');
 polygon(ctx,[[-35,-147],[28,-155],[45,-132],[40,-87],[-31,-72],[-48,-109]],metal);
 ctx.fillStyle='#162126';ctx.fillRect(-18,-226,36,81);
 for(let i=0;i<6;i++){let y=-153-i*12;ctx.strokeStyle=i/6<signalCharge?'#84d4e6':'#a39068';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,y,24,7,0,0,Math.PI*2);ctx.stroke()}
 ctx.fillStyle=metal;ctx.fillRect(-27,-238,54,20);ctx.fillStyle='#121b1f';ctx.fillRect(-15,-240,30,9);
 ctx.fillStyle=metal;ctx.fillRect(-15,-91+anim.mag*44,30,53);
 ctx.fillStyle=w.upgraded?'#beddea':'#63acbe';ctx.fillRect(-42,-127,8,22);ctx.fillStyle='#616c67';ctx.fillRect(-24,-40,22,26);ctx.fillRect(23,-66,22,32);
 ctx.restore();weaponMuzzleScreen={x:view.x-Math.sin(view.angle)*(-238)*scale,y:view.y+Math.cos(view.angle)*(-238)*scale};weaponMuzzleWorld={x:player.x+Math.cos(player.a)*.62,y:player.y+Math.sin(player.a)*.62,z:eyeHeight()-.07};
}
function signalFallbackEffects52(){
 const point=p=>{let q=project(p.x,p.y);return {x:q.x,y:horizonY()+q.size*(eyeHeight()-p.z),depth:q.depth}},line=(a,b,alpha)=>{let x=point(a),y=point(b);if(x.depth<.08||y.depth<.08)return;ctx.globalAlpha=alpha;ctx.strokeStyle='#7bd0e3';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x.x,x.y);ctx.lineTo(y.x,y.y);ctx.stroke()};
 ctx.save();for(let a of signalArcs)line(a.a,a.b,(1-a.age/.26)*.65);for(let f of signalFlights){let q=Math.min(1,f.age/f.duration),tail=Math.max(0,q-.04),lerp=t=>Object.fromEntries(['x','y','z'].map(k=>[k,f.origin[k]+(f.end[k]-f.origin[k])*t]));line(lerp(tail),lerp(q),.8)}ctx.restore();
}

function hitFeedback(z,dmg,region){if(time<(z.reactionReady||0))return;z.reactionReady=time+.95;z.reaction=.30;z.attackElapsed=null;z.attackContact=false;z.cooldown=Math.max(z.cooldown||0,.20);z.reactionRegion=region||'BODY';z.stagger=dmg>=100?Math.min(.45,.15+dmg/1600):.08;z.reactionSide=Math.random()<.5?-1:1;let a=Math.atan2(z.y-player.y,z.x-player.x),force=Math.min(.9,.12+dmg/500)*(z.dog?.6:1);z.pushX=Math.cos(a)*force;z.pushY=Math.sin(a)*force;if(region==='HEAD')sound(1050,.055,.022,'sine');if(ac)playSpatial(spatialBuffer('impact'),z,.15,region==='HEAD'?1.3:.8)}
function markWallShot(){let d=lineDist(player.a);if(!solid(player.x+Math.cos(player.a)*d,player.y+Math.sin(player.a)*d))return;let height=eyeHeight()+Math.tan(player.pitch||0)*d;if(height<.02||height>4.5)return;impactMarks.push({x:player.x+Math.cos(player.a)*(d-.04),y:player.y+Math.sin(player.a)*(d-.04),z:height,life:18});if(impactMarks.length>40)impactMarks.shift()}
function updateEnhancements(dt){updateCombat52(dt);adsBlend+=((aim&&weapon().type!=='signal'&&attackClock<=0&&!reloading?1:0)-adsBlend)*Math.min(1,dt*16);damageBearingTime=Math.max(0,damageBearingTime-dt);corpses=corpses.filter(c=>{c.life-=dt;c.age+=dt;return c.life>0});impactMarks=impactMarks.filter(p=>{p.life-=dt;return p.life>0});muzzleSmoke=muzzleSmoke.filter(p=>{p.life-=dt;return p.life>0});for(let z of zombies){z.entryOffset=Math.max(0,(z.entryOffset||0)-dt*.8);if(!z.dead&&(z.pushX||z.pushY)){move(z,(z.pushX||0)*dt,(z.pushY||0)*dt,.19);let damping=Math.exp(-dt*12);z.pushX*=damping;z.pushY*=damping;}z.reaction=Math.max(0,(z.reaction||0)-dt);z.stagger=Math.max(0,(z.stagger||0)-dt)}
if(reloading>0){let w=weapon(),p=1-reloading/(reloadDuration(w.type)),stage=p<.22?0:p<.65?1:2;if(stage>reloadStage){reloadStage=stage;let kind=weaponMotionProfiles[w.type].reload;sound(kind==='cell'?520:stage===1?175:330,.065,stage===1?.035:.025,kind==='cell'?'sine':'triangle',kind!=='cell')}}else reloadStage=-1;
heartbeatClock-=dt;if(player.hp<player.maxhp*.3&&heartbeatClock<=0){heartbeatClock=.85;sound(48,.18,.055,'sine')}ambientClock-=dt;if(ambientClock<=0){ambientClock=4+Math.random()*5;if(power){let st=stations.find(s=>s.type==='power'),d=Math.hypot(st.x-player.x,st.y-player.y);if(d<7)sound(60,.8,.023/(1+d*.3),'sine')}if(Math.random()<.6){sound(85,.13,.012,'triangle',true);sound(125,.22,.008,'triangle')}}}
function drawCombatEffects(){let horizon=horizonY();for(let p of impactMarks){let q=project(p.x,p.y);if(q.depth<.15||q.x<0||q.x>=W||!visibleBetween(player.x,player.y,p.x,p.y))continue;ctx.globalAlpha=Math.min(1,p.life/3);ctx.fillStyle='#141916';ctx.beginPath();ctx.ellipse(q.x,horizon+q.size*(eyeHeight()-p.z),Math.max(1,q.size*.008),Math.max(1,q.size*.012),0,0,Math.PI*2);ctx.fill()}ctx.globalAlpha=1;
if(attackClock<=0&&mode!=='menu'&&$('renderer-mode').value==='3d'&&solidRenderer&&weaponMuzzleScreen){for(let p of muzzleSmoke){let age=.65-p.life;ctx.globalAlpha=p.life*.13;ctx.fillStyle='#b9bdb2';ctx.beginPath();ctx.ellipse(weaponMuzzleScreen.x+p.side*age*25,weaponMuzzleScreen.y-age*60,3+age*15,5+age*20,0,0,Math.PI*2);ctx.fill()}ctx.globalAlpha=1}else if(attackClock<=0&&mode!=='menu'){const scale=Math.min(W/720,H/450),view=weaponViewPose(W,H,scale,aim),len=weaponBarrelLength(weapon().type);ctx.save();ctx.translate(view.x,view.y);ctx.scale(scale,scale);ctx.rotate(view.angle);for(let p of muzzleSmoke){let age=.65-p.life;ctx.globalAlpha=Math.max(0,p.life)*.17;ctx.fillStyle='#b0b7ae';ctx.beginPath();ctx.ellipse(p.side*age*35,-149-len-age*65,5+age*22,8+age*29,.2,0,Math.PI*2);ctx.fill()}ctx.restore()}
if(damageBearingTime>0){let a=damageBearing-player.a,x=W/2+Math.sin(a)*W*.29,y=H/2-Math.cos(a)*H*.29;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.globalAlpha=Math.min(1,damageBearingTime);polygon(ctx,[[-12,7],[0,-8],[12,7],[0,2]],'#e45c42');ctx.restore()}ctx.globalAlpha=1;}

function reset(){playerMotionStart=null;playerHitGraceUntil=0;applySelectedMap();installLivingMap53();resetLivingWorld53();resetMapProgress();fieldTask={target:-1,remaining:0,progress:0,completed:0,available:0};runSaveClock=15;upperUnlocked=false;ownedPerks.clear();renderPerkHud.key=null;burstRemaining=0;burstType=null;semiLatch=false;resetEnhancements();stopGunReports();stopGroans();stopIncidentalAudio();groanClock=.8;weaponShotTime=-100;world=template.map(s=>s.split('').map(Number));resetSignalAtmosphere();player={x:activeMapId==='railyard'?23.5:22,y:41,level:0,cameraBase:0,a:-Math.PI/2,pitch:0,hp:100,maxhp:100,lastHit:-10};inventory=[{type:'pistol',mag:8,reserve:80}];slot=0;zombies=[];drops=[];particles=[];points=500;round=0;killCount=0;power=false;boost=false;linked=[false,false,false];linking=-1;linkTime=0;teleCooldown=0;fastReload=false;doubleTap=false;trapTime=trapCooldown=boxTime=boxLife=boxSpins=boxIndex=lightning=actionCooldown=0;boxOffer=null;boxPending=boxPreview=boxLast=null;boxShuffle=0;dogRound=false;attackClock=shotClock=0;meleePendingHit=false;Object.assign(stations.find(s=>s.type==='box'),boxLocations[0]);reloading=0;nextRound=3;remaining=0;spawnClock=1;time=0;flash=hurt=0;stance=0;stanceEye=.82;controllerSprint=false;useHoldTime=0;useHoldConsumed=false;crouchHoldTime=0;proneConsumed=false;fragCount=4;tacticalCount=2;grenades=[];blasts=[];jumpHeight=jumpVelocity=jumpCooldown=sprintBlend=staminaRecoveryDelay=landingKick=motionPhase=0;stamina=6;sprintExhausted=false;playerMoving=false;hitRegion='';hitRegionTime=0;windows.forEach(w=>{w.boards=6;w.timer=0});flow=[];pathClock=0;banner(mapCatalog[activeMapId].region,3)}reset();
function start(fromController=false){if(mode==='paused')return resumeGame(fromController);return beginMatchLoad({controller:fromController})}
function pause(){if(mode!=='playing')return;cancelSignalCharge(true);saveRunRecord();stopGroans();stopGunReports();stopIncidentalAudio();mode='paused';saveCurrentRun();document.exitPointerLock?.();uiShow(Screens.PAUSED);updatePauseInfo();$('lobby-state').textContent='Take a breath';}
function die(){if(mode==='dead')return;cancelSignalCharge(true);try{localStorage.removeItem(RUN_SAVE_KEY)}catch{};saveRunRecord();$('challenge').disabled=false;stopGunReports();stopGroans();stopIncidentalAudio();high=Math.max(high,round);try{localStorage.setItem('dead-frequency-best',high)}catch{};uiShow(Screens.OVER);updatePauseInfo();document.exitPointerLock?.();$('over-accuracy').textContent=(runStats.shots?Math.round(runStats.hits/runStats.shots*100):0)+'%';$('over-headshots').textContent=runStats.headshots;sound(80,.7,.12)}
addEventListener('keydown',e=>{if(mode==='playing'&&['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab'].includes(e.code))e.preventDefault();if(e.repeat)return;if(e.code==='KeyP'||e.code==='Escape'){if(mode==='playing')pause();else uiBack(false);return}if(mode!=='playing'&&menuKeyboard(e))return;keys[e.code]=true;if(mode!=='playing')return;if(e.code==='Space'){e.preventDefault();jump()}if(e.code==='KeyC')changeStance();if(e.code==='KeyZ'){stance=stance===2?0:2;controllerSprint=false}if(e.code==='KeyF')toggleFlashlight();if(e.code==='KeyG')throwGrenade('frag');if(e.code==='KeyQ')throwGrenade('tactical');if(e.code==='KeyR')reload();if(e.code==='KeyE')interact();if(e.code==='KeyV')melee();if(e.code==='Digit1')switchGun(0);if(e.code==='Digit2')switchGun(1)});addEventListener('keyup',e=>keys[e.code]=false);addEventListener('blur',()=>{if(mode==='playing')pause()});document.addEventListener('visibilitychange',()=>{if(document.hidden&&mode==='playing')pause()});document.addEventListener('pointerlockchange',()=>{locked=document.pointerLockElement===cv;if(!locked&&mode==='playing')pause()});let drag=false;cv.onmousedown=e=>{if(mode!=='playing')return;if(e.button===0){fire=true;mouseFire=true;drag=true}if(e.button===2){aim=true;mouseAim=true}};addEventListener('mouseup',e=>{if(e.button===0){fire=false;mouseFire=false;drag=false}if(e.button===2){aim=false;mouseAim=false}});cv.oncontextmenu=e=>e.preventDefault();addEventListener('mousemove',e=>{if(mode==='playing'&&(locked||drag)){let speed=Number($('sens').value)*.0009*aimLookScale();player.a+=e.movementX*speed;lookVertical(-e.movementY*speed)}});
function switchGun(i){if(attackClock>0)return;if(inventory[i]&&i!==slot){cancelSignalCharge(true);weaponMuzzleWorld=null;burstRemaining=0;burstType=null;semiLatch=false;slot=i;reloading=0;shotClock=.2;sound(140,.1,.035,'triangle')}}
function reloadDuration(type){return (guns[type].shellTime||guns[type].reload)*(fastReload?.55:1)}
function reload(){const w=weapon(),g=guns[w.type];if(mode!=='playing'||attackClock>0||reloading||w.mag>=magazineCapacity(w)||w.reserve===0)return;burstRemaining=0;burstType=null;cancelSignalCharge(true);reloading=reloadDuration(w.type);reloadStage=-1;sound(220,.14,.04,'triangle')}
function lineDist(a){let d=0;while(d<64){d+=.035;if(solid(player.x+Math.cos(a)*d,player.y+Math.sin(a)*d))break}return d}
function damageZombie(z,dmg,region,source){if(z.dead)return;let oldPoints=points,key=region==='HEAD'?'woundHead':region==='LEGS'?'woundLegs':'woundBody';z[key]=Math.min(.8,(z[key]||0)+dmg/Math.max(100,z.max||200)*.35);hitFeedback(z,dmg,source==='melee'?'MELEE':region);z.hp-=dmg;if(region==='LEGS'&&!z.dog&&!z.crippled&&z.hp>0){z.legDamage=(z.legDamage||0)+dmg;if(z.legDamage>=Math.min((z.max||200)*.4,80)){z.crippled=true;z.speed=Math.max(.16,(z.speed||.6)*.42);if(z.variant==='runner')z.variant='walker';tell('LEG INJURY · CRAWLER')}}z.hit=.18;points+=10;hitmark=.14;if(z.hp<=0){z.dead=true;corpses.push({...z,life:7,age:0,deathStyle:Math.floor(Math.random()*3),deathHeading:Math.atan2(player.y-z.y,player.x-z.x)});if(corpses.length>12)corpses.shift();points+=90+(source==='melee'?40:region==='HEAD'?25:0);killCount++;runStats.kills++;if(source){runStats.weaponKills[source]=(runStats.weaponKills[source]||0)+1;if(region==='HEAD')runStats.headshots++}sound(100,.13,.045,'triangle');if(Math.random()<.13)drops.push({x:z.x,y:z.y,type:Math.random()<.55?'ammo':'health',life:18});for(let i=0;i<5;i++)particles.push({x:z.x,y:z.y,z:.3+Math.random(),life:.4,dx:(Math.random()-.5)*2,dy:(Math.random()-.5)*2})}if(particles.length>96)particles.splice(0,particles.length-96);combatNotice=(z.dead?(region==='HEAD'?'HEADSHOT':'ELIMINATION'):'HIT')+' · +'+(points-oldPoints);combatNoticeTime=z.dead?.7:.35;}
function lookVertical(delta){player.pitch=Math.max(-.65,Math.min(.65,(player.pitch||0)+delta))}
function eyeHeight(){return (player.cameraBase??actorElevation(player))+stanceEye+jumpHeight}
function baseFov(){return fovDegrees*Math.PI/180}
function aimLookScale(){return Math.tan(viewFov()/2)/Math.tan(baseFov()/2)}
function viewFov(){let base=baseFov(),scope=guns[weapon()?.type]?.scope||0,target=scope?2*Math.atan(Math.tan(base/2)/scope):base*.78;return base+sprintBlend*.075-(base-target+sprintBlend*.075)*adsBlend}
function jump(){if(mode!=='playing'||jumpHeight>0||jumpVelocity!==0||jumpCooldown>0)return;stance=0;jumpVelocity=1.72;jumpCooldown=.2;sound(115,.08,.025,'triangle')}
function horizonY(){return H/2+Math.tan(player.pitch||0)*W/(2*Math.tan(viewFov()/2))}
// Test the crosshair against the same projected silhouette used by the renderer.
function aimedRegion(z,spread=0){if(typeof solidRenderer!=='undefined'&&solidRenderer&&$('renderer-mode').value==='3d')return typeof characterRayRegion==='function'?characterRayRegion(z,spread):aimedRigRegion(z,spread);let p=project(z.x,z.y);if(p.depth<=.12)return null;let h=p.size*(z.dog?.62:1.02),width=h*(z.dog?1.3:.48),top=horizonY()+p.size*eyeHeight()-h+Math.sin(time*5+(z.phase||0))*h*.016;
let u=(W/2-(p.x-width/2))/width,v=(H/2-top)/h,pad=spread*Math.min(W,H)/h;
if(z.dog){if(v<.12-pad||v>1+pad||u<.02-pad||u>.95+pad)return null;return u<.37&&v<.55?'HEAD':v>.67?'LEGS':'BODY'}
if(v<.035-pad||v>1+pad)return null;
if(v<.32){if(u<.22-pad||u>.78+pad)return null;return 'HEAD'}
if(v<.71){if(u<.04-pad||u>.96+pad)return null;return 'BODY'}
if(!((u>=.24-pad&&u<=.47+pad)||(u>=.56-pad&&u<=.79+pad)))return null;return 'LEGS'}
function aimedRigRegion(z,spread=0){let p=project(z.x,z.y);if(p.depth<=.12)return null;let height=eyeHeight()+Math.tan(player.pitch||0)*p.depth,side=(W/2-p.x)/p.size,pad=spread*Math.min(W,H)/p.size;if(height>=.795-pad&&height<=.937+pad&&Math.abs(side+.008)<=.064+pad)return 'HEAD';if(height>=.43-pad&&height<.795+pad&&Math.abs(side)<=.17+pad)return 'BODY';if(height>=.025-pad&&height<.43+pad&&Math.abs(Math.abs(side)-.07)<=.043+pad)return 'LEGS';return null}
function shoot(fromBurst=false){if(attackClock>0||(shotClock>0&&!fromBurst)||reloading||mode!=='playing'||(burstRemaining>0&&!fromBurst))return;let w=weapon(),g=guns[w.type];if(w.type==='signal'){if(!signalCharging)fireSignalPulse();return}if(g.semi&&semiLatch&&!fromBurst)return;if(w.mag<=0){reload();shotClock=.3;return}if(g.semi)semiLatch=true;if(g.burst&&!fromBurst){burstRemaining=g.burst-1;burstTimer=.075;burstType=w.type}w.mag--;runStats.shots++;ejectCasing52(w.type);handlingKick=Math.min(1.5,handlingKick+Math.min(.35,g.damage/800));muzzleSmoke.push({life:.65,side:Math.random()*2-1});if(muzzleSmoke.length>10)muzzleSmoke.shift();shotClock=g.rate*(doubleTap?.75:1);flash=.07;weaponShotTime=time;gunReport(w.type);let hits=[];
for(const z of zombies){if(z.dead)continue;let d=Math.hypot(z.x-player.x,z.y-player.y),a=Math.atan2(z.y-player.y,z.x-player.x),region=aimedRegion(z,(w.type==='shotgun'||g.pellets)?.018:0);if(region&&d<g.range&&shotVisible(z))hits.push({z,d,region})}
const environmentalHit53=traceLivingShot53(g.range);if(environmentalHit53){hits=hits.filter(q=>q.d<environmentalHit53.distance);if(!hits.length||g.pierce>hits.length)damageLivingProp53(environmentalHit53.object,g.damage*(w.upgraded?2.5:1));}
hits.sort((a,b)=>a.d-b.d);if(w.type!=='shotgun'&&!g.pellets)hits=hits.slice(0,g.pierce||1);
if(hits.length)runStats.hits++;else if(!environmentalHit53)markWallShot();for(const {z,d,region} of hits){let multiplier=region==='HEAD'?2.5:region==='LEGS'?.55:z.variant==='armored'?.65:1;damageZombie(z,g.damage*(w.upgraded?2.5:1)*multiplier*((w.type==='shotgun'||g.pellets)?Math.max(.3,1-d/12):1),region,w.type);hitRegion=region==='HEAD'?'HEADSHOT':region==='LEGS'?'LEG HIT':'BODY HIT';hitRegionTime=.65;
if(w.type==='arc'){lightning=.3;sound(700,.35,.12,'square');let chain=[z];for(let i=0;i<(w.upgraded?9:5);i++){let next=zombies.find(n=>!n.dead&&!chain.includes(n)&&chain.some(c=>Math.hypot(n.x-c.x,n.y-c.y)<4)&&shotVisible(n));if(!next)break;chain.push(next);damageZombie(next,g.damage*(w.upgraded?2.5:1))}}}}
function melee(){
 if(attackClock>0||mode!=='playing')return;
 cancelSignalCharge(true);
 // Put the firearm away first. Unfinished reloads never transfer ammunition.
 reloading=0;reloadStage=-1;burstRemaining=0;burstType=null;burstTimer=0;
 flash=0;weaponMuzzleScreen=null;attackClock=.65;meleePendingHit=true;
 sound(150,.15,.06,'triangle',true);
}
function updateMeleeContact(){
 if(!meleePendingHit||attackClock>.65*.62||mode!=='playing')return;
 meleePendingHit=false;
 let z=zombies.filter(z=>!z.dead&&!z.wait&&Math.hypot(z.x-player.x,z.y-player.y)<1.6&&Math.abs(actorElevation(z)-actorElevation(player))<.6&&combatVisible(z)&&Math.cos(Math.atan2(z.y-player.y,z.x-player.x)-player.a)>.35&&visibleBetween(player.x,player.y,z.x,z.y)).sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y))[0];
 if(z)damageZombie(z,95*(boost?2:1)*(ownedPerks.has('brawler')?1.6:1),'BODY','melee');
}
function updateBurst(dt){if(!burstRemaining)return;if(attackClock>0||weapon().type!==burstType||reloading||mode!=='playing'){burstRemaining=0;return}burstTimer-=dt;while(burstRemaining&&burstTimer<=0){burstRemaining--;if(weapon().mag<=0){burstRemaining=0;return}shoot(true);burstTimer+=.075}}
function changeStance(){if(jumpHeight>0)return;stance=stance===0?1:0;controllerSprint=false}
function throwGrenade(type){if(mode!=='playing')return;if(type==='frag'?fragCount<=0:tacticalCount<=0){tell(type==='frag'?'No frag grenades left':'No tactical grenades left');return}if(type==='frag')fragCount--;else tacticalCount--;controllerSprint=false;grenades.push({type,level:player.level||0,x:player.x+Math.cos(player.a)*.22,y:player.y+Math.sin(player.a)*.22,z:eyeHeight(),vx:Math.cos(player.a)*5,vy:Math.sin(player.a)*5,vz:2+Math.sin(player.pitch)*3,fuse:type==='frag'?2:1.1});sound(180,.08,.025,'triangle')}
function obstacleVisualHeight(p){return p.colliderHeight??p.h??(p.type==='van'?.92:p.type==='car'?.68:p.type==='shelf'?1:p.type==='lamp'?1.32:p.type==='planter'?.42:p.type==='crate'?.40:p.type==='barrel'?.56:.65)}
function worldPointSolid(x,y,h){
 for(let p of mapObstacles){if(livingPropGone53(p))continue;if(p.only3d&&$('renderer-mode').value!=='3d')continue;if(h>=0&&h<obstacleVisualHeight(p)&&Math.abs(x-p.x)<p.ex&&Math.abs(y-p.y)<p.ey)return true}
 for(let st of stations){if(st.mounted||['tele','base'].includes(st.type))continue;let footprint=st.type==='box'?{ex:.48,ey:.28}:perkDefinitions[st.type]||['power','upgrade','ammo'].includes(st.type)?stationFootprint(st):null;if(footprint&&h>=0&&h<(st.type==='box'?.50:st.type==='ammo'?.72:1.25)&&Math.abs(x-st.x)<footprint.ex&&Math.abs(y-st.y)<footprint.ey)return true}
let cx=Math.floor(x),cy=Math.floor(y),v=world[cy]?.[cx]??1;if(inFireEscape(x,y)&&h<stairHeight(x,y)-.02)return true;if(upperFloorCell(x,y)&&!inFireEscape(x,y)&&h>1.64&&h<1.80)return true;
 if(activeMapId==='blackridge'&&cx===19&&cy===25&&h>=1.12&&h<3.5)return true;if(upperBridgeWall(cx,cy)&&h>=1.8&&h<3.5)return true;if(upperDoorCell(cx,cy)&&h>1.8&&h<2.95)return !upperUnlocked;if(upperDividerCell(cx,cy)&&h>=1.8)return false;if(!v)return false;let ox=originalAxis(cx,'x'),oy=originalAxis(cy,'y'),height=districtWallCells.has(cx+','+cy)?districtWallHeight(cx,cy):oy>=15&&ox>=9&&ox<=22?2.2:1.6;if(v>1)return h>=0&&h<height;return h>=0&&h<height}
function rayClear3D(x,y,h,tx,ty,th){let d=Math.hypot(tx-x,ty-y,th-h),steps=Math.ceil(d/.07);for(let i=1;i<steps;i++){let f=i/steps;if(worldPointSolid(x+(tx-x)*f,y+(ty-y)*f,h+(th-h)*f))return false}return true}
function shotVisible(z){return rayClear3D(player.x,player.y,eyeHeight(),z.x,z.y,actorElevation(z)+(z.dog?.28:.62))}
function combatVisible(z){return rayClear3D(z.x,z.y,actorElevation(z)+(z.dog?.30:.65),player.x,player.y,actorElevation(player)+.65)}
function visibleBetween(x,y,tx,ty){let d=Math.hypot(tx-x,ty-y),steps=Math.ceil(d/.1);for(let i=1;i<steps;i++)if(solid(x+(tx-x)*i/steps,y+(ty-y)*i/steps))return false;return true}
const equipmentReportBuffers={};
function equipmentReport(type){if(equipmentReportBuffers[type])return equipmentReportBuffers[type];let duration=type==='frag'?.85:.42,b=ac.createBuffer(1,Math.ceil(ac.sampleRate*duration),ac.sampleRate),a=b.getChannelData(0),low=0;for(let i=0;i<a.length;i++){let t=i/ac.sampleRate,n=Math.random()-.5;low=low*.91+n*.09;let envelope=Math.exp(-t*(type==='frag'?5:12));a[i]=(type==='frag'?low*.85+n*.12:low*.18+n*.35)*envelope}equipmentReportBuffers[type]=b;return b}
function playEquipmentReport(g){if(ac&&$('sound').checked)playSpatial(equipmentReport(g.type),g,g.type==='frag'?.65:.25,1)}
function explodeGrenade(g){if(g.type==='frag')damageLivingArea53(g,4,550,'frag');blasts.push({...g,age:0,seed:Math.random()*6.28,life:g.type==='frag'?2.2:1.05});if(blasts.length>8)blasts.shift();if(g.type==='tactical'){for(const z of zombies)if(!z.dead&&Math.hypot(z.x-g.x,z.y-g.y,actorElevation(z)+.4-g.z)<4.5&&rayClear3D(g.x,g.y,g.z+.05,z.x,z.y,actorElevation(z)+.4))z.stun=6;playEquipmentReport(g);return}playEquipmentReport(g);for(const z of zombies){let d=Math.hypot(z.x-g.x,z.y-g.y,actorElevation(z)+.4-g.z);if(!z.dead&&d<4&&rayClear3D(g.x,g.y,g.z+.05,z.x,z.y,actorElevation(z)+.4))damageZombie(z,550*Math.max(.15,1-d/4))}let d=Math.hypot(player.x-g.x,player.y-g.y,actorElevation(player)+.4-g.z);if(d<3&&rayClear3D(g.x,g.y,g.z+.05,player.x,player.y,actorElevation(player)+.4)){player.hp-=95*(1-d/3);player.lastHit=time;hurt=.9;if(player.hp<=0)die()}}
function updateGrenades(dt){for(const g of grenades){g.fuse-=dt;g.vz-=4.6*dt;g.z=Math.max(actorElevation(g)+.04,g.z+g.vz*dt);let ox=g.x,oy=g.y;move(g,g.vx*dt,g.vy*dt,.08);if(g.x===ox)g.vx*=-.35;if(g.y===oy)g.vy*=-.35;if(g.z<=actorElevation(g)+.041){g.vz=Math.abs(g.vz)*.2;g.vx*=Math.max(0,1-dt*3);g.vy*=Math.max(0,1-dt*3)}if(g.fuse<=0)explodeGrenade(g)}grenades=grenades.filter(g=>g.fuse>0);blasts=blasts.filter(b=>{b.age=(b.age||0)+dt;b.life-=dt;return b.life>0})}
function near(){if((player.level||0)===1||actorElevation(player)>.3){if(!upperUnlocked&&actorElevation(player)>1.55&&Math.hypot(player.x-upperAccessGate.x,player.y-upperAccessGate.y)<1.55)return upperAccessGate;return null;}let choices=[];for(const w of windows)if(w.boards<6)choices.push({x:w.x,y:w.y,type:'window',label:`REPAIR BARRICADE (${w.boards}/6)`,cost:0,w});for(const s of stations)if(s.type!=='fuse'||!fuses[s.id])choices.push(s);for(const g of gates)if(g.cells.some(([x,y])=>world[y][x]))choices.push(g);let primary=choices.filter(s=>{let d=Math.hypot(s.x-player.x,s.y-player.y);return d<1.55&&(s.type==='gate'||d<lineDist(Math.atan2(s.y-player.y,s.x-player.x))+.15)}).sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y))[0];return primary||nearestIntelClue()}
function interact(){const n=near();if(!n)return;if(n.type==='intel'){if(actionCooldown>0)return;actionCooldown=.6;signalDispatch(n.text,11);return}if(n.type==='window'){if(repairClock>0)return;n.w.boards++;points+=10;repairClock=.4;sound(150,.09,.06,'square');return}if(actionCooldown>0)return;actionCooldown=.45;if(livingInteract53(n)||mapInteraction(n))return;
if(n.type==='fuse'){fuses[n.id]=true;tell(`FUSE SALVAGED · ${fuses.filter(Boolean).length}/3${fuses.every(Boolean)?' — install at power cabinet':''}`);sound(450,.2,.04,'sine');return}if(n.type==='power'&&power&&fuses.every(Boolean)&&!questDone){questDone=true;points+=1000;inventory.forEach(w=>{w.mag=magazineCapacity(w);w.reserve=reserveCapacity(w.type)});reloading=0;banner('AUXILIARY SHIELD ONLINE');tell('Quest complete: +1000 points, full ammo and 15% less enemy damage');return}
if(runChallenge==='pistol'&&(guns[n.type]&&n.type!=='pistol'||n.type==='box')){tell('Pistol-only challenge: weapon purchases disabled');return}if(runChallenge==='no-perks'&&perkDefinitions[n.type]){tell('No-perks challenge: perk purchases disabled');return}
if(n.type==='base'){if(linking<0){tell(linked.every(Boolean)?'All teleporters linked. Forge-a-Punch online.':'Activate a teleporter, then return here within 50 seconds');return}linked[linking]=true;linking=-1;linkTime=0;banner('TELEPORTER LINK CONFIRMED');if(linked.every(Boolean)){banner('FORGE-A-PUNCH UNLOCKED');tell('Upgrade your held weapon at the courtyard forge')}return}
if(n.type==='tele'){if(!power){tell('Restore base power first');return}if(!linked[n.id]){if(linking>=0){tell('Finish the active link at the command relay first');return}linking=n.id;linkTime=50;banner(`LINK ${'ABC'[n.id]} STARTED`);tell('Return to the command relay within 50 seconds');return}if(teleCooldown>0){tell(`Teleporter charging: ${Math.ceil(teleCooldown)}s`);return}if(points<300){tell('Teleport costs 300 points');return}points-=300;player.x=base.x;player.y=base.y-1;player.level=0;player.cameraBase=0;player.a=-Math.PI/2;teleCooldown=12;lightning=.65;pathClock=0;banner('COMMAND RELAY RETURN',2);sound(500,.6,.12,'sine');return}
if(n.type==='box'){if(boxTime>0){tell('The crate is rolling…');return}if(boxOffer){boxLast=boxOffer;giveGun(boxOffer);boxOffer=null;boxPreview=null;boxLife=0;boxSpins++;if(boxSpins%4===0){boxIndex=(boxIndex+1)%boxLocations.length;Object.assign(n,boxLocations[boxIndex]);tell('Mystery crate moved — find the wooden chest')}return}}
if(n.type==='power'&&power){beginFieldTask();return}
if((perkDefinitions[n.type]||['upgrade','trap'].includes(n.type))&&!power){tell('Restore base power first');return}
if(n.type==='upgrade'&&!forgeReady()){tell(activeMapId==='railyard'?'Complete coolant lines and the induction charge first':'Link all three teleporters to unlock Forge-a-Punch');return}
if(n.type==='upgrade'&&weapon().upgraded){tell('This weapon is already upgraded');return}
if(perkDefinitions[n.type]&&ownedPerks.has(n.type)){tell('Perk already equipped');return}
if(n.type==='trap'&&(trapTime>0||trapCooldown>0)){tell(trapTime>0?'Trap active — stay clear':`Trap cooling: ${Math.ceil(trapCooldown)}s`);return}
let owned=inventory.find(w=>w.type===n.type),cost=owned?Math.floor(n.cost/2):n.cost;if(points<cost){tell(`Need ${cost-points} more points`);return}points-=cost;sound(380,.25,.07,'triangle');
if(n.type==='uppergate'){upperUnlocked=true;pathClock=0;navCache=null;banner('SKYBRIDGE HALL OPEN');tell('Upper hall unlocked — both buildings are connected')}
else if(n.type==='gate'){n.cells.forEach(([x,y])=>world[y][x]=0);livingDoorOpened53(n);pathClock=0;tell(n.label.replace('OPEN ','')+' OPENED')}
else if(n.type==='power'){power=true;banner(activeMapId==='railyard'?'REACTOR POWER ONLINE':'DISTRICT POWER ONLINE');tell(activeMapId==='railyard'?'Reactor online. Open all three coolant valves.':'Activate the three teleporters and link them to the mainframe')}
else if(perkDefinitions[n.type]){equipPerk(n.type)}
else if(n.type==='upgrade'){forgeWeapon()}
else if(n.type==='trap'){trapTime=15;trapCooldown=45;tell('Electric trap active in generator entrance — stay clear')}
else if(n.type==='box'){boxTime=2.8;boxPending=rollBox();boxShuffle=0;shuffleBox();tell('The mystery crate is rolling…')}
else if(n.type==='ammo'){inventory.forEach(w=>{if(w.type!=='signal')w.reserve=reserveCapacity(w.type)});tell(inventory.some(w=>w.type==='signal')?'MAGAZINES REPLENISHED · SIGNAL CELLS REQUIRE MAX AMMO':'Reserve ammunition replenished')}
else if(owned){owned.reserve=reserveCapacity(n.type);tell('Ammunition replenished')}
else giveGun(n.type)}
// Cached half-cell clearance graph; two layers connect only at the fire-escape top.
let NAV_W=92,NAV_H=88,NAV_N=NAV_W*NAV_H;let navCache=null,navDistances=null;
function navPoint(i){let level=Math.floor(i/NAV_N),n=i%NAV_N;return {x:(n%NAV_W+.5)/2,y:(Math.floor(n/NAV_W)+.5)/2,level}}
function navIndex(x,y,level=0){return level*NAV_N+Math.floor(y*2)*NAV_W+Math.floor(x*2)}
function navigationMaskAt(i){let o=navPoint(i);return o.level===0?groundCanMove(o.x,o.y,.195)&&(!inFireEscape(o.x,o.y)||(o.x>.24+20&&o.x<22-.24)):!inFireEscape(o.x,o.y)&&upperCellOpen(o.x,o.y)&&canMove(o.x,o.y,.195,o)}
function navigationEdgesAt(i,mask){let result=[];if(!mask[i])return result;let o=navPoint(i),x=Math.floor(o.x*2),y=Math.floor(o.y*2);for(let[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){let nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=NAV_W||ny>=NAV_H)continue;for(let level of[o.level,1-o.level]){let j=level*NAV_N+ny*NAV_W+nx;if(!mask[j])continue;let q=navPoint(j);if(level!==o.level&&!inFireEscape(o.x,o.y)&&!inFireEscape(q.x,q.y))continue;if(Math.abs(actorElevation(o)-actorElevation(q))>.221)continue;if(clearWalkLine(o.x,o.y,q.x,q.y,o))result.push(j)}}return result}
function buildNavigation(){
 if(NAV_W!==world[0].length*2){NAV_W=world[0].length*2;NAV_H=world.length*2;NAV_N=NAV_W*NAV_H;navCache=null;navDistances=null;}
 let meta=activeMapId+'|'+mapRevision+'|'+stations.filter(s=>!s.mounted).map(s=>s.type+':'+s.x+':'+s.y).join('|')+'|'+mapObstacles.map(p=>[p.x,p.y,p.ex,p.ey,p.only3d].join(',')).join('|')+'|'+$('renderer-mode').value+'|'+upperUnlocked,state=new Uint8Array(world.flat()),key=meta+'|'+world.map(r=>r.join('')).join()+'|'+livingCollisionRevision53;if(navCache?.key===key)return;
 let changed=[];if(navCache?.meta===meta&&navCache.state?.length===state.length)for(let i=0;i<state.length;i++)if(state[i]!==navCache.state[i])changed.push(i);
 if(navCache?.meta===meta)changed=[...new Set([...changed,...livingNavDirty53])];
 if(navCache?.meta===meta&&changed.length&&changed.length<=96){
  let core=new Set(),sources=new Set(),width=world[0].length;
  for(let cell of changed){let cx=cell%width,cy=Math.floor(cell/width);for(let y=cy*2-2;y<=cy*2+3;y++)for(let x=cx*2-2;x<=cx*2+3;x++){if(x<0||y<0||x>=NAV_W||y>=NAV_H)continue;for(let level of[0,1])core.add(level*NAV_N+y*NAV_W+x)}}
  for(let i of core){navCache.mask[i]=navigationMaskAt(i);let o=navPoint(i),x=Math.floor(o.x*2),y=Math.floor(o.y*2);for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){let xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<NAV_W&&yy<NAV_H)sources.add(o.level*NAV_N+yy*NAV_W+xx)}}
  // Remove old reverse links before reconnecting only the changed neighborhood.
  for(let i of sources){for(let j of navCache.edges[i])navCache.incoming[j]=navCache.incoming[j].filter(n=>n!==i);navCache.edges[i]=[]}
  for(let i of sources){let links=navigationEdgesAt(i,navCache.mask);navCache.edges[i]=links;for(let j of links)navCache.incoming[j].push(i)}
  Object.assign(navCache,{key,meta,state,updateKind:'local',updatedNodes:sources.size});livingNavDirty53.clear();return;
 }
 let mask=new Uint8Array(NAV_N*2),edges=Array.from({length:NAV_N*2},()=>[]),incoming=Array.from({length:NAV_N*2},()=>[]);for(let i=0;i<mask.length;i++)mask[i]=navigationMaskAt(i);
 for(let i=0;i<mask.length;i++){edges[i]=navigationEdgesAt(i,mask);for(let j of edges[i])incoming[j].push(i)}navCache={key,meta,state,mask,edges,incoming,updateKind:'full',updatedNodes:mask.length};livingNavDirty53.clear();
}
function clearWalkLine(x,y,tx,ty,o={x,y,level:0}){let actor={...o,x,y},length=Math.hypot(tx-x,ty-y),steps=Math.max(1,Math.ceil(length/.1));for(let i=1;i<=steps;i++){let nx=x+(tx-x)*i/steps,ny=y+(ty-y)*i/steps;if(!canMove(nx,ny,.19,actor))return false;actor.level=actorLevelAt(actor,nx,ny);actor.x=nx;actor.y=ny}return true}
function nearestNav(o,reachable=false){if(!navCache)return -1;let best=-1,score=Infinity,cx=Math.floor(o.x*2),cy=Math.floor(o.y*2);for(let radius=0;radius<=5;radius++){for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++){if(radius&&Math.abs(dx)!==radius&&Math.abs(dy)!==radius)continue;let x=cx+dx,y=cy+dy;if(x<0||y<0||x>=NAV_W||y>=NAV_H)continue;let i=(o.level||0)*NAV_N+y*NAV_W+x;if(!navCache.mask[i]||(reachable&&navDistances?.[i]>=65535))continue;let q=navPoint(i),d=Math.hypot(o.x-q.x,o.y-q.y);if(d<score&&clearWalkLine(o.x,o.y,q.x,q.y,o)){score=d;best=i}}if(best>=0)return best}return best}
function calcFlow(){let seed=(player.level||0)===1||actorElevation(player)>.3?{x:20.5,y:39.5}:player;flow=world.map(row=>row.map(()=>999));let x=Math.floor(seed.x),y=Math.floor(seed.y),q=[[x,y]];flow[y][x]=0;for(let i=0;i<q.length;i++){let[a,b]=q[i];for(let[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){let nx=a+dx,ny=b+dy;if(world[ny]?.[nx]===0&&flow[ny][nx]===999&&groundCanMove(nx+.5,ny+.5,.19)){flow[ny][nx]=flow[b][a]+1;q.push([nx,ny])}}}
 buildNavigation();navDistances=new Uint16Array(NAV_N*2);navDistances.fill(65535);let start=nearestNav(player);if(start<0)return;let queue=[start];navDistances[start]=0;for(let head=0;head<queue.length;head++){let i=queue[head];for(let n of navCache.incoming[i])if(navDistances[n]===65535){navDistances[n]=navDistances[i]+1;queue.push(n)}}
}
function navigationPotential(z){let i=nearestNav(z,true);return i>=0?navDistances[i]*.5+Math.hypot(z.x-navPoint(i).x,z.y-navPoint(i).y):Infinity}
function steerZombie(z,dt,d){let direct=(z.level||0)===(player.level||0)&&Math.abs(actorElevation(z)-actorElevation(player))<.25&&clearWalkLine(z.x,z.y,player.x,player.y,z),tx=player.x,ty=player.y;
 if(direct){z.navWaypoint=null}else{
  let pending=z.navWaypoint,q=pending!=null?navPoint(pending):null;
  if(!q||navDistances?.[pending]>=65535||Math.hypot(z.x-q.x,z.y-q.y)<.07||!clearWalkLine(z.x,z.y,q.x,q.y,z)){
   let current=nearestNav(z,true);if(current<0){z.navWaypoint=null;return}let candidates=[...navCache.edges[current]].filter(i=>navDistances[i]<navDistances[current]).sort((a,b)=>navDistances[a]-navDistances[b]||Math.hypot(navPoint(a).x-z.x,navPoint(a).y-z.y)-Math.hypot(navPoint(b).x-z.x,navPoint(b).y-z.y));
   let next=candidates.find(i=>{let n=navPoint(i);return clearWalkLine(z.x,z.y,n.x,n.y,z)});pending=next??current;z.navWaypoint=pending;q=navPoint(pending);
  }tx=q.x;ty=q.y;
 }
 let vx=tx-z.x,vy=ty-z.y,len=Math.hypot(vx,vy);if(len<.005)return;vx/=len;vy/=len;
 if(direct&&d>1.4){let sway=Math.sin(time*.75+(z.phase||0))*.025,oldX=vx;vx-=vy*sway;vy+=oldX*sway}
 // Doorway paths keep their heading; crowd separation applies only in open approaches.
 if(direct)for(let n of zombies){if(n===z||n.dead||n.wait||(n.level||0)!==(z.level||0))continue;let dx=z.x-n.x,dy=z.y-n.y,dist=Math.hypot(dx,dy);if(dist>.001&&dist<.40){let push=Math.min(.075,(.40-dist)*.45),px=vx+dx/dist*push,py=vy+dy/dist*push;if(clearWalkLine(z.x,z.y,z.x+px*z.speed*dt,z.y+py*z.speed*dt,z)){vx=px;vy=py}}}
 len=Math.hypot(vx,vy);if(len>.001){let step=Math.min(z.speed*dt,Math.hypot(tx-z.x,ty-z.y));move(z,vx/len*step,vy/len*step,.19)}
}
// Independent pressure controls: health, wave budget, active cap, cadence and gait mix.
function waveProfile(n){n=Math.max(1,n);return {count:6+n*2+Math.floor(n*n*.035),health:Math.round(105*(1+.065*Math.min(n-1,8))*Math.pow(1.065,Math.max(0,n-9))),speed:Math.min(.88,.53+n*.025),spawnInterval:Math.max(.55,2.05*Math.pow(.955,n-1)),cap:Math.min(24,7+Math.floor(n*.8)),boardInterval:Math.max(.65,1.4*Math.pow(.98,n-1)),damage:Math.min(32,25+Math.floor((n-1)/12)),runnerChance:n<4?0:Math.min(.42,.08+(n-4)*.022),sprintChance:n<8?0:Math.min(.18,.025+(n-8)*.012),armorChance:n<10?0:Math.min(.14,.03+(n-10)*.005)}}
function encounterZone(x,y){if(activeMapId==='railyard')return districtZone(x,y);x=originalAxis(x,'x');y=originalAxis(y,'y');return y<12?'generator':x<10?'west':x>=22?'east':'courtyard'}
function activeSpawnWindows(){return windows.filter(w=>groundCanMove(w.x,w.y,.19)&&nearestNav({...w,level:0},true)>=0)}
function chooseSpawnWindow(random=Math.random){let active=activeSpawnWindows();if(!active.length)return null;let zone=encounterZone(player.x,player.y),weights=active.map(w=>{let same=encounterZone(w.x,w.y)===zone,occupied=zombies.filter(z=>z.wait===w).length;return (same?3:1)/(1+occupied*2)}),pick=random()*weights.reduce((a,b)=>a+b,0);for(let i=0;i<active.length;i++){pick-=weights[i];if(pick<0)return active[i]}return active.at(-1)}
function roundStart(){round++;dogRound=round%5===0;remaining=dogRound?4+Math.floor(round*.7):waveProfile(round).count;spawnClock=.8;banner(dogRound?'HOUND WAVE':`ROUND ${String(round).padStart(2,'0')}`,3.5);if(round===4)tell('Mixed walking and running enemies incoming');if(round===8)tell('Sprinters incoming — watch the entrances');if(round===10)tell('Armored enemies incoming — aim for exposed heads');sound(90,.8,.08,'triangle');}
function spawn(){let w=chooseSpawnWindow();if(!w)return;let p=waveProfile(round),roll=Math.random(),variant=dogRound?'hound':roll<p.armorChance?'armored':'walker',gait=dogRound?'run':variant==='armored'?'walk':Math.random()<p.sprintChance?'sprint':Math.random()<p.runnerChance?'run':'walk';if(variant==='walker'&&gait!=='walk')variant='runner';let hp=dogRound?70+round*9:Math.round(p.health*(variant==='armored'?1.45:variant==='runner'?.9:1)),variation=.9+Math.random()*.2,speed=dogRound?Math.min(2.6,1.8+round*.015):gait==='sprint'?Math.min(2.35,1.65+round*.018)*variation:gait==='run'?Math.min(1.65,1.12+round*.02)*variation:p.speed*variation*(variant==='armored'?.85:1);notifyRadarSpawn(w);zombies.push({x:w.x,y:w.y,hp,max:hp,speed,gait,stride:dogRound?.45:gait==='walk'?.65:gait==='run'?.85:1.05,variant,damage:p.damage,dog:dogRound,wait:dogRound?null:w,phase:Math.random()*6,hit:0,cooldown:0,appearance:Math.floor(Math.random()*3),walk:Math.random()*6,stuckTime:0});remaining--;}
// Start, wind up, contact once, recover. Range and line of sight are checked at contact.

function recoverStuckEnemy(z,dt,moved){if(z.wait||z.attackElapsed!=null||(Math.hypot(z.x-player.x,z.y-player.y)<1.1&&Math.abs(actorElevation(z)-actorElevation(player))<.4&&combatVisible(z))){z.stuckTime=0;z.progressClock=0;return}
 let goal=z.progressGoal;if(!goal||Math.hypot(goal.x-player.x,goal.y-player.y)>1.25||goal.level!==(player.level||0)){z.progressGoal={x:player.x,y:player.y,level:player.level||0};z.bestPotential=Infinity;z.stuckTime=0;z.navWaypoint=null}
 z.progressClock=(z.progressClock||0)+dt;z.stuckTime=(z.stuckTime||0)+dt;
 if(z.progressClock>=.75){let potential=navigationPotential(z);if(Number.isFinite(potential)&&potential<(z.bestPotential??Infinity)-.12){z.bestPotential=potential;z.stuckTime=0}z.progressClock=0}
 if(!canMove(z.x,z.y,.19,z))z.stuckTime=Math.max(6,z.stuckTime);
 if(z.stuckTime>2.5&&time>=(z.repathAt||0)){pathClock=0;z.repathAt=time+.7;z.navWaypoint=null;z.footPlant=null;z.footOffsetX=z.footOffsetY=0}
 if(z.stuckTime<6||time<(z.recoveryAt||0))return;z.recoveryAt=time+.75;
 // Recover only onto a player-reachable surface that improves the route. Preserve this enemy's HP/count.
 let nearby=[];for(let y=-6;y<=6;y++)for(let x=-6;x<=6;x++){let q={x:z.x+x*.25,y:z.y+y*.25,level:z.level||0};if(Math.hypot(q.x-z.x,q.y-z.y)<.20||Math.hypot(q.x-player.x,q.y-player.y)<1.4||!canMove(q.x,q.y,.19,q))continue;let i=nearestNav(q,true);if(i<0)continue;let cost=navDistances[i]*.5+Math.hypot(q.x-navPoint(i).x,q.y-navPoint(i).y);if(Number.isFinite(z.bestPotential)&&cost>=z.bestPotential-.1)continue;nearby.push({q,cost:cost+Math.hypot(x,y)*.03+(shotVisible(q)?2:0)})}nearby.sort((a,b)=>a.cost-b.cost);let q=nearby[0]?.q;
 if(!q&&z.stuckTime>=12){let candidates=activeSpawnWindows().filter(w=>Math.hypot(w.x-player.x,w.y-player.y)>2).sort((a,b)=>(visibleBetween(player.x,player.y,a.x,a.y)?1:0)-(visibleBetween(player.x,player.y,b.x,b.y)?1:0));q=candidates[0];if(q)q={x:q.x,y:q.y,level:0}}
 if(q){z.x=q.x;z.y=q.y;z.level=q.level;z.entryOffset=0;z.navWaypoint=null;z.stuckTime=0;z.bestPotential=Infinity;z.progressClock=0;z.footPlant=null;z.footOffsetX=z.footOffsetY=0;pathClock=0}
}

function update(dt){if(mode!=='playing')return;playerMotionStart={x:player.x,y:player.y,level:player.level||0};time+=dt;stanceEye+=((stance===2?.28:stance===1?.53:.82)-stanceEye)*Math.min(1,dt*12);updateGrenades(dt);if(mode!=='playing')return;updateEnhancements(dt);updateLivingWorld53(dt);if(mode!=='playing')return;updateMapProgress(dt);updateFieldTask(dt);updateGroans(dt);updateAtmosphere(dt);jumpCooldown=Math.max(0,jumpCooldown-dt);landingKick=Math.max(0,landingKick-dt*5);if(jumpHeight>0||jumpVelocity>0){jumpVelocity-=4.6*dt;jumpHeight+=jumpVelocity*dt;if(jumpHeight<=0){jumpHeight=0;jumpVelocity=0;landingKick=.8;jumpCooldown=.12;sound(80,.09,.04,'triangle',true)}}hitRegionTime=Math.max(0,hitRegionTime-dt);actionCooldown=Math.max(0,actionCooldown-dt);teleCooldown=Math.max(0,teleCooldown-dt);trapTime=Math.max(0,trapTime-dt);trapCooldown=Math.max(0,trapCooldown-dt);lightning=Math.max(0,lightning-dt);if(linking>=0){linkTime-=dt;if(linkTime<=0){linking=-1;tell('Link timed out. Reactivate the teleporter to retry.')}}if(boxTime>0){boxTime-=dt;boxShuffle-=dt;if(boxShuffle<=0){shuffleBox();boxShuffle=boxTime>1?.09:.22}if(boxTime<=0){boxOffer=boxPending;boxPending=null;boxPreview=boxOffer;boxLife=12;tell(guns[boxOffer].name+' — hold '+controllerLabel('interact')+' / press E at crate to claim')}}else if(boxOffer){boxLife-=dt;if(boxLife<=0){boxOffer=boxPreview=null;tell('Mystery weapon expired')}}shotClock=Math.max(0,shotClock-dt);attackClock=Math.max(0,attackClock-dt);updateMeleeContact();repairClock=Math.max(0,repairClock-dt);flash=Math.max(0,flash-dt);hurt=Math.max(0,hurt-dt);hitmark=Math.max(0,hitmark-dt);bannerTime-=dt;toastTime-=dt;if(bannerTime<=0)$('banner').textContent='';if(toastTime<=0)$('toast').textContent='';if(reloading>0){reloading-=dt;if(reloading<=0){let w=weapon(),g=guns[w.type],n=Math.min(g.shellTime?1:magazineCapacity(w)-w.mag,w.reserve);w.mag+=n;w.reserve-=n;reloading=g.shellTime&&w.mag<magazineCapacity(w)&&w.reserve>0&&!fire?reloadDuration(w.type):0}}
let ci=controllerFrame,gx=0,gy=0,sprint=keys.ShiftLeft||keys.ShiftRight;if(ci){gx=ci.x;gy=ci.y;player.a+=ci.lookX*dt*controllerPrefs.sensitivity*1.35*aimLookScale();lookVertical(ci.lookY*dt*controllerPrefs.sensitivity*aimLookScale());aim=mouseAim||ci.held.aim;fire=mouseFire||ci.held.shoot;
if(ci.pressed.sprint){controllerSprint=true;stance=0}if(ci.y<.1||aim||fire||sprintExhausted)controllerSprint=false;sprint=sprint||controllerSprint;
if(ci.pressed.flashlight)toggleFlashlight();if(ci.pressed.jump)jump();if(ci.pressed.crouch){changeStance();crouchHoldTime=0;proneConsumed=false}if(ci.held.crouch){crouchHoldTime+=dt;if(crouchHoldTime>=.45&&!proneConsumed&&jumpHeight===0){stance=2;controllerSprint=false;proneConsumed=true}}else{crouchHoldTime=0;proneConsumed=false}
if(ci.held.interact){useHoldTime+=dt;if(useHoldTime>=.3){if(!useHoldConsumed){interact();useHoldConsumed=true}if(near()?.type==='window')interact()}}else if(useHoldTime>0){if(useHoldTime<.3&&!useHoldConsumed)reload();useHoldTime=0;useHoldConsumed=false}
if(ci.pressed.reload&&!ci.held.interact)reload();if(ci.pressed.melee)melee();if(ci.pressed.grenade)throwGrenade('frag');if(ci.pressed.tactical)throwGrenade('tactical');if(ci.pressed.switch)switchGun((slot+1)%inventory.length);if(ci.pressed.pause)pause();if(mode!=='playing')return}else{aim=mouseAim;fire=mouseFire;controllerSprint=false;useHoldTime=0;useHoldConsumed=false}

let forward=(keys.KeyW?1:0)-(keys.KeyS?1:0)+gy,strafe=(keys.KeyD?1:0)-(keys.KeyA?1:0)+gx,len=Math.max(1,Math.hypot(forward,strafe));playerMoving=Math.hypot(forward,strafe)>.12;let running=!!(sprint&&playerMoving&&!aim&&stance===0&&!sprintExhausted&&stamina>0);if(running){stamina=Math.max(0,stamina-dt);staminaRecoveryDelay=.75;if(stamina<=0){sprintExhausted=true;tell('Catch your breath — stamina recharging')}}else{staminaRecoveryDelay=Math.max(0,staminaRecoveryDelay-dt);if(staminaRecoveryDelay===0)stamina=Math.min(staminaCapacity(),stamina+dt*1.25);if(stamina>1.2)sprintExhausted=false} sprintBlend+=(Number(running)-sprintBlend)*Math.min(1,dt*8);if(playerMoving)motionPhase+=dt*(running?15:9);let speed=(running?4.25*(ownedPerks.has('fleet')?1.2:1):stance===2?.75:stance===1?1.35:aim?1.5:2.55)*dt;move(player,(Math.cos(player.a)*forward-Math.sin(player.a)*strafe)*speed/len,(Math.sin(player.a)*forward+Math.cos(player.a)*strafe)*speed/len);if(keys.ArrowUp)lookVertical(dt*1.2);if(keys.ArrowDown)lookVertical(-dt*1.2);if(keys.ArrowLeft)player.a-=dt*2;if(keys.ArrowRight)player.a+=dt*2;if(!fire)semiLatch=false;if(fire&&reloading>0&&guns[weapon().type].shellTime&&weapon().mag>0)reloading=0;updateSignalCharge(dt,aim);updateBurst(dt);if(fire)shoot();if(keys.KeyE&&near()?.type==='window')interact();
pathClock-=dt;if(pathClock<=0){calcFlow();pathClock=.45}if(nextRound>0){nextRound-=dt;if(nextRound<=0)roundStart()}else{spawnClock-=dt;if(remaining>0&&spawnClock<=0&&zombies.length<waveProfile(round).cap){spawn();spawnClock=dogRound?.55:waveProfile(round).spawnInterval}if(remaining===0&&!zombies.length){saveRunRecord();fragCount=Math.min(4,fragCount+2);tacticalCount=Math.min(2,tacticalCount+1);nextRound=Math.max(7,10-Math.max(0,round-12)*.08);points+=200;inventory.forEach(w=>w.reserve=Math.min(reserveCapacity(w.type),w.reserve+Math.ceil(guns[w.type].cap*(round<6?1.5:.5))));if(dogRound){inventory.forEach(w=>{w.mag=magazineCapacity(w);w.reserve=reserveCapacity(w.type)});reloading=0;banner('HOUNDS CLEARED • MAX AMMO',3)}else banner('ROUND CLEARED • +200',3);tell(`${Math.ceil(nextRound)} seconds to resupply. Buy ammo before the next wave.`)}}
for(const w of windows)w.timer=Math.max(0,w.timer-dt);if(trapTime>0&&actorElevation(player)<.25&&inTrap(player.x,player.y)){player.hp-=dt*90;player.lastHit=time;hurt=.65;if(player.hp<=0){die();return}}for(const z of zombies){if(trapTime>0&&actorElevation(z)<.25&&inTrap(z.x,z.y)){damageZombie(z,9999);continue}if(z.dead)continue;z.hit=Math.max(0,z.hit-dt);z.moving=false;if(z.stun>0){z.stun-=dt;z.attackElapsed=null;continue}z.cooldown-=dt;if(z.wait){if(z.wait.boards>0){updateLivingBarrier53(z,z.wait,dt);continue}else{z.attackElapsed=null;z.barrierPhase53=null;let f=wallFixtures.find(f=>f.kind==='window'&&f.object===z.wait);if(f){z.entryOffset=.7;z.entryDX=f.dx;z.entryDY=f.dy}z.wait=null}}let dx=player.x-z.x,dy=player.y-z.y,d=Math.hypot(dx,dy);if(enemyAttack(z,dt)){if(mode!=='playing')return;continue}if(d<.8&&Math.abs(actorElevation(z)-actorElevation(player))<.48&&z.cooldown<=0&&combatVisible(z)){z.attackElapsed=0;z.attackDuration=z.dog?.65:z.crippled?1.05:z.gait==='sprint'?.8:.95;z.attackHeading=Math.atan2(dy,dx);z.attackContact=false;continue}if(d<.6&&Math.abs(actorElevation(z)-actorElevation(player))<.48&&combatVisible(z))continue;let oldX=z.x,oldY=z.y;steerZombie(z,dt*((z.stagger||0)>0?.3:1),d);let moved=Math.hypot(z.x-oldX,z.y-oldY);z.moving=moved>1e-5;if(z.moving)z.moveHeading=Math.atan2(z.y-oldY,z.x-oldX);if(z.dog||z.crippled){let target=z.attackElapsed!=null?z.attackHeading:z.moveHeading??Math.atan2(player.y-z.y,player.x-z.x);z.visualHeading=Number.isFinite(z.visualHeading)?z.visualHeading+Math.atan2(Math.sin(target-z.visualHeading),Math.cos(target-z.visualHeading))*Math.min(1,dt*12):target}if(trapTime>0&&actorElevation(z)<.25&&crossesTrap(oldX,oldY,z.x,z.y)){damageZombie(z,9999);continue}recoverStuckEnemy(z,dt,moved);let gaitStride=z.stride||.65;if(!z.dog&&typeof characterModel==='function'){let gaitClip=characterModel(0).clips[z.variant==='runner'||z.speed>1.2?'run':'walk'];gaitStride=gaitClip.stride||gaitStride}z.walk=(z.walk||0)+moved*Math.PI*2/(z.crippled?.4:gaitStride)}resolveEnemyContact(dt);if(typeof updateInfectedFootPlant==='function')for(const z of zombies)updateInfectedFootPlant(z,dt);zombies=zombies.filter(z=>!z.dead);if(time-player.lastHit>(ownedPerks.has('medic')?2.5:4))player.hp=Math.min(player.maxhp,player.hp+dt*(ownedPerks.has('medic')?17:11));drops=drops.filter(d=>{d.life-=dt;if(Math.hypot(d.x-player.x,d.y-player.y)<.7){if(d.type==='ammo'){inventory.forEach(w=>{w.reserve=reserveCapacity(w.type);w.mag=magazineCapacity(w)});reloading=0;tell('MAX AMMO')}else{player.hp=player.maxhp;tell('HEALTH RESTORED')}sound(500,.3,.08,'sine');return false}return d.life>0});particles=particles.filter(p=>{p.life-=dt;p.x+=p.dx*dt;p.y+=p.dy*dt;return p.life>0});player.cameraBase+=(actorElevation(player)-(player.cameraBase||0))*Math.min(1,dt*12);updateSignalAtmosphere(dt);updateHud();runSaveClock-=dt;if(runSaveClock<=0)saveCurrentRun();}
function damageEffectStrength(){let low=Math.max(0,Math.min(1,1-player.hp/player.maxhp));return Math.min(.88,hurt*.82+Math.pow(low,1.7)*(.64+.035*Math.sin(time*4)))}
function updateHud(){let w=weapon(),g=guns[w.type];$('round').textContent=String(round).padStart(2,'0');$('waveinfo').textContent=nextRound>0?`NEXT WAVE · ${Math.ceil(nextRound)}s`:`${remaining+zombies.filter(z=>!z.dead).length} ENEMIES LEFT`;
$('points').textContent=points.toLocaleString();$('stamina-fill').style.width=`${stamina/staminaCapacity()*100}%`;$('stamina-fill').style.background=sprintExhausted?'#da9e63':'#89c8bd';$('movement-status').textContent=jumpHeight>0?'AIRBORNE':stance===2?'PRONE':stance===1?'CROUCHING':sprintBlend>.5?'SPRINTING':sprintExhausted?'RECOVERING':'SHIFT / LS · SPRINT';$('equipment').textContent=`FRAG ${fragCount} · TACTICAL ${tacticalCount} · LIGHT ${flashlightOn?'ON':'OFF'}`;$('health').textContent=`${Math.max(0,Math.ceil(player.hp))} / ${player.maxhp}`;$('hp').style.width=`${player.hp/player.maxhp*100}%`;$('mag').textContent=w.mag;$('reserve').textContent=w.reserve+' reserve';$('weapon').textContent=weaponDisplayName(w);$('reload').textContent=reloading?'RELOADING…':w.mag===0?'R · RELOAD':'R · RELOAD';renderPerkHud();updateHudAppearance(w,g);$('cross').textContent=hitmark>0?'×':'+';$('cross').style.color=hitmark>0?'#ff4b4b':'#eef2f7';$('cross').style.opacity=hitmark>0?'1':(guns[w.type].scope||forgeAttachments(w).redDot)&&adsBlend>.78?'0':'.8';$('hitregion').textContent=hitRegionTime>0?hitRegion:'';$('damage').style.opacity=String(damageEffectStrength());$('objective').textContent=objective();$('quest-progress').textContent=fieldTask.target>=0||fieldTask.completed?fieldTaskLabel():activeMapId==='railyard'?'COOLING '+depotState.valves.filter(Boolean).length+'/3 · INDUCTION '+Math.floor(depotState.charge/40*100)+'%':questDone?'AUXILIARY SHIELD · 15% DAMAGE REDUCTION':`OPTIONAL: SALVAGE FUSES ${fuses.filter(Boolean).length}/3${fuses.every(Boolean)?' · USE POWER CABINET':''}`;$('run-tally').textContent=`${runChallenge.toUpperCase()} · ${killCount} KILLS · ${runStats.headshots} HEADSHOT KILLS`;$('zone').textContent=(player.level===1?(player.x<20?'SKYBRIDGE HALL':'UPPER BALCONY'):inFireEscape(player.x,player.y)?'FIRE ESCAPE · '+districtZone(player.x,player.y):districtZone(player.x,player.y));let n=near();$('prompt').hidden=!n;if(n){let owned=inventory.some(w=>w.type===n.type);$('prompt').textContent=`E / HOLD ${controllerLabel('interact')} · ${n.type==='box'&&boxTime>0?'ROLLING · '+guns[boxPreview].name:n.type==='box'&&boxOffer?'CLAIM '+guns[boxOffer].name+' · '+Math.ceil(boxLife)+'s':n.type==='tele'?(linked[n.id]?n.label+' • RETURN TO COMMAND RELAY — 300 PTS':n.label+' • START LINK'):n.type==='power'&&power?'POWER CABINET · OPTIONAL FIELD REPAIR':n.label}${n.cost&&!(n.type==='box'&&boxOffer)?' — '+(owned?Math.floor(n.cost/2):n.cost)+' PTS':''}`}}
// Software raycaster: deliberately no GPU requirement or external assets.
const textures=[];textures[1]=factoryTexture('concrete');textures[2]=textures[3]=factoryTexture('door');textures[4]=factoryTexture('metal');textures[5]=factoryTexture('tile');textures[6]=factoryTexture('brick');
const zombieFrames={};for(const variant of ['walker','runner','armored'])zombieFrames[variant]=Array.from({length:12},(_,i)=>undeadFrame(i,variant));const zombieLooks={};for(const variant of ['walker','runner','armored'])zombieLooks[variant]=[zombieFrames[variant],...Array.from({length:2},(_,a)=>Array.from({length:12},(_,i)=>undeadFrame(i,variant,a+1)))];const zs=zombieFrames.walker[0];
function houndSprite(){let c=document.createElement('canvas');c.width=130;c.height=100;let t=c.getContext('2d');t.fillStyle='#2f3029';t.fillRect(26,35,74,32);t.fillRect(25,62,12,33);t.fillRect(88,62,12,33);t.fillRect(46,63,10,25);t.fillRect(72,63,10,25);t.fillStyle='#514735';t.fillRect(8,22,40,30);t.fillRect(3,39,30,15);t.fillRect(10,11,10,18);t.fillRect(33,11,10,18);t.fillStyle='#f3bd65';t.fillRect(10,29,7,5);t.fillRect(30,29,7,5);t.fillStyle='#bc6034';t.fillRect(44,42,45,5);t.fillRect(56,52,25,3);t.strokeStyle='#5b513d';t.lineWidth=7;t.beginPath();t.moveTo(97,40);t.lineTo(116,25);t.stroke();return c}const hs=houndSprite();
const signs=[{x:14.5,y:15.5,label:'UTILITY BLOCK ↑'},{x:10.5,y:18.5,label:'← BANK ARCADE'},{x:21.5,y:18.5,label:'CIVIC ARCADE →'},{x:15.5,y:25.5,label:'WARDEN · BLACKOUT SECTOR'}];signs.forEach(s=>{let start=wallFixtures.length;mountFixture(s,'sign');wallFixtures.slice(start).forEach(translateFixture)});
function signSprite(label){let c=document.createElement('canvas');c.width=160;c.height=50;let t=c.getContext('2d');t.fillStyle='#514b36';t.fillRect(0,10,160,35);t.strokeStyle='#b49b63';t.strokeRect(1,11,158,33);t.fillStyle='#ded0a0';t.font='bold 12px Arial';t.textAlign='center';t.fillText(label,80,32);return c}signs.forEach(s=>s.sprite=signSprite(s.label));

function stationSprite(s){let c=document.createElement('canvas');c.width=100;c.height=130;let t=c.getContext('2d');if(['tele','base','box','trap'].includes(s.type)){t.fillStyle='#203b3e';t.fillRect(10,18,80,106);t.strokeStyle=s.type==='trap'?'#ce9865':'#74b7c0';t.lineWidth=4;t.strokeRect(10,18,80,106);t.fillStyle='#0f2528';t.fillRect(18,30,64,73);t.fillStyle=s.type==='box'?'#a1885a':'#72c4ce';if(s.type==='box'){t.fillStyle='#765836';t.fillRect(7,70,86,40);t.fillStyle='#dcc080';t.font='bold 32px Georgia';t.textAlign='center';t.fillText('?',50,101)}else{t.beginPath();t.arc(50,64,24,0,Math.PI*2);t.fill();t.fillStyle='#14383d';t.font='bold 28px Arial';t.textAlign='center';t.fillText(s.type==='trap'?'ϟ':s.type==='base'?'M':'ABC'[s.id],50,74)}t.fillStyle='#b8c8b4';t.font='8px Arial';t.textAlign='center';t.fillText(s.type.toUpperCase(),50,119)}else if(s.type==='window'){t.fillStyle='#162222';t.fillRect(5,5,90,125);t.strokeStyle='#767965';t.lineWidth=5;t.strokeRect(5,5,90,125);t.fillStyle='#4c422d';for(let i=0;i<s.w.boards;i++){t.save();t.translate(50,22+i*18);t.rotate(i%2?.1:-.12);t.fillRect(-47,-6,94,12);t.fillStyle='#b39d72';t.fillRect(-38,-2,2,2);t.fillRect(38,-2,2,2);t.fillStyle='#4c422d';t.restore()}}else if(['power','health','upgrade','ammo','speed','double'].includes(s.type)){t.fillStyle='#293a31';t.fillRect(12,8,76,118);t.strokeStyle='#6b7962';t.lineWidth=3;t.strokeRect(12,8,76,118);t.fillStyle=s.type==='health'?'#864235':s.type==='upgrade'?'#6b596f':s.type==='power'?'#ac914e':'#607359';t.fillRect(18,18,64,37);t.fillStyle='#ebe1bb';t.font='bold 22px Arial';t.textAlign='center';t.fillText(s.type==='health'?'+':s.type==='power'?'ϟ':s.type==='upgrade'?'↑':'≡',50,45);t.fillStyle='#121d17';t.fillRect(22,69,56,21);t.fillStyle='#a7b59d';t.font='8px Arial';t.fillText(s.type.toUpperCase(),50,83);t.fillStyle='#b5a878';t.fillRect(62,99,12,7)}else{t.fillStyle='#28392dc9';t.fillRect(4,45,92,50);t.strokeStyle='#9da88b';t.lineWidth=2;t.strokeRect(4,45,92,50);t.fillStyle='#c7c8a5';t.fillRect(16,66,63,7);t.fillRect(43,71,9,15);t.fillRect(18,73,20,11);t.fillStyle='#ab9564';t.font='8px Arial';t.textAlign='center';t.fillText(s.label,50,59)}return c}stations.forEach(s=>{s.sprite=perkDefinitions[s.type]||['power','upgrade','ammo'].includes(s.type)?equipmentAppearance(s):equipmentGraphic(s);if(['tele','base'].includes(s.type))s.sprite=machineDetail(s)});const barricadeSprites=Array.from({length:7},(_,boards)=>stationSprite({type:'window',w:{boards}}));
function project(x,y){let dx=x-player.x,dy=y-player.y,ca=Math.cos(player.a),sa=Math.sin(player.a),depth=dx*ca+dy*sa,side=-dx*sa+dy*ca,focal=W/(2*Math.tan(viewFov()/2));return {depth,x:W/2+side*focal/depth,size:focal/depth}}
function renderLegacy(){const horizon=horizonY();ctx.fillStyle='#182122';ctx.fillRect(0,0,W,horizon);let floor=ctx.createLinearGradient(0,horizon,0,H);floor.addColorStop(0,'#1b2522');floor.addColorStop(1,'#3b4034');ctx.fillStyle=floor;ctx.fillRect(0,horizon,W,H-horizon);let ceil=ctx.createLinearGradient(0,0,0,horizon);ceil.addColorStop(0,'#222c29');ceil.addColorStop(1,'#111b1b');ctx.fillStyle=ceil;ctx.fillRect(0,0,W,horizon);if(player.x>=10&&player.x<=22&&player.y>=15)factorySky(horizon);const fov=viewFov(),focal=W/(2*Math.tan(fov/2)),ca=Math.cos(player.a),sa=Math.sin(player.a);roomCeiling(horizon,focal);texturedFloor(horizon,focal,ca,sa,fov);

for(let x=0;x<W;x+=2){let camera=(2*x/W-1)*Math.tan(fov/2),dx=ca-sa*camera,dy=sa+ca*camera,mx=Math.floor(player.x),my=Math.floor(player.y),ddx=Math.abs(1/dx),ddy=Math.abs(1/dy),sx=dx<0?-1:1,sy=dy<0?-1:1,sdx=(dx<0?player.x-mx:mx+1-player.x)*ddx,sdy=(dy<0?player.y-my:my+1-player.y)*ddy,side=0,v=0;for(let steps=0;steps<110;steps++){if(sdx<sdy){sdx+=ddx;mx+=sx;side=0}else{sdy+=ddy;my+=sy;side=1}v=world[my]?.[mx]??1;if(v)break}let d=side?sdy-ddy:sdx-ddx;d=Math.max(.02,d);zbuffer[x]=zbuffer[x+1]=d;let wallHeight=my>=15&&mx>=9&&mx<=22?2.2:1.6,height=focal*wallHeight/d,top=horizon-focal*(wallHeight-eyeHeight())/d,wall=side?player.x+d*dx:player.y+d*dy,tx=Math.floor((wall-Math.floor(wall))*128);let material=v===1?(mx<9?4:mx>22?5:my>=15?6:1):v;let texture=material===6?(power?facadeLit:facadeUnlit):textures[material]||textures[1];ctx.drawImage(texture,tx,0,1,texture.height,x,top,2,height);for(const f of wallFixtures){if(f.kind==='fuse'&&fuses[f.object.id])continue;if(f.mx!==mx||f.my!==my||!!f.dx===!!side)continue;if(f.dx&&Math.sign(dx)!==f.dx||f.dy&&Math.sign(dy)!==f.dy)continue;let u=(wall-Math.floor(wall)-(.5-f.width/2))/f.width;if(u<0||u>1)continue;let image=f.kind==='window'?barricadeSprites[f.object.boards]:f.object.sprite;ctx.drawImage(image,u*(image.width-1),0,1,image.height,x,horizon+focal*(eyeHeight()-f.bottom-f.height)/d,2,focal*f.height/d)}let wx=player.x+d*dx,wy=player.y+d*dy,lamp=power?Math.max(0,...factoryProps.filter(p=>p.type==='lamp').map(p=>1-Math.hypot(wx-p.x,wy-p.y)/4))*.17:0;lamp*=.86+.14*Math.sin(time*17+mx*3);let cone=Math.max(0,1-Math.abs(camera)*1.6)*Math.max(0,1-d/10)*.16;let shade=Math.min(.88,Math.max(.04,(power?.13:.24)+d*.033+(side?.1:0)-lamp-cone-(flash>0?.12:0)));ctx.fillStyle=`rgba(5,14,13,${shade})`;ctx.fillRect(x,top,2,height);if(power){ctx.fillStyle=`rgba(184,167,100,${Math.max(0,.055-d*.003)})`;ctx.fillRect(x,top,2,height)}}
drawMysteryChest(horizon,focal,ca,sa,fov);let sprites=livingFallbackSprites53();for(const p of architectureProps)sprites.push({...p});for(const p of factoryProps)sprites.push({...p,kind:'prop'});for(const s of stations)if(!s.mounted&&s.type!=='box')sprites.push({...s,h:['tele','base'].includes(s.type)?.35:stationDimensions(s).h,wide:stationDimensions(s).w/stationDimensions(s).h,kind:'station'});for(const dead of corpses){let p=project(dead.x,dead.y);if(p.depth>.2&&p.x>0&&p.x<W&&p.depth<zbuffer[Math.floor(p.x)]){let fall=Math.min(1,dead.age/.65),foot=horizon+p.size*eyeHeight();ctx.save();ctx.globalAlpha=Math.min(1,dead.life/2)*.65;ctx.translate(p.x,foot);ctx.rotate((dead.deathStyle===1?-1:1)*fall*1.35);ctx.drawImage(dead.dog?hs:zombieLooks[dead.variant||'walker'][dead.appearance||0][0],-p.size*.2,-p.size*(1-fall*.5),p.size*.4,p.size*(1-fall*.5));ctx.restore()}}for(const z of zombies)if(!z.dead)sprites.push({...z,h:z.dog?.62:1.02,sprite:z.dog?hs:zombieLooks[z.variant||'walker'][z.appearance||0][Math.floor((z.walk||0)*2)%12],kind:'zombie'});for(const d of drops)sprites.push({...d,h:.28,kind:'drop'});sprites=sprites.map(s=>({...s,p:project(s.x,s.y)})).filter(s=>s.p.depth>.12).sort((a,b)=>b.p.depth-a.p.depth);for(const s of sprites){let h=s.p.size*s.h,sw=s.kind==='zombie'?h*(s.dog?1.3:.48):s.kind==='drop'?h:s.wide?h*s.wide:h*.77,left=s.p.x-sw/2,top=horizon+s.p.size*eyeHeight()-h;if(s.kind==='zombie')top+=(s.hit>0?Math.sin(s.hit*32)*h*.022:0);
if(s.kind==='zombie'||s.kind==='prop'||s.kind==='station'){const foot=horizon+s.p.size*eyeHeight();for(let px=Math.max(0,Math.floor(left));px<Math.min(W,left+sw);px+=2){if(s.p.depth>=zbuffer[px])continue;let u=(px-s.p.x)/(sw*.5),sh=Math.sqrt(Math.max(0,1-u*u))*s.p.size*.07;ctx.fillStyle='rgba(1,10,6,.24)';ctx.fillRect(px,foot-sh,2,sh*2)}}
if(s.kind==='drop'){top-=Math.sin(time*3)*5;for(let x=Math.max(0,Math.floor(left));x<Math.min(W,left+sw);x+=2)if(s.p.depth<zbuffer[x]){ctx.fillStyle=s.type==='ammo'?'#acb773':'#b46551';ctx.fillRect(x,top,2,h)}continue}for(let x=Math.max(0,Math.floor(left));x<Math.min(W,left+sw);x+=2){if(s.p.depth>=zbuffer[x]+.1)continue;let tx=(x-left)/sw*s.sprite.width;ctx.globalAlpha=Math.max(.3,1-s.p.depth*.022);ctx.drawImage(s.sprite,tx,0,Math.min(2/sw*s.sprite.width,s.sprite.width-tx),s.sprite.height,x,top,2,h);ctx.globalAlpha=1;if(s.kind==='zombie'&&s.hit>0){ctx.fillStyle='#ae423759';ctx.fillRect(x,top,2,h)}}}
for(const s of stations){if(!['tele','base'].includes(s.type))continue;let p=project(s.x,s.y);if(p.depth<.3||p.x<0||p.x>=W||p.depth>zbuffer[Math.floor(p.x)]+.15)continue;let active=s.type==='box'||s.type==='base'&&linking>=0||s.type==='tele'&&linked[s.id]||s.type==='trap'&&trapTime>0;ctx.globalAlpha=active?.28:.08;ctx.fillStyle=s.type==='trap'?'#eca44d':'#76e4e9';ctx.fillRect(p.x-p.size*.15,Math.max(0,horizon-p.size*1.7),p.size*.3,p.size*2.2);ctx.globalAlpha=1}
if(trapTime>0){for(let h of [.25,.55,.85,1.15]){let p=project(expandAxis(16,'x'),expandAxis(15,'y'));if(p.depth>.3&&p.x>0&&p.x<W&&p.depth<zbuffer[Math.floor(p.x)]){ctx.strokeStyle='#98eaff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(p.x-p.size*.95,horizon+p.size*(eyeHeight()-h));ctx.lineTo(p.x,horizon+p.size*(eyeHeight()-h)+Math.sin(time*30+h)*p.size*.05);ctx.lineTo(p.x+p.size*.95,horizon+p.size*(eyeHeight()-h));ctx.stroke()}}}
if(lightning>0){ctx.fillStyle=`rgba(91,211,236,${Math.min(.25,lightning)})`;ctx.fillRect(0,0,W,H);ctx.strokeStyle='#b5f4ff';ctx.lineWidth=2;for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(W*.6,H);for(let j=0;j<5;j++)ctx.lineTo(W*.5+(Math.random()-.5)*W*.5,H*(1-j/5));ctx.stroke()}}
for(const g of grenades){let p=project(g.x,g.y);if(p.depth>.2&&p.x>=0&&p.x<W&&p.depth<zbuffer[Math.floor(p.x)]){ctx.fillStyle=g.type==='frag'?'#9aa87c':'#82bfc7';ctx.beginPath();ctx.arc(p.x,horizon+p.size*(eyeHeight()-g.z),Math.max(2,p.size*.045),0,Math.PI*2);ctx.fill()}}
for(const b of blasts){let p=project(b.x,b.y);if(p.depth>.2&&p.x>=0&&p.x<W&&p.depth<zbuffer[Math.floor(p.x)]){let radius=p.size*(1-b.life)*1.2,cy=horizon+p.size*(eyeHeight()-.3);let glow=ctx.createRadialGradient(p.x,cy,1,p.x,cy,Math.max(2,radius));glow.addColorStop(0,b.type==='frag'?'#fff5b7c0':'#c2ecf5a0');glow.addColorStop(.4,b.type==='frag'?'#c6844470':'#6cd6e64a');glow.addColorStop(1,'#131b1800');ctx.fillStyle=glow;ctx.fillRect(p.x-radius,cy-radius,radius*2,radius*2)}}
let vignette=ctx.createRadialGradient(W/2,H*.48,H*.08,W/2,H/2,W*.72);vignette.addColorStop(0,'rgba(0,0,0,0)');vignette.addColorStop(1,'rgba(0,5,5,.54)');ctx.fillStyle=vignette;ctx.fillRect(0,0,W,H);
if(power&&W>480){for(const l of factoryProps.filter(p=>p.type==='lamp')){let p=project(l.x,l.y);if(p.depth<.5||p.x<0||p.x>=W||p.depth>zbuffer[Math.floor(p.x)])continue;let y=horizon+p.size*eyeHeight()-p.size*1.1,g=ctx.createRadialGradient(p.x,y,1,p.x,y,p.size*.45);g.addColorStop(0,'#ffe9a57a');g.addColorStop(1,'#e2b96400');ctx.fillStyle=g;ctx.fillRect(p.x-p.size*.45,y-p.size*.45,p.size*.9,p.size*.9)}}
for(const p of particles){let q=project(p.x,p.y);if(q.depth>.2&&q.x>0&&q.x<W&&q.depth<zbuffer[Math.floor(q.x)]){ctx.globalAlpha=Math.max(0,p.life/.4);ctx.fillStyle='#9e6651';ctx.fillRect(q.x,horizon+q.size*(eyeHeight()-p.z),Math.max(2,q.size*.025),Math.max(2,q.size*.025));ctx.globalAlpha=1}}
drawLivingFallbackHazards53();drawBoxOffer(horizon);environmentAtmosphere(horizon);if(mode==='playing'||mode==='paused'||mode==='dead'){signalFallbackEffects52();if(weapon().type==='signal')signalFallbackGraphic52();else weaponGraphic();}else{ctx.fillStyle='#aeb188';ctx.font='bold 12px Arial';ctx.fillText(mapCatalog[activeMapId].region,W*.65,H*.25)}drawMini();}
let solidRenderer=null,solidAttempted=false;
function ensureRenderer(){if($('renderer-mode').value!=='3d')return;if(!solidAttempted){solidAttempted=true;try{if(typeof createSolidRenderer==='function')solidRenderer=createSolidRenderer()}catch(error){console.warn('3D renderer unavailable; compatibility graphics retained',error)}}}
function renderGameplay(){if($('renderer-mode').value!=='3d'){solidAttempted=false;if(solidRenderer){solidRenderer.dispose();solidRenderer=null;solidAttempted=false}renderLegacy();drawCombatEffects();drawScope();return}if(!solidAttempted){solidAttempted=true;try{if(typeof createSolidRenderer==='function')solidRenderer=createSolidRenderer()}catch(error){console.warn('3D renderer unavailable; using compatibility graphics',error)}}if(!solidRenderer){renderLegacy();drawCombatEffects();drawScope();return}try{if(!solidRenderer.draw()){solidRenderer.dispose();solidRenderer=null;renderLegacy();drawCombatEffects();drawScope();return}}catch(error){solidRenderer.dispose();solidRenderer=null;console.warn('3D renderer stopped; using compatibility graphics',error);renderLegacy();drawCombatEffects();drawScope();return}
ctx.clearRect(0,0,W,H);for(let x=0;x<W;x+=4){let angle=player.a+Math.atan((2*x/W-1)*Math.tan(viewFov()/2)),d=.12;while(d<64&&!solid(player.x+Math.cos(angle)*d,player.y+Math.sin(angle)*d))d+=.12;let depth=d*Math.cos(angle-player.a);for(let i=0;i<4&&x+i<W;i++)zbuffer[x+i]=depth}environmentAtmosphere(horizonY());drawBoxOffer(horizonY());if(attackClock>0)knifeGraphic();drawCombatEffects();drawScope();drawMini();}
// One brief radar alert per nearby spawn group; repeated spawns do not hold it on forever.

function notifyRadarSpawn(w){if(Math.hypot(w.x-player.x,w.y-player.y)<=11&&time-radarLastAlert>4){radarPulseUntil=time+2.5;radarLastAlert=time}}
function minimapTransform(size=150){let scale=(size-8)/Math.max(world[0].length,world.length);return {size,scale,ox:(size-world[0].length*scale)/2,oy:(size-world.length*scale)/2}}
function mapStationMarkers(){
 let markers=[];for(let s of stations){let category=perkDefinitions[s.type]?'perks':s.type==='ammo'?'ammo':s.type==='box'?'box':null;if(category&&$('minimap-'+category).checked)markers.push({station:s,type:s.type,category,x:s.x,y:s.y,label:perkDefinitions[s.type]?.name||s.label})}
 // Actual active crate only: no stale markers from boxLocations or former offers.
 return markers.sort((a,b)=>(a.category==='box'?-1:a.category==='ammo'?0:1)-(b.category==='box'?-1:b.category==='ammo'?0:1));
}
function minimapMarkerLayout(markers,t=minimapTransform()){
 let placed=[];for(let m of markers){let anchor={x:t.ox+m.x*t.scale,y:t.oy+m.y*t.scale},position=null;
  for(let[dx,dy]of[[0,0],[0,-7],[7,0],[0,7],[-7,0],[7,-7],[-7,7]]){let candidate={x:Math.max(5,Math.min(t.size-5,anchor.x+dx)),y:Math.max(5,Math.min(t.size-5,anchor.y+dy))};if(!placed.some(p=>Math.hypot(p.x-candidate.x,p.y-candidate.y)<6.3)){position=candidate;break}}
  placed.push({...m,...(position||anchor),anchor});
 }return placed;
}
function drawStationMarker(m){
 let x=m.x,y=m.y;mini.save();if(Math.hypot(x-m.anchor.x,y-m.anchor.y)>1){mini.strokeStyle='#b4c4cc77';mini.lineWidth=.7;mini.beginPath();mini.moveTo(m.anchor.x,m.anchor.y);mini.lineTo(x,y);mini.stroke();mini.fillStyle='#bccbd0';mini.fillRect(m.anchor.x-.5,m.anchor.y-.5,1,1)}
 mini.translate(x,y);mini.fillStyle=m.category==='box'?'#aa8c48':m.category==='ammo'?'#638a9a':perkDefinitions[m.type].color;mini.strokeStyle='#07121d';mini.lineWidth=1.3;mini.beginPath();mini.arc(0,0,3.4,0,Math.PI*2);mini.fill();mini.stroke();let ink=m.category==='box'||['medic','pockets','double'].includes(m.type)?'#10202a':'#f1f2e7';mini.strokeStyle=ink;mini.fillStyle=ink;mini.lineWidth=.9;
 const line=(a,b,c,d)=>{mini.beginPath();mini.moveTo(a,b);mini.lineTo(c,d);mini.stroke()};
 if(m.category==='box'){mini.font='bold 6px Arial';mini.textAlign='center';mini.textBaseline='middle';mini.fillText('?',0,.1)}
 else if(m.category==='ammo'){for(let dx of[-1.2,1.2]){mini.fillRect(dx-.55,-1.4,1.1,3);line(dx-.55,-1.5,dx,-2.1);line(dx,-2.1,dx+.55,-1.5)}}
 else if(m.type==='health'){line(-1.8,0,1.8,0);line(0,-1.8,0,1.8)}
 else if(m.type==='speed'){mini.beginPath();mini.arc(0,0,1.9,0,Math.PI*2);mini.stroke();line(0,0,0,-1.4);line(0,0,1.2,.5)}
 else if(m.type==='double'){for(let dx of[-1.2,1.2]){line(dx-.6,-1.5,dx+.6,0);line(dx+.6,0,dx-.6,1.5)}}
 else if(m.type==='fleet'){for(let h of[-1.2,1.2]){line(-1.6,h,1.7,h);line(.6,h-.8,1.7,h)}}
 else if(m.type==='medic'){mini.beginPath();mini.arc(0,0,2.1,0,Math.PI*2);mini.stroke();line(-1.1,0,1.1,0);line(0,-1.1,0,1.1)}
 else if(m.type==='pockets'){mini.strokeRect(-1.6,-1.1,2.6,2.7);line(-.7,-1.8,1.7,-1.8);line(1.7,-1.8,1.7,1.1)}
 else if(m.type==='brawler'){mini.beginPath();mini.moveTo(-1.6,-1.6);mini.lineTo(1.6,-1.6);mini.lineTo(1.2,.9);mini.lineTo(0,1.9);mini.lineTo(-1.2,.9);mini.closePath();mini.stroke();line(0,-.8,0,.8)}
 mini.restore();
}
function setupMinimapSettings(){for(let category of ['perks','ammo','box']){let id='minimap-'+category,key='dead-signal-minimap-'+category,el=$(id),stored=localStorage.getItem(key);if(stored!==null)el.checked=stored==='true';el.addEventListener?.('change',()=>{try{localStorage.setItem(key,String(el.checked))}catch{}})}}

function drawMini(){
 const {size,scale,ox,oy}=minimapTransform();
 mini.clearRect(0,0,size,size);mini.fillStyle='#07121df2';mini.fillRect(0,0,size,size);
 for(let y=0;y<world.length;y++)for(let x=0;x<world[y].length;x++){mini.fillStyle=(player.level||0)===1?(upperCellOpen(x+.5,y+.5)?'#35485c':inFireEscape(x+.5,y+.5)?'#758293':'#0b1723'):world[y][x]===0?'#172b3c':world[y][x]===1?'#415369':'#9b9275';mini.fillRect(ox+x*scale,oy+y*scale,scale+.1,scale+.1)}
 for(let p of mapObstacles){if(livingPropGone53(p))continue;if(p.only3d&&$('renderer-mode').value!=='3d')continue;mini.fillStyle=p.flowObstacle?'#718088':'#314554';mini.fillRect(ox+(p.x-p.ex)*scale,oy+(p.y-p.ey)*scale,p.ex*2*scale,p.ey*2*scale)}
 for(let s of stations.filter(s=>['power','upgrade','coolant','tele','forge-control'].includes(s.type))){mini.strokeStyle='#c1ae7899';mini.lineWidth=.7;mini.beginPath();let x=ox+s.x*scale,y=oy+s.y*scale;mini.moveTo(x,y-1.6);mini.lineTo(x+1.6,y);mini.lineTo(x,y+1.6);mini.lineTo(x-1.6,y);mini.closePath();mini.stroke()}
 for(let m of minimapMarkerLayout(mapStationMarkers()))drawStationMarker(m);
 for(const d of livingPlan53().machines){const state=livingState53.machines[d.id],x=ox+d.x*scale,y=oy+d.y*scale;mini.strokeStyle=state.active>0?'#ff9460':state.on?'#72c2a2':'#90a5b6';mini.lineWidth=1;mini.strokeRect(x-1.7,y-1.7,3.4,3.4);}
 let px=ox+player.x*scale,py=oy+player.y*scale;
 if(radarPulseUntil>time){let phase=(time-radarLastAlert)%1;mini.strokeStyle=`rgba(255,70,70,${(1-phase)*.8})`;mini.lineWidth=1.5;mini.beginPath();mini.arc(px,py,6+phase*27,0,Math.PI*2);mini.stroke()}
 mini.fillStyle='#ff5252';for(let z of zombies){if(z.dead)continue;mini.beginPath();mini.arc(ox+z.x*scale,oy+z.y*scale,1.7,0,Math.PI*2);mini.fill()}
 mini.save();mini.translate(px,py);mini.rotate(player.a);mini.fillStyle='#fff';mini.strokeStyle='#09131f';mini.lineWidth=1.4;mini.beginPath();mini.moveTo(6,0);mini.lineTo(-3.5,-3.5);mini.lineTo(-1.8,0);mini.lineTo(-3.5,3.5);mini.closePath();mini.fill();mini.stroke();mini.restore();
}
function drawScope(){let g=guns[weapon()?.type];if(!g?.scope||adsBlend<.78||reloading>0||attackClock>0||!['playing','paused','dead'].includes(mode))return;let cx=W/2,cy=H/2,r=Math.min(W,H)*.425;
 ctx.save();ctx.globalAlpha=Math.min(1,(adsBlend-.78)/.17);ctx.fillStyle='#030507';ctx.beginPath();ctx.rect(0,0,W,H);ctx.arc(cx,cy,r,0,Math.PI*2,true);ctx.fill('evenodd');
 let ring=ctx.createRadialGradient(cx,cy,r*.84,cx,cy,r);ring.addColorStop(0,'#0000');ring.addColorStop(.9,'#0003');ring.addColorStop(1,'#000e');ctx.fillStyle=ring;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#080b0f';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(cx-r,cy);ctx.lineTo(cx+r,cy);ctx.moveTo(cx,cy-r);ctx.lineTo(cx,cy+r);ctx.stroke();
 ctx.lineWidth=3;ctx.beginPath();for(let dir of[-1,1]){ctx.moveTo(cx+dir*r*.42,cy);ctx.lineTo(cx+dir*r*.96,cy);ctx.moveTo(cx,cy+dir*r*.42);ctx.lineTo(cx,cy+dir*r*.96)}ctx.stroke();ctx.lineWidth=1;ctx.beginPath();for(let i=1;i<5;i++){let d=i*r*.09;ctx.moveTo(cx-4,cy+d);ctx.lineTo(cx+4,cy+d)}ctx.stroke();ctx.fillStyle='#8f1010';ctx.beginPath();ctx.arc(cx,cy,1.6,0,Math.PI*2);ctx.fill();ctx.restore();
}

function loop(t){let dt=Math.min(.04,(t-last)/1000||.016);last=t;controllerFrame=pollController();if(updateControllerMenu(controllerFrame,dt))controllerFrame=null;updateScreens(dt);if(mode==='playing')update(dt);renderScreen();requestAnimationFrame(loop)}$('stats').textContent=high?`PERSONAL BEST · ROUND ${high}`:'YOUR FIRST INTERCEPT STARTS HERE';$('challenge').disabled=false;$('challenge').onchange=showRecords;showRecords();setupControllers();requestAnimationFrame(loop);

$('software-version').textContent='VERSION '+GAME_VERSION+' DEVELOPMENT';

function showLobbyTab(tab){for(let key of['play','briefing','graphics','controller']){$('menu-'+key+'-panel').hidden=key!==tab;$('menu-'+key).setAttribute?.('aria-selected',String(key===tab))}}
function setupLobby(){for(let tab of['play','briefing','graphics','controller'])$('menu-'+tab).onclick=()=>showLobbyTab(tab);$('fov').value=fovDegrees;$('fov-value').textContent=fovDegrees+'°';$('fov').oninput=$('fov').onchange=()=>{let value=Number($('fov').value);fovDegrees=Number.isFinite(value)?Math.max(70,Math.min(110,value)):92;$('fov-value').textContent=fovDegrees+'°';try{localStorage.setItem('dead-regiment-fov',String(fovDegrees))}catch{}}}
setupLobby();

setupMaps();setupGameScreens();$('save-quit').onclick=saveAndQuit;refreshSaveMenu();
