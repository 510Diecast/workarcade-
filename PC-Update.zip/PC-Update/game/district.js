'use strict';
// World-space city plan. Rooms sit inside the expanded 46 x 44 footprint.
const districtRooms=[
 {id:'cafe',name:'NIGHT OWL CAFE',x0:13,y0:23,x1:19,y1:27,front:'east',color:[.31,.37,.34]},
 {id:'hardware',name:'BLACKRIDGE HARDWARE',x0:13,y0:31,x1:19,y1:36,front:'east',color:[.39,.31,.24]},
 {id:'pharmacy',name:'CENTRAL PHARMACY',x0:26,y0:23,x1:32,y1:27,front:'west',color:[.31,.39,.36]},
 {id:'courier',name:'METRO PARCEL SERVICE',x0:26,y0:31,x1:32,y1:36,front:'west',color:[.34,.35,.41]}
];
const districtPartitions=[
 {x0:1,y0:24,x1:12,y1:24},{x0:1,y0:34,x1:12,y1:34},{x0:7,y0:18,x1:7,y1:23},
 {x0:33,y0:24,x1:44,y1:24},{x0:33,y0:34,x1:44,y1:34},{x0:38,y0:18,x1:38,y1:23},
 {x0:25,y0:1,x1:25,y1:12}
];
const districtDoors=[
 {x:19,y:25,axis:'x',name:'CAFE',cost:500,room:'cafe'},
 {x:19,y:33,axis:'x',name:'HARDWARE STORE',cost:750,room:'hardware'},
 {x:26,y:25,axis:'x',name:'PHARMACY',cost:750,room:'pharmacy'},
 {x:26,y:33,axis:'x',name:'PARCEL DEPOT',cost:750,room:'courier'},
 {x:5,y:24,axis:'y',name:'BANK LOBBY',cost:1000},
 {x:6,y:34,axis:'y',name:'BANK RECORDS',cost:1000},
 {x:7,y:21,axis:'x',name:'BANK MANAGER OFFICE',cost:600},
 {x:39,y:24,axis:'y',name:'CIVIC OFFICES',cost:1000},
 {x:39,y:34,axis:'y',name:'SERVICE GARAGE',cost:1000},
 {x:38,y:21,axis:'x',name:'SECURITY OFFICE',cost:600},
 {x:25,y:6,axis:'x',name:'UTILITY CONTROL ROOM',cost:1000}
];
// These rear doors create paid shortcuts between storefronts and the side streets.
districtDoors.push({x:13,y:33,axis:'x',name:'HARDWARE REAR EXIT',cost:500,room:'hardware'},
 {x:32,y:33,axis:'x',name:'DEPOT REAR EXIT',cost:500,room:'courier'});
const districtWallCells=new Set();
function applyDistrictGrid(rows){const m=rows.map(r=>r.split(''));
 function wall(x,y){m[y][x]='1';districtWallCells.add(x+','+y)}
 // The old expansion duplicated a two-cell connector into an eight-cell bypass.
 for(let y=13;y<=20;y++)for(let x=21;x<=26;x++)wall(x,y);
 for(const r of districtRooms){for(let x=r.x0;x<=r.x1;x++){wall(x,r.y0);wall(x,r.y1)}for(let y=r.y0;y<=r.y1;y++){wall(r.x0,y);wall(r.x1,y)}}
 for(const r of districtPartitions)for(let y=r.y0;y<=r.y1;y++)for(let x=r.x0;x<=r.x1;x++)wall(x,y);
 for(const d of districtDoors)m[d.y][d.x]='2';
 return m.map(r=>r.join(''));
}
function districtWallHeight(x,y){if(typeof livingWallCells53!=='undefined'&&livingWallCells53.has(x+','+y))return 3.5;let r=districtRooms.find(r=>x>=r.x0&&x<=r.x1&&y>=r.y0&&y<=r.y1);return r?3.5:1.6}
const cityProps=[
 {type:'car',x:22.5,y:30.8,ex:.58,ey:1.30,color:[.23,.31,.32]},
 {type:'car',x:24.5,y:38.5,ex:.58,ey:1.30,color:[.37,.29,.23]},
 {type:'planter',x:23.6,y:22.6,ex:.85,ey:.38},
 {type:'planter',x:16.0,y:38.5,ex:1.05,ey:.40},
 {type:'planter',x:29.3,y:37.7,ex:.95,ey:.40},
 {type:'counter',x:16.0,y:25.8,ex:1.10,ey:.30},
 {type:'shelf',x:16.35,y:32.45,ex:1.05,ey:.25},
 {type:'counter',x:29.7,y:24.3,ex:1.05,ey:.28},
 {type:'parcel',x:30.5,y:34.7,ex:.65,ey:.45},
 {type:'counter',x:4.0,y:26.5,ex:1.60,ey:.32},
 {type:'counter',x:3.8,y:21.7,ex:.70,ey:.40},
 {type:'desk',x:10.2,y:20.4,ex:.65,ey:.35},
 {type:'shelf',x:3.5,y:36.5,ex:1.15,ey:.28},
 {type:'desk',x:35.5,y:20.5,ex:.75,ey:.40},
 {type:'desk',x:41.5,y:22.2,ex:.80,ey:.40},
 {type:'counter',x:42.3,y:32.0,ex:1.30,ey:.30},
 {type:'van',x:37.0,y:38.0,ex:.70,ey:1.55,color:[.36,.38,.32]},
 {type:'parcel',x:42.0,y:37.3,ex:.65,ey:.55},
 {type:'desk',x:29.5,y:8.2,ex:1.10,ey:.40},
 {type:'counter',x:4,y:19.1,ex:.90,ey:.30},
 {type:'seat',x:2.5,y:22.7,ex:1,ey:.28},
 {type:'shelf',x:11.4,y:32.0,ex:.30,ey:.85},
 {type:'seat',x:34.6,y:27.0,ex:1,ey:.30},
 {type:'counter',x:33.8,y:30.8,ex:.30,ey:.90}
];
const districtWeapons={
 burst:{name:'TRIAD BURST RIFLE',cap:30,max:240,damage:53,rate:.42,reload:2.15,range:25,color:'#7d9389',shape:'rifle',weight:15,burst:3,barrel:.31},
 lever:{name:'FRONTIER LEVER RIFLE',cap:8,max:96,damage:185,rate:.72,reload:.62,shellTime:.62,range:28,color:'#ab895c',shape:'marksman',weight:12,pierce:2,semi:true,barrel:.43},
 pdw:{name:'KESTREL PDW',cap:50,max:300,damage:31,rate:.072,reload:2.3,range:18,color:'#85958f',shape:'compact',weight:16,barrel:.17},
 combatsg:{name:'RIOT COMBAT SHOTGUN',cap:8,max:72,damage:195,rate:.68,reload:.55,shellTime:.55,range:11,color:'#8d9789',shape:'shotgun',weight:14,pellets:true,pump:true,barrel:.34},
 battlerifle:{name:'CITADEL BATTLE RIFLE',cap:20,max:180,damage:125,rate:.28,reload:2.4,range:30,color:'#a4a893',shape:'rifle',weight:13,pierce:2,semi:true,barrel:.39},
 machinepistol:{name:'JACKAL MACHINE PISTOL',cap:24,max:216,damage:35,rate:.08,reload:1.5,range:14,color:'#939f93',shape:'compact',weight:17,sidearm:true,barrel:.16}
};
function installDistrict(){
 const names=['OPEN BANK ARCADE','OPEN CIVIC ARCADE','OPEN UTILITY BLOCK','OPEN BANK SERVICE ALLEY','OPEN CIVIC SERVICE ALLEY'];
 gates.forEach((g,i)=>g.label=names[i]||g.label);
 for(const d of districtDoors)gates.push({x:d.x+.5,y:d.y+.5,type:'gate',label:'OPEN '+d.name,cost:d.cost,cells:[[d.x,d.y]],axis:d.axis,city:true,room:d.room});
 const ammo=stations.find(s=>s.type==='ammo');ammo.y=25.5;
 // New purchases are secured to an interior wall, with a clear approach.
 for(const [type,x,y,dx,dy,cost] of [['scout',17.5,28.5,0,-1,2000],['sniper',30.5,35.5,0,1,2600],['lever',16.5,35.5,0,1,1500],['burst',10.5,18.5,0,-1,1700],['pdw',29.5,32.5,0,-1,1400],['combatsg',29.5,26.5,0,1,1600],['battlerifle',44.5,21.5,1,0,2000]]){
  const s={type,x,y,label:guns[type].name,cost,mounted:true};stations.push(s);
  wallFixtures.push({x,y,mx:Math.floor(x+dx),my:Math.floor(y+dy),dx,dy,kind:'weapon',object:s,height:.48,bottom:.65,width:.82});
 }
 for(let i=cityProps.length-1;i>=0;i--)if(blocksDoorPath(cityProps[i]))cityProps.splice(i,1);
 for(const p of cityProps){mapObstacles.push({...p});architectureProps.push({x:p.x,y:p.y,kind:'prop',h:p.type==='shelf'?1:p.type==='van'?.85:.65,wide:Math.max(1,p.ex*3),sprite:cityPropGraphic(p)})}
}
function cityPropGraphic(p){
 const c=document.createElement('canvas');c.width=180;c.height=120;const t=c.getContext('2d');
 t.fillStyle='#384643';
 if(p.type==='car'||p.type==='van'){
  t.fillRect(12,55,156,42);t.fillRect(38,24,105,39);t.fillStyle='#122528';t.fillRect(48,29,82,28);
  t.fillStyle='#131a18';t.fillRect(18,86,28,25);t.fillRect(133,86,28,25);t.fillStyle='#a6a17d';t.fillRect(20,66,24,10);t.fillRect(139,66,22,10);
 }else if(p.type==='planter'){
  t.fillStyle='#747569';t.fillRect(10,56,160,58);t.fillStyle='#384d32';for(let i=0;i<6;i++){t.beginPath();t.arc(26+i*25,51,19,0,Math.PI*2);t.fill()}
 }else if(p.type==='shelf'){
  t.fillRect(9,8,9,108);t.fillRect(164,8,9,108);for(let y of[32,69,109]){t.fillRect(9,y,163,6);t.fillStyle='#877348';for(let x of[25,70,116])t.fillRect(x,y-25,33,24);t.fillStyle='#384643'}
 }else{t.fillStyle='#70644a';t.fillRect(10,50,160,17);t.fillStyle='#39423a';t.fillRect(17,67,146,44);t.fillStyle='#202f2c';t.fillRect(69,29,43,24)}
 return c;
}
const districtSignCache=new Map();
function districtSign(text,sub='DEAD SIGNAL · CIVIL DEFENSE SECTOR',aspect=4){
 const key=text+'|'+sub+'|'+aspect;if(districtSignCache.has(key))return districtSignCache.get(key);
 const c=document.createElement('canvas');c.width=768;c.height=Math.round(c.width/aspect);const t=c.getContext('2d'),h=c.height;
 t.fillStyle='#1c302f';t.fillRect(0,0,768,h);t.strokeStyle='#b2a77b';t.lineWidth=5;t.strokeRect(6,6,756,h-12);t.textAlign='center';
 function line(label,y,font,color){let size=font;t.font='bold '+size+'px Arial';let width=t.measureText?.(label)?.width||label.length*size*.58;if(width>700){size*=700/width;t.font='bold '+size+'px Arial'}t.fillStyle=color;t.fillText(label,384,y)}
 line(text,h*.48,Math.min(50,h*.35),'#e0d7b8');line(sub,h*.79,Math.min(24,h*.16),'#aeb8a8');districtSignCache.set(key,c);return c;
}

function districtZone(x,y){if(activeMapId==='railyard'){let room=districtRooms.find(r=>x>r.x0&&x<r.x1&&y>r.y0&&y<r.y1);return room?.name||(y>36?'ARRIVAL PLATFORM':y<15?'REACTOR APPROACH':y<25?'WAREHOUSE SERVICE YARD':'FREIGHT CONCOURSE')}const room=districtRooms.find(r=>x>r.x0&&x<r.x1+1&&y>r.y0&&y<r.y1+1);if(room)return room.name;if(y<18)return x>=25?'UTILITY CONTROL':'UTILITY BLOCK';if(x<13)return y<24?(x<7?'BANK LOBBY':'MANAGER OFFICE'):y>34?'BANK RECORDS':'BANK ARCADE';if(x>=33)return y<24?(x<38?'CIVIC OFFICES':'SECURITY OFFICE'):y>34?'SERVICE GARAGE':'CIVIC ARCADE';return y>=37?'COMMERCE SQUARE':'CENTRAL STREET'}

// Railyard building names occupy the masonry band above the low door/shutter
// signs and below the first upstairs windows. City facades retain their layout.
function districtFacadeSign(r){return {x:r.front==='east'?r.x1+1.06:r.x0-.06,y:activeMapId==='railyard'?1.90:1.40,z:(r.y0+r.y1+1)/2,w:3.4,h:activeMapId==='railyard'?.32:.40}}

// Keep a traversable landing on each side of every paid opening.
function blocksDoorPath(p){return gates.some(g=>g.cells.some(([x,y])=>{const side=g.axis?g.axis==='x':originalAxis(x,'x')===9||originalAxis(x,'x')===22;return Math.abs(p.x-x-.5)<(p.ex||0)+(side?1.45:.65)&&Math.abs(p.y-y-.5)<(p.ey||0)+(side?.65:1.45)}))}
const interiorZones=[
 {id:'bank',x0:1,y0:18,x1:12,y1:33,floor:[.43,.40,.32],trim:[.32,.24,.17],kind:14},
 {id:'civic',x0:33,y0:18,x1:44,y1:33,floor:[.31,.40,.40],trim:[.23,.34,.34],kind:14},
 {id:'utility',x0:11,y0:1,x1:34,y1:12,floor:[.22,.27,.28],trim:[.35,.39,.36],kind:14},
 {id:'cafe',x0:14,y0:24,x1:18,y1:26,floor:[.44,.31,.19],trim:[.37,.29,.20],kind:15},
 {id:'pharmacy',x0:27,y0:24,x1:31,y1:26,floor:[.54,.58,.53],trim:[.32,.49,.40],kind:14}
];

// Connected second floor spanning both buildings; ground passage remains open.
const UPPER_HEIGHT=1.8;
function inFireEscape(x,y){if(activeMapId!=='blackridge')return false;return x>=20&&x<=22&&y>=34&&y<=39}
function stairHeight(x,y){return inFireEscape(x,y)?Math.max(0,Math.min(1.8,Math.floor((39-y)/5*18+.00001)*.1)):0}
let upperUnlocked=false;
const upperAccessGate={x:20.20,y:33.5,type:'uppergate',cost:1250,label:'OPEN SKYBRIDGE HALL'};
function upperFloorCell(x,y){if(activeMapId!=='blackridge')return false;x=Math.floor(x);y=Math.floor(y);return(x>=20&&x<=21&&y>=23&&y<=33)||(x>=14&&x<=18&&y>=24&&y<=35)||upperDoorCell(x,y)}
function upperCellOpen(x,y){let cx=Math.floor(x),cy=Math.floor(y);return upperFloorCell(x,y)&&((cx>=20&&cx<=21)||upperUnlocked)}
function upperDoorCell(x,y){if(activeMapId!=='blackridge')return false;return x===19&&y===33}
function upperDividerCell(x,y){if(activeMapId!=='blackridge')return false;return x>=14&&x<=18&&(y===27||y===31)}
function upperBridgeWall(x,y){return(x===13||x===19)&&y>=28&&y<=30}
function actorElevation(o){return inFireEscape(o.x,o.y)?stairHeight(o.x,o.y):(o.level||0)*UPPER_HEIGHT}
function actorLevelAt(o,x,y){if(inFireEscape(x,y))return 0;if((o.level||0)===1)return 1;if(actorElevation(o)>1.59&&upperCellOpen(x,y))return 1;return 0}
const upperProps=[{x:15.2,y:30.0,ex:.8,ey:.28,type:'desk'},{x:15.2,y:24.65,ex:.70,ey:.25,type:'desk'},{x:15.4,y:34.65,ex:.85,ey:.27,type:'desk'},{x:17.8,y:26.3,ex:.4,ey:.22,type:'cabinet'}];

// Authored maps share combat, but own geometry, fixtures, spawn windows and Forge progression.
const mapCatalog={blackridge:{name:'Blackridge',region:'BLACKRIDGE BUSINESS DISTRICT',description:'A city communications blackout. Search shuttered storefronts, service alleys and the skybridge for three surviving uplinks.',forge:'Power → link three teleporters → Forge',doors:18},railyard:{name:'Railyard 09',region:'RAILYARD 09',description:'A military relay buried inside a freight terminal. Push through checkpoints, restore cooling and synchronize the induction hall.',forge:'Power → three coolant valves → hold the induction charge',doors:14}};
const signalLore={
 blackridge:{frequency:'91.6',band:'CIVIL BAND',intro:'At 02:17, Blackridge’s emergency network began repeating a message nobody sent. The streets fell silent. The dead kept listening.',story:'Blackridge was the first place to hear the Dead Signal. Emergency receivers carried the same voice, even after their transmitters lost power. Three teleporter uplinks hold the remaining fragments.',route:'Open the utility block and restore power. Activate each teleporter, then confirm its link at the command relay before the timer expires. Three linked carriers unlock Forge-a-Punch.',firstTransmission:'Intercept 02:17: “Do not answer the voice.” Restore power. Trace the uplinks.'},
 railyard:{frequency:'73.9',band:'MILITARY RELAY',intro:'Railyard 09 was supposed to relay the evacuation order. The last train never left. Somewhere beyond the warehouses, the carrier is still alive.',story:'The Warden Signal Corps routed its final transmission through Railyard 09. The coolant network failed before the uplink could shut down. Its induction array is still repeating the blackout signal.',route:'Buy passage through the freight checkpoints. Restore reactor power and open all three coolant valves. Start the induction switch and hold the hall for 40 seconds; leaving pauses the charge. The synchronized relay unlocks Forge-a-Punch.',firstTransmission:'Relay intercept: “No outbound traffic. No evacuation.” Reach reactor control.'}
};
let activeMapId='blackridge',mapLoadedId='blackridge',mapRevision=0,blackridgeSnapshot=null,depotState={valves:[false,false,false],charging:false,charge:0,ready:false};
function mapLists(){return {gates,stations,windows,wallFixtures,factoryProps,mapObstacles,architectureProps,cityProps,districtRooms,districtPartitions,districtDoors,interiorZones,signs,boxLocations}}
function captureBlackridge(){if(blackridgeSnapshot)return;blackridgeSnapshot={lists:Object.fromEntries(Object.entries(mapLists()).map(([k,v])=>[k,v.slice()])),template:template.slice(),walls:[...districtWallCells],base:{...base},trap:{...trapZone}}}
function applySelectedMap(){if(!blackridgeSnapshot||mapLoadedId===activeMapId)return;
 if(activeMapId==='blackridge'){for(let[k,a]of Object.entries(mapLists()))a.splice(0,a.length,...blackridgeSnapshot.lists[k]);template=blackridgeSnapshot.template.slice();districtWallCells.clear();blackridgeSnapshot.walls.forEach(v=>districtWallCells.add(v));Object.assign(base,blackridgeSnapshot.base);Object.assign(trapZone,blackridgeSnapshot.trap)}else buildRailyard();
 mapLoadedId=activeMapId;mapRevision++;navCache=null;navDistances=null;skyPanorama=null;equipmentArt.clear();districtSignCache.clear();
}
// Authored route islands. These share footprints with navigation and minimap rendering.
const mapFlowPlans={
 blackridge:[
  {id:'commerce-roadworks',type:'roadworks',x:16.8,y:40.0,ex:1.5,ey:.48,h:.55,label:'ROAD CLOSED / CITY WORKS'},
  {id:'street-diversion',type:'barricade',x:24.8,y:29.0,ex:.60,ey:.30,h:.48,label:'DIVERSION'},
  {id:'civil-supply-island',type:'roadworks',x:28.4,y:39.8,ex:1.3,ey:.45,h:.52,label:'CIVIL DEFENSE'},
  {id:'evacuation-vehicle',type:'ambulance',x:34.5,y:39.5,ex:.70,ey:1.55,h:.92,label:'EVACUATION STOPPED'}
 ],
 railyard:[
  // Primary clearance: 2*.44 player diameters + .16 separation + .24 wall margin = 1.28.
  // The loading apron begins at warehouse back face y=38 and ends at perimeter y=42.
  {id:'arrival-freight-car',type:'freight-car',x:9.8,y:39.92,ex:3.2,ey:.62,h:1.4,colliderHeight:1.62,label:'WARDEN / FREIGHT 09'},
  {id:'arrival-container',type:'container',x:37.2,y:40.0,ex:2.2,ey:.72,h:1.55,label:'RELAY CARGO'},
  {id:'concourse-maintenance',type:'container',x:17.8,y:32.3,ex:.75,ey:1.12,h:1.40,label:'MAINTENANCE BAY'},
  {id:'dispatch-cargo-island',type:'cargo-stack',x:29.0,y:3.4,ex:1.5,ey:.42,h:.82,label:'OUTBOUND HELD'}
 ]
};
function installMapFlow(){
 const ids=new Set(mapObstacles.filter(p=>p.flowObstacle).map(p=>p.id));
 for(let definition of mapFlowPlans[activeMapId])if(!ids.has(definition.id)){mapObstacles.push({...definition,flowObstacle:true});architectureProps.push({x:definition.x,y:definition.y,kind:'prop',h:definition.h,wide:definition.ex*2,sprite:cityPropGraphic({...definition,type:definition.type==='ambulance'?'van':'parcel'})})}
 if(activeMapId==='railyard'){
  for(let i=factoryProps.length-1;i>=0;i--)if(factoryProps[i].type==='lamp')factoryProps.splice(i,1);
  for(let i=mapObstacles.length-1;i>=0;i--)if(mapObstacles[i].type==='lamp')mapObstacles.splice(i,1);
  let ammo=stations.find(s=>s.type==='ammo');if(ammo){ammo.x=25;ammo.y=41.58;ammo.wallDX=0;ammo.wallDY=1;ammo.rotation=Math.PI}
 }
}
function reconcileFlowSave(){
 let actors=[player,...zombies.filter(z=>!z.wait&&!z.dead)];
 for(let actor of actors){let r=actor===player?.22:.19;if((actor.level||0)!==0)continue;
  for(let p of mapObstacles.filter(p=>p.flowObstacle))if(Math.abs(actor.x-p.x)<p.ex+r&&Math.abs(actor.y-p.y)<p.ey+r){
   let candidates=[{x:p.x-p.ex-r-.03,y:actor.y},{x:p.x+p.ex+r+.03,y:actor.y},{x:actor.x,y:p.y-p.ey-r-.03},{x:actor.x,y:p.y+p.ey+r+.03}].sort((a,b)=>Math.hypot(a.x-actor.x,a.y-actor.y)-Math.hypot(b.x-actor.x,b.y-actor.y));
   let spot=candidates.find(c=>canMove(c.x,c.y,r,actor));if(spot){actor.x=spot.x;actor.y=spot.y;actor.cameraBase=actorElevation(actor)}
  }
 }
}

function buildRailyard(){
 for(let a of Object.values(mapLists()))a.splice(0);districtWallCells.clear();const m=Array.from({length:44},(_,y)=>Array.from({length:46},(_,x)=>x>=2&&x<=43&&y>=2&&y<=41?0:1));
 const rooms=[['receiving','RECEIVING DEPOT',5,27,14,37,'east'],['machine','MACHINE SHOP',31,27,40,37,'west'],['cargo','CARGO WAREHOUSE',5,5,15,22,'east'],['dispatch','DISPATCH WAREHOUSE',30,5,40,22,'west'],['reactor','REACTOR CONTROL',19,5,26,13,'west'],['induction','INDUCTION HALL',19,18,26,29,'east']];
 for(let[id,name,x0,y0,x1,y1,front]of rooms){let r={id,name,x0,y0,x1,y1,front,color:id==='reactor'?[.34,.40,.42]:id==='induction'?[.42,.31,.23]:[.34,.38,.37]};districtRooms.push(r);for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){let wall=x===x0||x===x1||y===y0||y===y1;m[y][x]=wall?1:0;if(wall)districtWallCells.add(x+','+y)}interiorZones.push({id,x0:x0+1,y0:y0+1,x1:x1-1,y1:y1-1,floor:id==='induction'?[.31,.34,.36]:[.33,.36,.35],trim:[.26,.30,.31],kind:14})}
 for(let[x,y,axis,name,cost,room]of[[14,33,'x','RECEIVING DEPOT',750,'receiving'],[5,30,'x','RECEIVING REAR EXIT',500,'receiving'],[31,33,'x','MACHINE SHOP',750,'machine'],[40,30,'x','MACHINE SHOP REAR EXIT',500,'machine'],[15,17,'x','CARGO WAREHOUSE',1000,'cargo'],[10,22,'y','CARGO LOADING DOOR',600,'cargo'],[30,17,'x','DISPATCH WAREHOUSE',1000,'dispatch'],[36,22,'y','DISPATCH LOADING DOOR',600,'dispatch'],[23,13,'y','REACTOR CONTROL',1250,'reactor'],[22,29,'y','INDUCTION HALL',1000,'induction'],[26,27,'x','INDUCTION SERVICE DOOR',600,'induction']]){m[y][x]=2;gates.push({x:x+.5,y:y+.5,type:'gate',label:'OPEN '+name,cost,cells:[[x,y]],axis,city:true,room})}
 // Solid checkpoint partitions terminate on the room/perimeter walls.
 // Existing three-unit side lanes are retained; the shutter apertures are also three units wide.
 for(let[y,ranges]of[[36,[[2,4],[15,30],[41,43]]],[24,[[2,18],[27,43]]]])for(let[a,b]of ranges)for(let x=a;x<=b;x++){m[y][x]=1;districtWallCells.add(x+','+y)}
 for(let[x,y,name,cost]of[[22,36,'FREIGHT CONCOURSE',750],[16,24,'WEST WAREHOUSE PASSAGE',1000],[27,24,'EAST WAREHOUSE PASSAGE',1000]]){let cells=[[x,y],[x+1,y],[x+2,y]];for(let[a,b]of cells)m[b][a]=2;gates.push({x:x+1.5,y:y+.5,type:'gate',label:'OPEN '+name,cost,cells,axis:'y',city:true,checkpoint:true})}
 template=m.map(r=>r.join(''));Object.assign(base,{x:23,y:40});Object.assign(trapZone,{x0:-10,x1:-9,y0:-10,y1:-9});
 function fixture(o,kind,dx,dy){o.mounted=true;stations.includes(o)||kind==='window'||stations.push(o);wallFixtures.push({x:o.x,y:o.y,mx:Math.floor(o.x+dx),my:Math.floor(o.y+dy),dx,dy,object:o,kind,height:kind==='window'?1.12:kind==='coolant-valve'?.42:.48,bottom:kind==='window'?.12:.65,width:kind==='window'?.84:kind==='coolant-valve'?.42:.82})}
 for(let[x,y,dx,dy]of[[7.5,41.5,0,1],[20.5,41.5,0,1],[38.5,41.5,0,1],[6.5,15.5,-1,0],[39.5,15.5,1,0],[20.5,6.5,0,-1],[6.5,33.5,-1,0],[39.5,34.5,1,0]]){let w={x,y,boards:6,timer:0};windows.push(w);fixture(w,'window',dx,dy)}
 for(let[type,x,y,dx,dy,cost]of[['pistol',16.5,41.5,0,1,300],['silenced',29.5,41.5,0,1,650],['smg',13.5,28.5,1,0,750],['shotgun',39.5,28.5,1,0,1200],['rifle',14.5,8.5,1,0,1500],['scout',25.5,10.5,1,0,2300],['lmg',31.5,7.5,-1,0,2200],['interceptor',39.5,20.5,1,0,2800]])fixture({type,x,y,label:guns[type].name,cost},'weapon',dx,dy);
 for(let[type,x,y,dx,dy]of[['health',6.4,35.5,-1,0],['speed',39.6,35.5,1,0],['double',6.4,7,-1,0],['fleet',15.36,28.5,-1,0],['medic',39.6,18.5,1,0],['pockets',30.6,35.5,1,0],['brawler',20.4,20.5,-1,0],['power',21.5,6.38,0,-1],['upgrade',25.40,26.5,1,0],['ammo',25,40.8,0,1]]){let p=perkDefinitions[type];stations.push({type,x,y,mounted:false,wallDX:dx,wallDY:dy,rotation:Math.atan2(dx,dy),cost:p?.cost||(type==='upgrade'?5000:type==='ammo'?350:0),label:p?p.name+' · '+p.effect:type==='power'?'RESTORE REACTOR POWER':type==='upgrade'?'FORGE-A-PUNCH · UPGRADE HELD WEAPON':'AMMUNITION CACHE'})}
 boxLocations.push({x:10.5,y:34.5},{x:36.5,y:34.5},{x:7.5,y:18.5},{x:38.5,y:18.5});stations.push({x:10.5,y:34.5,type:'box',label:'MYSTERY CRATE',cost:950});
 for(let[id,x,y,dx,dy]of[[0,6.5,10.5,-1,0],[1,39.5,10.5,1,0],[2,39.5,32.5,1,0]]){let o={id,x,y,type:'coolant',label:'OPEN COOLANT VALVE '+(id+1),cost:0};fixture(o,'coolant-valve',dx,dy);mapObstacles.push({x:x+dx*.39,y:y+dy*.39,ex:.10,ey:.10,type:'valve'})}
 fixture({x:20.5,y:26.5,type:'forge-control',label:'START INDUCTION CHARGE',cost:0},'forge-control',-1,0);mapObstacles.push({x:20.10,y:26.5,ex:.12,ey:.18,type:'induction-switch'});
 for(let[type,x,y,ex,ey]of[['parcel',20,35,.8,.7],['parcel',25.5,33,.7,.8],['parcel',17.5,25,.6,.6],['parcel',28.5,25,.6,.6],['parcel',9.5,13,1.2,.7],['shelf',12.5,10,.25,1.2],['parcel',35.5,13,1.2,.7],['shelf',38.2,9,.25,1.3],['counter',8,29.8,1.1,.3],['desk',36,29.8,.7,.4],['parcel',8,35,.7,.6],['parcel',37.5,35,.7,.6],['counter',24.2,8.5,.8,.3]]){let p={type,x,y,ex,ey};if(blocksDoorPath(p))continue;cityProps.push(p);mapObstacles.push({...p});architectureProps.push({x,y,kind:'prop',h:type==='shelf'?1:.65,wide:Math.max(1,ex*3),sprite:cityPropGraphic(p)})}
 for(let[x,y]of[[17.5,40],[29.5,40],[15.2,25.6],[30.8,25.6],[16.10,14.5],[29.90,14.5]]){let p={x,y,type:'lamp',h:1.3};factoryProps.push(p);mapObstacles.push({...p,ex:.08,ey:.08})}
 installMapFlow();
}
function forgeReady(){return power&&(activeMapId==='railyard'?depotState.ready:linked.every(Boolean))}
function resetMapProgress(){depotState={valves:[false,false,false],charging:false,charge:0,ready:false}}
function updateMapProgress(dt){if(activeMapId!=='railyard'||!depotState.charging||depotState.ready)return;let inHall=player.x>20&&player.x<26&&player.y>19&&player.y<29&&(player.level||0)===0;if(!inHall)return;depotState.charge=Math.min(40,depotState.charge+dt);if(depotState.charge>=40){depotState.ready=true;depotState.charging=false;banner('RAILYARD FORGE ONLINE',4);tell('Induction complete. Forge your held weapon at the hall machine.')}}
function mapObjective(){if(!power){let closed=g=>g?.cells.some(([x,y])=>world[y]?.[x]!==0);if(closed(gates.find(g=>g.label==='OPEN FREIGHT CONCOURSE')))return 'FREIGHT CHECKPOINT · 750 POINTS';if(gates.filter(g=>g.checkpoint&&g.y===24.5).every(closed))return 'WAREHOUSE PASSAGE · 1000 PTS · REACTOR BEYOND';return 'OPEN REACTOR CONTROL · RESTORE POWER';}if(!depotState.valves.every(Boolean))return 'OPEN COOLANT VALVES · '+depotState.valves.filter(Boolean).length+'/3';if(!depotState.charging&&!depotState.ready)return 'INDUCTION HALL · START THE CHARGE SWITCH';if(depotState.ready)return 'FORGE ONLINE · UPGRADE YOUR WEAPONS';return 'HOLD THE INDUCTION HALL · '+Math.floor(depotState.charge/40*100)+'% CHARGED'}
function mapInteraction(n){if(activeMapId!=='railyard'||!['coolant','forge-control'].includes(n.type))return false;if(!power){tell('Restore reactor power first');return true}if(n.type==='coolant'){if(depotState.valves[n.id]){tell('This coolant valve is already open');return true}depotState.valves[n.id]=true;pathClock=0;banner('COOLANT LINE '+(n.id+1)+' ONLINE');tell(depotState.valves.every(Boolean)?'Cooling ready. Start the induction switch in the central hall.':depotState.valves.filter(Boolean).length+'/3 coolant valves open');return true}if(!depotState.valves.every(Boolean)){tell('Open all three coolant valves first');return true}if(depotState.ready){tell('The Forge is already online');return true}if(depotState.charging){tell('Remain inside the induction hall to continue charging');return true}depotState.charging=true;banner('INDUCTION CYCLE STARTED');tell('Hold the hall for 40 seconds. Leaving pauses the charge.');return true}
function refreshMapArt(){for(let s of stations){s.sprite=['coolant','forge-control'].includes(s.type)?mapControlGraphic(s):perkDefinitions[s.type]||['power','upgrade','ammo'].includes(s.type)?equipmentAppearance(s):equipmentGraphic(s);if(['tele','base'].includes(s.type))s.sprite=machineDetail(s)}for(let s of signs)s.sprite=signSprite(s.label)}
function mapControlGraphic(s){let c=document.createElement('canvas');c.width=400;c.height=240;let t=c.getContext('2d');t.fillStyle='#17242b';t.fillRect(0,0,400,240);t.strokeStyle='#7e9d9d';t.lineWidth=8;t.strokeRect(8,8,384,224);t.strokeStyle=s.type==='coolant'?'#b9af76':'#7da9bd';t.lineWidth=13;t.beginPath();t.arc(200,112,63,0,Math.PI*2);t.stroke();for(let a=0;a<Math.PI*2;a+=Math.PI/2){t.beginPath();t.moveTo(200,112);t.lineTo(200+Math.cos(a)*62,112+Math.sin(a)*62);t.stroke()}t.fillStyle='#dce4d7';t.font='bold 22px Arial';t.textAlign='center';t.fillText(s.type==='coolant'?'COOLANT '+(s.id+1):'INDUCTION CHARGE',200,213);return c}
function selectMap(id){if(!mapCatalog[id])id='blackridge';if(id!==activeMapId&&round>0)saveRunRecord();activeMapId=id;reset();refreshMapArt();mode='menu';if(typeof refreshSaveMenu==='function')refreshSaveMenu();$('challenge').disabled=false;$('stats').textContent='';$('hud').style.display='none';$('overlay').style.display='flex';$('start').textContent='DEPLOY TO '+mapCatalog[id].name.toUpperCase()+' →';$('new').hidden=true;$('lobby-state').textContent='Establish contact';$('intro').textContent=mapCatalog[id].description;$('map-description').textContent=mapCatalog[id].description;$('map-forge').textContent=mapCatalog[id].forge;$('map-doors').textContent=mapCatalog[id].doors;$('lobby-region').textContent=mapCatalog[id].region;$('lobby-route').textContent=mapCatalog[id].forge;showRecords();syncSignalLobby();try{localStorage.setItem('dead-regiment-map',id)}catch{}}
function setupMaps(){installMapFlow();captureBlackridge();let selected='blackridge';try{let saved=localStorage.getItem('dead-regiment-map');if(mapCatalog[saved])selected=saved}catch{}$('map-choice').value=selected;$('map-choice').onchange=()=>selectMap($('map-choice').value);selectMap(selected)}

function railyardWallLights(){if(activeMapId!=='railyard')return [];return districtRooms.map(r=>({x:r.front==='east'?r.x1+1.012:r.x0-.012,y:r.id==='receiving'||r.id==='machine'?31:r.id==='reactor'?9.5:r.id==='induction'?21.5:12.5,dx:r.front==='east'?1:-1,dy:0}))}
