'use strict';
// v5.3: plain authoritative map state. Rendering, audio and input remain consumers.
const LIVING_WIDTH53=62;
const livingPlans53={
 blackridge:{
  rooms:[{id:'police53',name:'BLACKRIDGE POLICE ANNEX',x0:49,y0:22,x1:60,y1:38,front:'west',color:[.34,.39,.40]},{id:'exchange53',name:'MUNICIPAL SIGNAL EXCHANGE',x0:49,y0:4,x1:60,y1:18,front:'west',color:[.39,.34,.29]}],
  corridors:[[44,27,50,29],[46,12,48,30],[48,14,50,16],[34,6,50,8]],
  gates:[{id:'police-entry',name:'POLICE ANNEX',x:45,y:27,axis:'x',cost:1000},{id:'exchange-entry',name:'SIGNAL EXCHANGE',x:46,y:20,axis:'y',cost:750},{id:'utility-return',name:'UTILITY RETURN SHUTTER',x:35,y:6,axis:'x',cost:0,controlled:true}],
  machines:[{id:'civil-feed',kind:'machine',x:53.5,y:6.5,label:'RESTORE LOCAL FEED · UTILITY SHORTCUT',cost:250,gate:'utility-return',requiresPower:true},{id:'police-coil',kind:'electric',x:50.5,y:31.5,label:'POLICE SECURITY COIL · DANGEROUS TO ALL',cost:500,duration:10,cooldown:35,zone:{x0:46.7,x1:47.3,y0:27,y1:30},access:'police-entry'}],
  props:[{id:'police-glass',kind:'glass',x:56,y:34,ex:1.0,ey:.045,h:1.12,hp:35},{id:'evidence-crate',kind:'crate',x:57.5,y:25.5,ex:.45,ey:.45,h:.62,hp:80},{id:'civil-fuel',kind:'fuel',x:57.5,y:14,ex:.30,ey:.30,h:.90,hp:70}],
  purchases:[{type:'combatsg',x:59.5,y:25.5,cost:1600,dx:1,dy:0},{type:'ammo',x:59.5,y:10.5,cost:350,dx:1,dy:0}],
  furniture:[{type:'counter',x:52.5,y:35.5,ex:1.15,ey:.32},{type:'desk',x:57,y:7.5,ex:1.05,ey:.35},{type:'shelf',x:59.3,y:30,ex:.25,ey:1.3}]
 },
 railyard:{
  rooms:[{id:'military53',name:'RESTRICTED MILITARY CARGO',x0:49,y0:24,x1:60,y1:38,front:'west',color:[.30,.36,.32]},{id:'maintenance53',name:'FREIGHT MAINTENANCE DEPOT',x0:49,y0:4,x1:60,y1:18,front:'west',color:[.37,.35,.30]}],
  corridors:[[43,29,50,31],[46,12,48,31],[48,14,50,16],[39,12,50,14]],
  gates:[{id:'military-entry',name:'MILITARY CARGO',x:44,y:29,axis:'x',cost:1250},{id:'maintenance-entry',name:'MAINTENANCE SHUTTER',x:46,y:21,axis:'y',cost:1000},{id:'dispatch-return',name:'DISPATCH RETURN SHUTTER',x:44,y:12,axis:'x',cost:0,controlled:true}],
  machines:[{id:'rail-feed',kind:'machine',x:53.5,y:6.5,label:'RESTORE SWITCH FEED · DISPATCH SHORTCUT',cost:250,gate:'dispatch-return',requiresPower:true},{id:'cargo-coil',kind:'electric',x:50.5,y:34.5,label:'CARGO SECURITY COIL · DANGEROUS TO ALL',cost:500,duration:10,cooldown:35,zone:{x0:46.7,x1:47.3,y0:29,y1:32},access:'military-entry'},{id:'freight-press',kind:'crusher',x:50.5,y:15.5,label:'FREIGHT PRESS · KEEP CLEAR OF AMBER ZONE',cost:500,duration:9,cooldown:40,zone:{x0:46,x1:49,y0:20.3,y1:21.7},access:'maintenance-entry'}],
  props:[{id:'cargo-fuel',kind:'fuel',x:55,y:28,ex:.30,ey:.30,h:.90,hp:70},{id:'supply-crate',kind:'crate',x:57.5,y:35,ex:.45,ey:.45,h:.62,hp:80},{id:'inspection-glass',kind:'glass',x:56,y:13,ex:1.0,ey:.045,h:1.12,hp:35}],
  purchases:[{type:'battlerifle',x:59.5,y:31.5,cost:2000,dx:1,dy:0},{type:'ammo',x:59.5,y:10.5,cost:350,dx:1,dy:0}],
  furniture:[{type:'shelf',x:59.3,y:26,ex:.25,ey:1.2},{type:'counter',x:56,y:7.5,ex:1.5,ey:.36},{type:'parcel',x:54,y:35,ex:.55,ey:.55}]
 }
};
let livingMap53=null,livingState53={schema:1,machines:{},props:{}},livingCollisionRevision53=0;
const livingNavDirty53=new Set(),livingWallCells53=new Set();let livingDebris53=[],livingExplosionQueue53=[],livingDoors53=[];
function livingPlan53(map=activeMapId){return livingPlans53[map]}
function livingGateCells53(g){return Array.from({length:3},(_,i)=>[g.x+(g.axis==='y'?i:0),g.y+(g.axis==='x'?i:0)])}
function livingCabinetPose53(d){const room=livingPlan53().rooms.find(r=>d.x>r.x0&&d.x<r.x1&&d.y>r.y0&&d.y<r.y1),bounds=typeof DEAD_STATIC_PBR53==='undefined'?{ex:.16,ey:.03,h:.43}:DEAD_STATIC_PBR53.bounds,north=d.kind==='machine';return north?{x:d.x,z:room.y0+1+bounds.ey-.02,rotation:0,ex:bounds.ex,ey:bounds.ey,h:bounds.h}:{x:room.x0+1+bounds.ey-.02,z:d.y,rotation:Math.PI/2,ex:bounds.ey,ey:bounds.ex,h:bounds.h};}
function installLivingMap53(){
 if(template[0].length===LIVING_WIDTH53){livingMap53=activeMapId;markLivingWallCells53(template);return;}
 const plan=livingPlan53(),m=template.map(row=>row.padEnd(LIVING_WIDTH53,'1').split(''));
 for(const r of plan.rooms){districtRooms.push({...r,living53:true});for(let y=r.y0;y<=r.y1;y++)for(let x=r.x0;x<=r.x1;x++){const wall=x===r.x0||x===r.x1||y===r.y0||y===r.y1;m[y][x]=wall?'1':'0';if(wall)districtWallCells.add(x+','+y);}}
 for(const [x0,y0,x1,y1]of plan.corridors)for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){m[y][x]='0';districtWallCells.delete(x+','+y);}
 for(const g of plan.gates){const cells=livingGateCells53(g);for(const [x,y]of cells)m[y][x]='2';gates.push({x:g.x+(g.axis==='y'?1.5:.5),y:g.y+(g.axis==='x'?1.5:.5),axis:g.axis,cells,cost:g.cost,type:'gate',label:'OPEN '+g.name,living53:g.id,controlled53:!!g.controlled});}
 for(const d of plan.machines){const p=livingCabinetPose53(d);stations.push({...d,x:p.x,y:p.z,type:'living',living53:d.id,mounted:true});mapObstacles.push({x:p.x,y:p.z,ex:p.ex,ey:p.ey,h:p.h,type:'control-cabinet',livingFixture53:d.id});}
 for(const d of plan.props)mapObstacles.push({...d,type:d.kind,living53:d.id,colliderHeight:d.h});
 if(activeMapId==='blackridge')for(const y of[29,31])mapObstacles.push({x:58.9,y,ex:1.04,ey:.05,h:1.40,type:'cell-front',living53Furniture:true});
 for(const p of plan.furniture){cityProps.push({...p,living53:true});mapObstacles.push({...p,living53Furniture:true});}
 for(const p of plan.purchases){const s={...p,label:p.type==='ammo'?'RESERVE AMMUNITION CACHE':guns[p.type].name,mounted:p.type!=='ammo',wallDX:p.dx,wallDY:p.dy,rotation:Math.atan2(p.dx,p.dy),living53Purchase:true};stations.push(s);if(p.type!=='ammo')wallFixtures.push({x:p.x,y:p.y,mx:Math.floor(p.x+p.dx),my:Math.floor(p.y+p.dy),dx:p.dx,dy:p.dy,kind:'weapon',object:s,height:.48,bottom:.65,width:.82});}
 template=m.map(row=>row.join(''));markLivingWallCells53(template);livingMap53=activeMapId;mapCatalog[activeMapId].doors=gates.length;mapRevision++;
}
function markLivingWallCells53(grid){livingWallCells53.clear();for(const [x0,y0,x1,y1]of livingPlan53().corridors)for(let y=y0-1;y<=y1+1;y++)for(let x=x0-1;x<=x1+1;x++)if(grid[y]?.[x]==='1'&&(x===x0-1||x===x1+1||y===y0-1||y===y1+1)){livingWallCells53.add(x+','+y);districtWallCells.add(x+','+y);}}
function resetLivingWorld53(){
 const p=livingPlan53(),changed=p.props.filter(d=>livingState53.props[d.id]?.destroyed);livingState53={schema:1,machines:Object.fromEntries(p.machines.map(d=>[d.id,{on:false,active:0,cooldown:0,elapsed:0,cycle:-1}])),props:Object.fromEntries(p.props.map(d=>[d.id,{hp:d.hp,destroyed:false}]))};livingDebris53=[];livingExplosionQueue53=[];livingDoors53=[];livingNavDirty53.clear();if(changed.length){livingCollisionRevision53++;for(const d of changed)for(let y=Math.floor(d.y-d.ey);y<=Math.floor(d.y+d.ey);y++)for(let x=Math.floor(d.x-d.ex);x<=Math.floor(d.x+d.ex);x++)livingNavDirty53.add(y*LIVING_WIDTH53+x);}
}
function livingSnapshot53(){return {...JSON.parse(JSON.stringify(livingState53)),explosions:livingExplosionQueue53.map(p=>({...p}))}}
function validLivingSnapshot53(s,map){
 if(s==null)return true;const p=livingPlans53[map],finite=(n,a,b)=>typeof n==='number'&&Number.isFinite(n)&&n>=a&&n<=b;
 if(s.schema!==1||!s.machines||!s.props||Array.isArray(s.machines)||Array.isArray(s.props)||Object.keys(s.machines).length!==p.machines.length||Object.keys(s.props).length!==p.props.length)return false;
 for(const d of p.machines){const v=s.machines[d.id];if(!v||typeof v.on!=='boolean'||!finite(v.active,0,d.duration||0)||!finite(v.cooldown,0,(d.cooldown||0)+(d.duration||0))||!finite(v.elapsed,0,d.duration||0)||!Number.isInteger(v.cycle)||v.cycle< -1||v.cycle>20)return false;}
 for(const d of p.props){const v=s.props[d.id];if(!v||!finite(v.hp,0,d.hp)||typeof v.destroyed!=='boolean'||v.destroyed!==(v.hp===0))return false;}if(s.explosions!=null&&(!Array.isArray(s.explosions)||s.explosions.length>4||s.explosions.some(p=>!finite(p.x,0,LIVING_WIDTH53)||!finite(p.y,0,44)||!finite(p.z,0,6))))return false;return true;
}
function restoreLivingWorld53(s){if(s)livingState53=JSON.parse(JSON.stringify(s));livingDebris53=[];livingDoors53=[];livingExplosionQueue53=(s?.explosions||[]).map(p=>({...p}));delete livingState53.explosions;livingNavDirty53.clear();livingCollisionRevision53++;}
function livingDoorOpened53(g){livingDoors53.push({cells:g.cells.map(p=>p.slice()),axis:g.axis||(originalAxis(g.cells[0][0],'x')===9||originalAxis(g.cells[0][0],'x')===22?'x':'y'),age:0,life:.48});if(livingDoors53.length>8)livingDoors53.shift();livingSound53('shutter',g);}
function livingPropGone53(p){return !!p.living53&&!!livingState53.props[p.living53]?.destroyed}
function migrateLivingGrid53(old){
 if(old[0].length===LIVING_WIDTH53)return old.map(row=>row.slice());
 const result=template.map(row=>row.split('').map(Number));for(let y=0;y<old.length;y++)for(let x=0;x<old[y].length;x++)result[y][x]=old[y][x];
 for(const [x0,y0,x1,y1]of livingPlan53().corridors)for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)result[y][x]=0;
 for(const g of livingPlan53().gates)for(const [x,y]of livingGateCells53(g))result[y][x]=2;return result;
}
function livingInteract53(n){
 if(n.controlled53){tell('Restore the local feed inside the new facility to open this shutter');return true;}
 if(n.type!=='living')return false;const d=livingPlan53().machines.find(d=>d.id===n.living53),s=livingState53.machines[d.id];
 if(!power){tell('Restore base power first');return true;}
 if(s.on&&d.kind==='machine'){tell('Local feed is online; the return route is open');return true;}
 if(s.active>0||s.cooldown>0){tell(s.active>0?'Hazard active — keep clear':'Hazard cooling: '+Math.ceil(s.cooldown)+'s');return true;}
 if(d.access&&gates.find(g=>g.living53===d.access).cells.some(([x,y])=>world[y][x]!==0)){tell('Open the access shutter before operating this hazard');return true;}
 if(points<d.cost){tell('Need '+(d.cost-points)+' more points');return true;}points-=d.cost;
 if(d.kind==='machine'){s.on=true;const gate=gates.find(g=>g.living53===d.gate);for(const [x,y]of gate.cells)world[y][x]=0;livingDoorOpened53(gate);pathClock=0;banner('LOCAL FEED ONLINE');tell('Return shortcut opened · '+gate.label.replace('OPEN ',''));}
 else{s.active=d.duration;s.cooldown=d.cooldown+d.duration;s.elapsed=0;s.cycle=-1;tell('ONE SECOND WARNING · '+d.kind.toUpperCase()+' · HAZARD DAMAGES PLAYERS AND ENEMIES');}
 livingSound53(d.kind,n);return true;
}
function livingHazardPhase53(d,s){if(s.active<=0||s.elapsed<1)return 'idle';return d.kind==='crusher'?((s.elapsed-1)%2>=.7&&(s.elapsed-1)%2<=1.05?'impact':'warning'):'active';}
function livingInside53(o,zone){return (o.level||0)===0&&actorElevation(o)<.3&&o.x>zone.x0&&o.x<zone.x1&&o.y>zone.y0&&o.y<zone.y1;}
function livingPlayerDamage53(damage){if(damage<=0||player.hp<=0)return;player.hp-=damage;player.lastHit=time;hurt=Math.max(hurt,.7);if(player.hp<=0)die();}
function livingEnemyDamage53(z,damage,source){if(z.dead)return;const before=points;damageZombie(z,damage,'BODY',source);points=before+(z.dead?50:0);combatNotice=z.dead?'ENVIRONMENT ELIMINATION · +50':'ENVIRONMENT HIT';}
function updateLivingWorld53(dt){
 livingDoors53=livingDoors53.filter(d=>{d.age+=dt;return d.age<d.life;});
 for(const d of livingPlan53().machines){const s=livingState53.machines[d.id];s.cooldown=Math.max(0,s.cooldown-dt);if(s.active<=0)continue;const step=Math.min(dt,s.active);s.active=Math.max(0,s.active-dt);s.elapsed=Math.min(d.duration,s.elapsed+step);
  if(d.kind==='electric'&&s.elapsed>1){const charged=Math.min(step,s.elapsed-1);for(const z of zombies)if(!z.dead&&!z.wait&&livingInside53(z,d.zone))livingEnemyDamage53(z,charged*480,'electric-trap');if(livingInside53(player,d.zone))livingPlayerDamage53(charged*80);}
  if(d.kind==='crusher'){const first=Math.max(0,s.cycle+1),last=Math.floor((s.elapsed-2)/2);for(let cycle=first;cycle<=last;cycle++){s.cycle=cycle;for(const z of zombies)if(!z.dead&&!z.wait&&livingInside53(z,d.zone))livingEnemyDamage53(z,700,'freight-press');if(livingInside53(player,d.zone))livingPlayerDamage53(85);livingSound53('crusher',{x:(d.zone.x0+d.zone.x1)/2,y:(d.zone.y0+d.zone.y1)/2});}}
 }
 if(livingExplosionQueue53.length)livingExplosion53(livingExplosionQueue53.shift());
 livingDebris53=livingDebris53.filter(p=>{p.life-=dt;p.age+=dt;return p.life>0;});
}
function updateLivingBarrier53(z,w,dt){
 if(z.barrierPhase53==null){if(w.timer>0)return;z.barrierPhase53=0;z.barrierContact53=false;const f=wallFixtures.find(f=>f.kind==='window'&&f.object===w);z.attackHeading=f?Math.atan2(f.my+.5-z.y,f.mx+.5-z.x):Math.atan2(w.y-z.y,w.x-z.x);}
 const duration=z.crippled?1.25:.90,previous=z.barrierPhase53;z.barrierPhase53+=dt;z.attackElapsed=z.barrierPhase53;z.attackDuration=duration;
 if(!z.barrierContact53&&previous<duration*.52&&z.barrierPhase53>=duration*.52){z.barrierContact53=true;w.boards=Math.max(0,w.boards-1);w.timer=waveProfile(round).boardInterval;livingSound53('board',w);}
 if(z.barrierPhase53>=duration){z.barrierPhase53=null;z.attackElapsed=null;}
}
function damageLivingProp53(d,amount,source='bullet'){
 const s=livingState53.props[d.id];if(!s||s.destroyed||!Number.isFinite(amount)||amount<=0)return false;s.hp=Math.max(0,s.hp-amount);if(s.hp>0)return true;s.destroyed=true;
 livingCollisionRevision53++;pathClock=0;for(let y=Math.floor(d.y-d.ey);y<=Math.floor(d.y+d.ey);y++)for(let x=Math.floor(d.x-d.ex);x<=Math.floor(d.x+d.ex);x++)livingNavDirty53.add(y*world[0].length+x);
 for(let i=0;i<8;i++)livingDebris53.push({x:d.x,y:d.y,z:d.h*.7,age:0,life:1.5,index:i,kind:d.kind});if(livingDebris53.length>48)livingDebris53.splice(0,livingDebris53.length-48);
 livingSound53(d.kind,d);if(d.kind==='fuel'&&livingExplosionQueue53.length<4)livingExplosionQueue53.push({x:d.x,y:d.y,z:.55});return true;
}
function livingExplosion53(p){
 blasts.push({...p,type:'frag',age:0,seed:0,life:1.5});if(blasts.length>8)blasts.shift();playEquipmentReport({...p,type:'frag'});
 for(const z of zombies){const distance=Math.hypot(z.x-p.x,z.y-p.y,actorElevation(z)+.4-p.z);if(!z.dead&&distance<3.2&&rayClear3D(p.x,p.y,p.z,z.x,z.y,actorElevation(z)+.4))livingEnemyDamage53(z,430*Math.max(.15,1-distance/3.2),'fuel-drum');}
 const distance=Math.hypot(player.x-p.x,player.y-p.y,actorElevation(player)+.4-p.z);if(distance<2.8&&rayClear3D(p.x,p.y,p.z,player.x,player.y,actorElevation(player)+.4))livingPlayerDamage53(75*(1-distance/2.8));
 damageLivingArea53(p,3.2,110,'fuel');
}
function livingBoxEntry53(p,d){
 const delta=[d.x-p.x,d.y-p.y,d.h/2-p.z],distance=Math.hypot(...delta);if(distance<1e-8)return {distance:0,point:{...p}};const dir=delta.map(n=>n/distance),origin=[p.x,p.y,p.z];let lo=0,hi=distance;
 for(const [axis,min,max]of [[0,d.x-d.ex,d.x+d.ex],[1,d.y-d.ey,d.y+d.ey],[2,0,d.h]]){if(Math.abs(dir[axis])<1e-8){if(origin[axis]<min||origin[axis]>max)return null;}else{let a=(min-origin[axis])/dir[axis],b=(max-origin[axis])/dir[axis];if(a>b)[a,b]=[b,a];lo=Math.max(lo,a);hi=Math.min(hi,b);}}if(hi<lo)return null;const stop=Math.max(0,lo-.04);return {distance,point:{x:p.x+dir[0]*stop,y:p.y+dir[1]*stop,z:p.z+dir[2]*stop}};
}
function damageLivingArea53(p,radius,damage,source){for(const d of livingPlan53().props){if(livingState53.props[d.id].destroyed)continue;const hit=livingBoxEntry53(p,d);if(hit&&hit.distance<radius&&rayClear3D(p.x,p.y,p.z,hit.point.x,hit.point.y,hit.point.z))damageLivingProp53(d,damage*Math.max(.25,1-hit.distance/radius),source);}}
function traceLivingShot53(range){
 if((player.level||0)!==0)return null;const pitch=Math.tan(player.pitch||0),scale=1/Math.sqrt(1+pitch*pitch),origin=[player.x,player.y,eyeHeight()],dir=[Math.cos(player.a)*scale,Math.sin(player.a)*scale,pitch*scale];let nearest=null;
 for(const d of livingPlan53().props){if(livingState53.props[d.id].destroyed)continue;let lo=0,hi=range;for(const [axis,min,max]of [[0,d.x-d.ex,d.x+d.ex],[1,d.y-d.ey,d.y+d.ey],[2,0,d.h]]){if(Math.abs(dir[axis])<1e-8){if(origin[axis]<min||origin[axis]>max){hi=-1;break;}}else{let a=(min-origin[axis])/dir[axis],b=(max-origin[axis])/dir[axis];if(a>b)[a,b]=[b,a];lo=Math.max(lo,a);hi=Math.min(hi,b);}}if(hi<lo||lo>range)continue;const stop=Math.max(0,lo-.08);if(!rayClear3D(...origin,origin[0]+dir[0]*stop,origin[1]+dir[1]*stop,origin[2]+dir[2]*stop))continue;if(!nearest||lo<nearest.distance)nearest={object:d,distance:lo,point:{x:origin[0]+dir[0]*lo,y:origin[1]+dir[1]*lo,z:origin[2]+dir[2]*lo}};}return nearest;
}
const livingSoundBuffers53={};
function livingSound53(kind,p){
 if(!ac||!$('sound').checked)return;let b=livingSoundBuffers53[kind];if(!b){const duration=kind==='glass'?.35:kind==='crusher'?.48:.24;b=ac.createBuffer(1,Math.ceil(ac.sampleRate*duration),ac.sampleRate);const data=b.getChannelData(0);let low=0;for(let i=0;i<data.length;i++){const t=i/ac.sampleRate,n=Math.random()-.5;low=low*.85+n*.15;data[i]=(kind==='electric'?Math.sin(t*2*Math.PI*120)*.2:kind==='glass'?n*.45:low*.6)*Math.exp(-t*(kind==='glass'?12:8));}livingSoundBuffers53[kind]=b;}playSpatial(b,p,.16,1);
}
const livingSpriteCache53=new Map();
function livingFallbackSprite53(d){const state=livingState53.machines[d.id],key=d.kind+':'+(state?.on?'on':state?.active>0?'active':'idle');if(livingSpriteCache53.has(key))return livingSpriteCache53.get(key);const c=document.createElement('canvas');c.width=128;c.height=128;const t=c.getContext('2d');t.fillStyle=d.kind==='fuel'?'#68704b':d.kind==='crate'?'#765332':'#253b40';t.fillRect(12,8,104,112);t.strokeStyle='#a8b7b0';t.lineWidth=4;t.strokeRect(12,8,104,112);t.fillStyle=d.kind==='glass'?'#54828e':state?.on?'#59bb83':state?.active>0?'#ed954f':'#819a91';t.fillRect(23,22,82,44);t.fillStyle='#e5dcc7';t.font='bold 12px Arial';t.textAlign='center';t.fillText(d.kind.toUpperCase(),64,92);livingSpriteCache53.set(key,c);return c;}
function livingFallbackSprites53(){const p=livingPlan53();return [...p.props.filter(d=>!livingState53.props[d.id].destroyed).map(d=>({...d,kind:'prop',h:d.h,wide:d.ex*2/d.h,sprite:livingFallbackSprite53(d)})),...p.machines.map(d=>{const pose=livingCabinetPose53(d);return {...d,x:pose.x,y:pose.z,kind:'prop',h:pose.h,wide:pose.ex*2/pose.h,sprite:livingFallbackSprite53(d)}})];}
function drawLivingFallbackHazards53(){for(const d of livingPlan53().machines){if(!d.zone)continue;const s=livingState53.machines[d.id],q=project((d.zone.x0+d.zone.x1)/2,(d.zone.y0+d.zone.y1)/2);if(q.depth<.15||q.x<0||q.x>=W||q.depth>zbuffer[Math.floor(q.x)])continue;const corners=[[d.zone.x0,d.zone.y0],[d.zone.x1,d.zone.y0],[d.zone.x1,d.zone.y1],[d.zone.x0,d.zone.y1]].map(([x,y])=>project(x,y));if(corners.some(p=>p.depth<.1))continue;ctx.strokeStyle=s.active>0?'#ff9c63':'#b39248';ctx.lineWidth=2;ctx.beginPath();corners.forEach((p,i)=>ctx[i?'lineTo':'moveTo'](p.x,horizonY()+p.size*eyeHeight()));ctx.closePath();ctx.stroke();if(s.active>0){ctx.fillStyle='#ffe4b9';ctx.font='bold 12px Arial';ctx.textAlign='center';ctx.fillText(d.kind==='electric'?'LIVE ELECTRIC COIL':'ACTIVE FREIGHT PRESS',q.x,horizonY()+q.size*(eyeHeight()-.35));}}}
