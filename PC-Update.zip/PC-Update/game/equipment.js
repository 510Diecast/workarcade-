'use strict';
const perkDefinitions={
 health:{name:'IRON HEART',short:'HEART',effect:'200 maximum health',cost:2500,color:'#bd4034',rgb:[.60,.19,.15],icon:'heart',w:.72,d:.52,h:1.32},
 speed:{name:'QUICK HANDS',short:'HANDS',effect:'45% faster reloads',cost:2000,color:'#468eb9',rgb:[.19,.36,.55],icon:'clock',w:.64,d:.52,h:1.37},
 double:{name:'RAPID FIRE',short:'FIRE',effect:'25% shorter shot cooldown',cost:2000,color:'#d3a047',rgb:[.64,.41,.16],icon:'bullets',w:.76,d:.54,h:1.29},
 fleet:{name:'FLEET FEET',short:'FEET',effect:'20% faster sprint · 8s stamina',cost:2200,color:'#6dc29b',rgb:[.26,.51,.38],icon:'boot',w:.66,d:.52,h:1.34},
 medic:{name:'FIELD MEDIC',short:'MEDIC',effect:'Heal after 2.5s · 17 HP/s',cost:3000,color:'#dfdad0',rgb:[.67,.69,.62],icon:'cross',w:.70,d:.52,h:1.31},
 pockets:{name:'DEEP POCKETS',short:'AMMO',effect:'50% more reserve ammunition',cost:1500,color:'#b7b56b',rgb:[.43,.47,.25],icon:'ammo',w:.78,d:.54,h:1.28},
 brawler:{name:'KNUCKLE TONIC',short:'FISTS',effect:'60% stronger melee',cost:2000,color:'#b86dba',rgb:[.46,.24,.46],icon:'fist',w:.70,d:.54,h:1.30}
};
const ownedPerks=new Set(),equipmentArt=new Map();
function reserveCapacity(type,w=inventory.find(w=>w.type===type)){return Math.floor(guns[type].max*(w?.upgraded?1.5:1)*(ownedPerks.has('pockets')?1.5:1))}
function staminaCapacity(){return ownedPerks.has('fleet')?8:6}
function stationDimensions(s){
 const p=perkDefinitions[s.type];if(p)return {w:p.w,d:p.d,h:p.h};
 return s.type==='upgrade'?{w:1.18,d:.88,h:1.16}:s.type==='power'?{w:.76,d:.50,h:1.43}:s.type==='ammo'?{w:1,d:.64,h:.55}:{w:.43,d:.33,h:1};
}
function stationFootprint(s){const q=stationDimensions(s),rot=s.rotation||0,c=Math.abs(Math.cos(rot)),n=Math.abs(Math.sin(rot));return {ex:(q.w*c+q.d*n)/2,ey:(q.w*n+q.d*c)/2}}
function installEquipment(){
 for(const s of stations.filter(s=>perkDefinitions[s.type]||['upgrade','power','ammo'].includes(s.type))){
  const offset=s.type==='upgrade'?.30:s.type==='ammo'?.24:.18;s.x-=(s.wallDX||0)*offset;s.y-=(s.wallDY||0)*offset;
  if(perkDefinitions[s.type])s.label=perkDefinitions[s.type].name+' · '+perkDefinitions[s.type].effect;
 }
 stations.find(s=>s.type==='ammo').y=25;
 for(const [type,x,y,dx,dy] of [['fleet',14.38,24.7,-1,0],['medic',31.62,26.1,1,0],['pockets',27.40,34.5,-1,0],['brawler',33.4,36.2,-1,0]]){
  const p=perkDefinitions[type];stations.push({type,x,y,wallDX:dx,wallDY:dy,rotation:Math.atan2(dx,dy),mounted:false,label:p.name+' · '+p.effect,cost:p.cost});
 }
}
function equipPerk(type){
 ownedPerks.add(type);if(type==='health'){player.maxhp=200;player.hp=200}if(type==='speed')fastReload=true;if(type==='double')doubleTap=true;
 if(type==='fleet')stamina=Math.min(staminaCapacity(),stamina+2);
 if(type==='pockets')inventory.forEach(w=>w.reserve=Math.min(reserveCapacity(w.type),w.reserve+Math.floor(guns[w.type].max*.5)));
 tell(perkDefinitions[type].name+' EQUIPPED · '+perkDefinitions[type].effect);pathClock=0;
}
function renderPerkHud(){
 const key=[...ownedPerks].join(',')+'|'+power;if(renderPerkHud.key===key)return;renderPerkHud.key=key;
 const e=$('perks');e.innerHTML=[...ownedPerks].map(type=>{const p=perkDefinitions[type];return `<span class="perk-chip" style="--perk-color:${p.color}" title="${p.name}: ${p.effect}">${p.short}</span>`}).join('')||(power?'POWER ONLINE':mapCatalog[activeMapId].name.toUpperCase());
}
function equipmentIcon(type){
 const key='icon:'+type;if(equipmentArt.has(key))return equipmentArt.get(key);
 const c=document.createElement('canvas');c.width=c.height=256;const t=c.getContext('2d'),p=perkDefinitions[type];
 t.fillStyle='#15221f';t.beginPath();t.arc(128,128,118,0,Math.PI*2);t.fill();t.strokeStyle=p?.color||'#c7a55e';t.lineWidth=12;t.beginPath();t.arc(128,128,112,0,Math.PI*2);t.stroke();t.fillStyle=type==='medic'?'#ba4135':'#eee2b8';t.strokeStyle=t.fillStyle;t.lineWidth=13;t.lineCap='round';
 const icon=p?.icon||type;
 if(icon==='heart'){t.beginPath();t.moveTo(128,190);t.bezierCurveTo(35,133,44,65,85,68);t.bezierCurveTo(112,61,128,90,128,90);t.bezierCurveTo(145,59,199,63,204,104);t.bezierCurveTo(209,142,162,178,128,190);t.fill()}
 else if(icon==='clock'){t.beginPath();t.arc(128,126, 60,0,Math.PI*2);t.stroke();t.beginPath();t.moveTo(128,88);t.lineTo(128,128);t.lineTo(157,143);t.stroke()}
 else if(icon==='cross'){t.fillRect(106,62,44,132);t.fillRect(62,106,132,44)}
 else if(icon==='bullets'||icon==='ammo'){for(let i=0;i<3;i++){let x=64+i*49;t.fillRect(x,102,29,82);t.beginPath();t.moveTo(x,102);t.lineTo(x+14,66);t.lineTo(x+29,102);t.fill();t.fillRect(x-3,179,35,9)}}
 else if(icon==='boot'){t.beginPath();t.moveTo(78,61);t.lineTo(131,61);t.lineTo(142,139);t.lineTo(188,158);t.lineTo(188,189);t.lineTo(66,189);t.lineTo(69,147);t.lineTo(83,145);t.closePath();t.fill();for(let y of[92,113,134]){t.fillStyle='#15221f';t.fillRect(83,y,40,7)}}
 else if(icon==='fist'){t.fillRect(77,113,108,75);for(let i=0;i<4;i++){t.beginPath();t.arc(78+i*27,106,19,Math.PI,0);t.lineTo(97+i*27,147);t.lineTo(59+i*27,147);t.fill()}t.fillRect(62,143,30,38)}
 else if(icon==='power'){t.beginPath();t.moveTo(143, 40);t.lineTo(73,139);t.lineTo(116,139);t.lineTo(101,218);t.lineTo(188,105);t.lineTo(140,105);t.closePath();t.fill()}
 else if(icon==='upgrade'){t.beginPath();t.moveTo(60,100);t.lineTo(196,100);t.lineTo(166,129);t.lineTo(143,137);t.lineTo(143,168);t.lineTo(179,183);t.lineTo(179,195);t.lineTo(77,195);t.lineTo(77,183);t.lineTo(112,168);t.lineTo(112,137);t.lineTo(78,128);t.closePath();t.fill();t.fillRect(155,65,19,35)}
 else{t.fillRect(66,92,124,91);for(let i=0;i<3;i++)t.fillRect(79+i*34,66,20,35)}
 equipmentArt.set(key,c);return c;
}
function equipmentLabel(s){
 const key='label:'+s.type;if(equipmentArt.has(key))return equipmentArt.get(key);
 const c=document.createElement('canvas');c.width=640;c.height=160;const t=c.getContext('2d'),p=perkDefinitions[s.type];
 t.fillStyle='#142420';t.fillRect(0,0,640,160);t.strokeStyle=p?.color||'#c8aa71';t.lineWidth=6;t.strokeRect(5,5,630,150);t.textAlign='center';t.fillStyle='#ede3c8';t.font='bold 38px Arial';
 t.fillText(p?.name||(s.type==='upgrade'?'FORGE-A-PUNCH':s.type==='power'?'DISTRICT POWER':'AMMO CACHE'),320,70);
 t.font='23px Arial';t.fillStyle='#babca8';t.fillText(s.type==='power'?'WARDEN SIGNAL CORPS':s.cost+' POINTS',320,121);equipmentArt.set(key,c);return c;
}
function equipmentAppearance(s){
 const p=perkDefinitions[s.type],q=stationDimensions(s),c=document.createElement('canvas');c.width=480;c.height=Math.round(480*q.h/q.w);const t=c.getContext('2d'),h=c.height;
 t.fillStyle=p?.color|| (s.type==='upgrade'?'#745239':s.type==='power'?'#707b71':'#705f3d');t.fillRect(18,12,444,h-20);t.fillStyle='#172823';t.fillRect(38,32,404,h- 60);
 const iconSize=Math.min(210,h*.30);t.drawImage(equipmentIcon(s.type),(480-iconSize)/2,h*.07,iconSize,iconSize);t.drawImage(equipmentLabel(s),38,h*.39,404,101);
 if(p){t.fillStyle='#0b1918';t.fillRect(80,h*.57,320,h*.27);for(let i=0;i<4;i++){t.fillStyle=p.color;t.fillRect(100+i*75,h*.61,36,h*.12);t.fillStyle='#c7c6ad';t.fillRect(109+i*75,h*.59,18,h*.025)}t.fillStyle='#b9b498';t.fillRect(185,h*.88,111,17)}
 else if(s.type==='upgrade'){t.fillStyle='#e69d45';for(let x of[61,384])for(let y=250;y<h-30;y+=23)t.fillRect(x,y,25,10);t.fillStyle='#090f0f';t.fillRect(64,h*.65,352,h*.16);t.fillStyle='#7c8579';for(let i=0;i<8;i++)t.fillRect(80+i*40,h*.82,25,15)}
 else if(s.type==='power'){for(let i=0;i<6;i++){t.fillStyle=i%2?'#ae4839':'#789682';t.fillRect(90+(i%2)*165,h*.61+Math.floor(i/2)*55,120,35)}}
 else{t.fillStyle='#b29e66';t.fillRect(59,h*.66,363,h*.07)}return c;
}
