. (Join-Path $PSScriptRoot 'Common.ps1')
try {
 $metadata=Read-Brand $PSScriptRoot;$target=Join-Path $env:LOCALAPPDATA $metadata.installationFolder
 if([IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') -ne [IO.Path]::GetFullPath($target).TrimEnd('\')){throw 'Run the installed uninstaller from its registered location.'}
 Confirm-GameIdentity $target;Confirm-GameClosed (Join-Path $env:LOCALAPPDATA $metadata.profileFolder)
 if([System.Windows.Forms.MessageBox]::Show('Remove the application? Saved runs, scores and settings will remain in the existing game profile.','Zombies: Dead Signal','YesNo','Question') -ne 'Yes'){exit}
 $desktop=[Environment]::GetFolderPath('Desktop');$programs=[Environment]::GetFolderPath('Programs');$menu=Join-Path $programs $metadata.shortcutName
 foreach($path in @((Join-Path $desktop ($metadata.shortcutName+'.lnk')),(Join-Path $menu ($metadata.shortcutName+'.lnk')),(Join-Path $desktop 'Dead Frequency.lnk'),(Join-Path $programs 'Dead Frequency\Dead Frequency.lnk'))){if(Is-GameShortcut $path $target){Remove-Item -LiteralPath $path}}
 if((Test-Path -LiteralPath $menu) -and -not(Get-ChildItem -LiteralPath $menu -Force)){Remove-Item -LiteralPath $menu}
 $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\'+$metadata.uninstallRegistryName
 if((Test-Path -LiteralPath $key) -and (Get-ItemProperty -LiteralPath $key).InstallLocation -eq $target){Remove-Item -LiteralPath $key -Recurse}
 Remove-Item -LiteralPath $target -Recurse -Force
} catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Zombies: Dead Signal - Uninstall','OK','Error') | Out-Null;exit 1}
