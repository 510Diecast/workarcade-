$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
function Read-Brand([string]$Root){Get-Content -LiteralPath (Join-Path $Root 'branding.json') -Raw | ConvertFrom-Json}
function Read-InstalledVersion([string]$Root){
 if(-not(Test-Path -LiteralPath $Root)){return $null}
 if(Test-Path -LiteralPath (Join-Path $Root 'branding.json')){return (Read-Brand $Root).version}
 $game=Join-Path $Root 'game\game.js'
 if(Test-Path -LiteralPath $game){$text=Get-Content -LiteralPath $game -Raw;if($text -match "GAME_VERSION='([^']+)'"){return $Matches[1]}}
 return $null
}
function Confirm-GameIdentity([string]$Root){
 if(-not(Test-Path -LiteralPath $Root)){return}
 $index=Join-Path $Root 'game\index.html';$launch=Join-Path $Root 'Launch.ps1'
 if(-not(Test-Path -LiteralPath $index) -or -not(Test-Path -LiteralPath $launch)){throw 'This folder is not a recognized Dead Signal installation. Nothing was changed.'}
 $html=Get-Content -LiteralPath $index -Raw
 if($html -notmatch '<title>[^<]*(Dead Frequency|Dead Regiment|Zombies: Dead Signal)'){throw 'The existing folder belongs to an unrecognized game. Nothing was changed.'}
 $brand=Join-Path $Root 'branding.json'
 if(Test-Path -LiteralPath $brand){$old=Read-Brand $Root;if($old.appId -ne 'DeadFrequency.ZombiesDeadSignal' -or $old.profileFolder -ne 'DeadFrequencyProfile'){throw 'Application identity does not match this update.'}}
 elseif((Get-Content -LiteralPath $launch -Raw) -notmatch 'DeadFrequencyProfile'){throw 'The legacy launcher profile does not match this game.'}
}
function Is-GameShortcut([string]$Path,[string]$Root){
 if(-not(Test-Path -LiteralPath $Path)){return $false}
 $s=(New-Object -ComObject WScript.Shell).CreateShortcut($Path)
 $exe=Join-Path $Root 'ZombiesDeadSignal.exe';$vbs=Join-Path $Root 'Launch.vbs'
 return $s.TargetPath -eq $exe -or ($s.TargetPath -match '\\wscript\.exe$' -and $s.Arguments.Trim('"') -eq $vbs)
}
function Confirm-GameClosed([string]$Profile){
 $running=@()
 try {$running=@(Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" | Where-Object {$_.CommandLine -and $_.CommandLine.IndexOf($Profile,[StringComparison]::OrdinalIgnoreCase) -ge 0})}catch{}
 if($running.Count){throw 'Close the game completely before updating or uninstalling. Your active run must be saved first.'}
}
function Update-GameShortcuts([string]$Root,$Metadata){
 if(-not ('DeadSignalWindow' -as [type])){Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $Root 'WindowBranding.cs') -Raw)}
 $shell=New-Object -ComObject WScript.Shell
 $desktop=[Environment]::GetFolderPath('Desktop');$programs=[Environment]::GetFolderPath('Programs');$menu=Join-Path $programs $Metadata.shortcutName
 New-Item -ItemType Directory -Path $menu -Force | Out-Null
 foreach($path in @((Join-Path $desktop ($Metadata.shortcutName+'.lnk')),(Join-Path $menu ($Metadata.shortcutName+'.lnk')))){
  if((Test-Path -LiteralPath $path) -and -not(Is-GameShortcut $path $Root)){throw 'A shortcut with the new name belongs to another application. It was not overwritten.'}
  $shortcut=$shell.CreateShortcut($path);$shortcut.TargetPath=Join-Path $Root $Metadata.executable;$shortcut.WorkingDirectory=$Root;$shortcut.IconLocation=(Join-Path $Root $Metadata.icon)+',0';$shortcut.Description=$Metadata.productName+' '+$Metadata.version;$shortcut.Save();[DeadSignalWindow]::ApplyShortcut($path,$Metadata.appId)
 }
 foreach($path in @((Join-Path $desktop 'Dead Frequency.lnk'),(Join-Path $programs 'Dead Frequency\Dead Frequency.lnk'),(Join-Path $desktop 'Dead Regiment.lnk'))){if(Is-GameShortcut $path $Root){Remove-Item -LiteralPath $path}}
 $legacy=Join-Path $programs 'Dead Frequency';if((Test-Path -LiteralPath $legacy) -and -not(Get-ChildItem -LiteralPath $legacy -Force)){Remove-Item -LiteralPath $legacy}
}
function Register-Game([string]$Root,$Metadata){
 $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\'+$Metadata.uninstallRegistryName
 if(Test-Path -LiteralPath $key){$old=Get-ItemProperty -LiteralPath $key;if($old.InstallLocation -and $old.InstallLocation -ne $Root){throw 'The uninstall identity belongs to a different installation.'}}
 New-Item -Path $key -Force | Out-Null
 $ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $values=@{DisplayName=$Metadata.productName;DisplayVersion=$Metadata.version;DisplayIcon=((Join-Path $Root $Metadata.icon)+',0');InstallLocation=$Root;UninstallString=('"'+$ps+'" -NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $Root 'Uninstall.ps1')+'"')}
 foreach($entry in $values.GetEnumerator()){New-ItemProperty -Path $key -Name $entry.Key -Value $entry.Value -PropertyType String -Force | Out-Null}
 foreach($name in @('NoModify','NoRepair')){New-ItemProperty -Path $key -Name $name -Value 1 -PropertyType DWord -Force | Out-Null}
 # No fabricated publisher or signature. Preserve a real publisher if previously set.
}
function Restore-GameBackup([string]$Root,[string]$Backup,$Metadata){
 $prefix=[IO.Path]::GetFullPath((Join-Path $Root 'UpdateBackups')).TrimEnd('\')+'\'
 if(-not([IO.Path]::GetFullPath($Backup).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase))){throw 'Recovery path is outside this installation.'}
 $record=Get-Content -LiteralPath (Join-Path $Backup 'RecoveryManifest.json') -Raw | ConvertFrom-Json
 foreach($name in $record.createdFiles){if([IO.Path]::GetFileName($name) -ne $name){throw 'Recovery filename is invalid.'};if(-not(Test-Path -LiteralPath (Join-Path $Backup $name))){Remove-Item -LiteralPath (Join-Path $Root $name) -Force -ErrorAction SilentlyContinue}}
 foreach($name in $record.originalFiles){if([IO.Path]::GetFileName($name) -ne $name){throw 'Recovery filename is invalid.'};Copy-Item -LiteralPath (Join-Path $Backup $name) -Destination $Root -Force}
 foreach($name in @('index.html','district.js','equipment.js','graphics.js','renderer3d.js','controllers.js','game.js')){if(-not(Test-Path -LiteralPath (Join-Path $Backup ('game\'+$name)))){Remove-Item -LiteralPath (Join-Path $Root ('game\'+$name)) -Force -ErrorAction SilentlyContinue}}
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $Backup 'game')){Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $Root 'game') -Recurse -Force}
 foreach($entry in $record.shortcuts){if($entry.present){New-Item -ItemType Directory -Path (Split-Path $entry.path -Parent) -Force | Out-Null;Copy-Item -LiteralPath (Join-Path $Backup $entry.backup) -Destination $entry.path -Force}else{if(Is-GameShortcut $entry.path $Root){Remove-Item -LiteralPath $entry.path}}}
 $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\'+$Metadata.uninstallRegistryName
 if($record.registryPresent){$old=Get-Content -LiteralPath (Join-Path $Backup 'RegistryBackup.json') -Raw | ConvertFrom-Json;New-Item -Path $key -Force | Out-Null;foreach($property in $old.PSObject.Properties){if($null -ne $property.Value){$type=if($property.Name -in @('NoModify','NoRepair')){'DWord'}else{'String'};New-ItemProperty -Path $key -Name $property.Name -Value $property.Value -PropertyType $type -Force | Out-Null}}}
 elseif((Test-Path -LiteralPath $key) -and (Get-ItemProperty -LiteralPath $key).InstallLocation -eq $Root){Remove-Item -LiteralPath $key -Recurse}
}
