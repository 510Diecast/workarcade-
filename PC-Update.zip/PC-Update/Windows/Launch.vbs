Option Explicit
Dim shell, fso, root, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
If fso.FileExists(root & "\ZombiesDeadSignal.exe") Then
 command = Chr(34) & root & "\ZombiesDeadSignal.exe" & Chr(34)
Else
 command = Chr(34) & shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe" & Chr(34) & " -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & root & "\Launch.ps1" & Chr(34)
End If
shell.Run command, 0, False
