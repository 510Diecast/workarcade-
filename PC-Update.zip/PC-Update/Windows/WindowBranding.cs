using System;
using System.Runtime.InteropServices;
public static class DeadSignalWindow {
 [StructLayout(LayoutKind.Sequential)] struct PropertyKey {public Guid format;public uint id;public PropertyKey(uint i){format=new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");id=i;}}
 [StructLayout(LayoutKind.Explicit,Size=24)] struct PropVariant {
  [FieldOffset(0)] public ushort type;[FieldOffset(8)] public IntPtr value;
 }
 [ComImport,Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IPropertyStore {
  [PreserveSig]int GetCount(out uint count);[PreserveSig]int GetAt(uint index,out PropertyKey key);
  [PreserveSig]int GetValue(ref PropertyKey key,out PropVariant value);[PreserveSig]int SetValue(ref PropertyKey key,ref PropVariant value);[PreserveSig]int Commit();
 }
 [DllImport("shell32.dll")] static extern int SHGetPropertyStoreForWindow(IntPtr window,ref Guid iid,[MarshalAs(UnmanagedType.Interface)]out IPropertyStore store);
 [DllImport("shell32.dll",CharSet=CharSet.Unicode)] static extern int SHGetPropertyStoreFromParsingName(string path,IntPtr context,uint flags,ref Guid iid,[MarshalAs(UnmanagedType.Interface)]out IPropertyStore store);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern IntPtr LoadImage(IntPtr instance,string file,uint type,int x,int y,uint flags);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern IntPtr SendMessage(IntPtr window,uint message,IntPtr parameter,IntPtr value);
 static IntPtr small,big;
 static void Set(IPropertyStore store,uint id,string text){PropertyKey key=new PropertyKey(id);PropVariant value=new PropVariant();value.type=31;value.value=Marshal.StringToCoTaskMemUni(text);try{Marshal.ThrowExceptionForHR(store.SetValue(ref key,ref value));}finally{Marshal.FreeCoTaskMem(value.value);}}
 public static void ApplyShortcut(string path,string appId){Guid iid=new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");IPropertyStore store;Marshal.ThrowExceptionForHR(SHGetPropertyStoreFromParsingName(path,IntPtr.Zero,2,ref iid,out store));try{Set(store,5,appId);Marshal.ThrowExceptionForHR(store.Commit());}finally{Marshal.ReleaseComObject(store);}}
 public static void Apply(IntPtr window,string title,string icon,string appId,string executable){
  if(small==IntPtr.Zero)small=LoadImage(IntPtr.Zero,icon,1,32,32,0x10);
  if(big==IntPtr.Zero)big=LoadImage(IntPtr.Zero,icon,1,256,256,0x10);
  if(small!=IntPtr.Zero)SendMessage(window,0x80,IntPtr.Zero,small);
  if(big!=IntPtr.Zero)SendMessage(window,0x80,new IntPtr(1),big);
  Guid iid=new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");IPropertyStore store;
  if(SHGetPropertyStoreForWindow(window,ref iid,out store)<0)return;
  try{Set(store,5,appId);Set(store,2,"\""+executable+"\"");Set(store,3,icon+",0");Set(store,4,title);Marshal.ThrowExceptionForHR(store.Commit());}finally{Marshal.ReleaseComObject(store);}
 }
}
