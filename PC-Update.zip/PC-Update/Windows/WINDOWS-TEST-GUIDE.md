# Zombies: Dead Signal — Windows installation and recovery

This release retains the existing Windows PowerShell 5.1 + Microsoft Edge/Google Chrome app-mode runtime. It adds a small icon-bearing launcher compiled on your PC by the existing .NET Framework compiler. It is unsigned. This package has been inspected on Linux; installation, compilation, Shell integration and upgrade must still be checked on Windows 10/11. A work PC may restrict scripts or compilation; follow your workplace's software policy.

## Install or upgrade

1. Extract the entire ZIP. Keep `PC-Update/game` beside `PC-Update/Windows`.
2. Save and quit an existing game, then close its window.
3. For an existing installation, run `PC-Update/Apply-Update.cmd`. For a fresh installation, run `PC-Install/Install.cmd`.
4. The installer verifies all payload SHA-256 hashes and compiles the branded launcher in a temporary folder before changing the installation. Compilation failure leaves the old app unchanged.
5. Installation stays at `%LOCALAPPDATA%\DeadFrequency`. Saves, settings, best scores and run progress stay in the browser's existing `%LOCALAPPDATA%\DeadFrequencyProfile` directory with the same `game/index.html` file origin and storage keys. The new launcher uses this same profile.
6. During an upgrade the old application, shortcuts, uninstall registration and a closed-profile snapshot are backed up under `DeadFrequency\UpdateBackups`. The current profile is never replaced by the installer or application rollback.

The official product name is **Zombies: Dead Signal**. The shortcut file is **Zombies - Dead Signal**, since Windows filenames cannot contain a colon. No administrator elevation is requested. SHA-256 detects missing/corrupt payload files; it is not an authenticity signature. Obtain release ZIPs from the game's trusted release source.

## Windows verification checklist

Use a separate Windows test account for a fresh-install check. Confirm these on your own account for an upgrade:

| Check | Expected result |
|---|---|
| Fresh install | One installation under the existing stable directory; game launches through Edge/Chrome |
| Desktop / Start menu | Official name, new multi-size icon, target `ZombiesDeadSignal.exe` |
| File Properties | Product name `Zombies: Dead Signal`, four-component release FileVersion |
| Taskbar / Alt+Tab | New icon; window and shortcut share the stable AppUserModelID |
| Installed Apps | Official name, current version, current icon, functioning uninstaller |
| v5.1 upgrade | No second installation; previous application backup and profile snapshot exist |
| Saved run | Resume on Blackridge and Railyard; purchased doors, guns, Forge upgrades, points and quests remain |
| Settings | Existing controller mapping, audio, sensitivity, FOV and best scores remain |
| Corrupt payload | Change a copied game file before running updater; verification rejects it before touching the installed game |
| Rollback | Run `PC-Update/Restore-Previous.cmd`; previous app restores, current profile remains unchanged |
| Uninstall | Use Installed Apps; app and owned shortcuts removed, current profile retained |

Existing pinned shortcuts may keep cached icons. Unpin the old shortcut and pin the new one. Do not delete your browser profile to refresh an icon. `Branding-Diagnostic.txt` records optional window-branding errors while allowing the game to launch.

## Recover a profile snapshot only if necessary

Application rollback intentionally leaves current saved progress alone. If your profile itself needs recovery, close all windows using this dedicated profile, copy the current `DeadFrequencyProfile` somewhere safe, and copy the selected backup's `ProfileSnapshot` back to `DeadFrequencyProfile`. This is a separate manual recovery operation because it replaces progress with the earlier snapshot. Never perform it while the game is running.

## Future updates

The version-aware package builder generates launcher metadata, hashes and a versioned icon from the game's version and the stable branding configuration. The manual updater safely targets the existing installation. Updating a GitHub Pages/WorkArcade browser game does **not** update an installed Windows app. Network auto-update is not configured: it requires an authorized HTTPS release feed, signed trusted release metadata and an appropriate executable-signing/distribution setup. No executable downloader was added.
