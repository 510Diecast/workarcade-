. (Join-Path $PSScriptRoot 'Common.ps1')
try {
 $metadata=Read-Brand $PSScriptRoot;$target=Join-Path $env:LOCALAPPDATA $metadata.installationFolder
 Confirm-GameIdentity $target;Confirm-GameClosed (Join-Path $env:LOCALAPPDATA $metadata.profileFolder)
 $receipt=Get-Content -LiteralPath (Join-Path $target 'InstallReceipt.json') -Raw | ConvertFrom-Json
 if(-not $receipt.backup){throw 'There is no previous installation backup.'}
 if([System.Windows.Forms.MessageBox]::Show('Restore the previous game and launcher? Current saved progress will remain in its existing profile.','Zombies: Dead Signal','YesNo','Question') -ne 'Yes'){exit}
 Restore-GameBackup $target $receipt.backup $metadata
 [System.Windows.Forms.MessageBox]::Show('Previous application restored. Game saves/settings were not moved or deleted.','Zombies: Dead Signal') | Out-Null
} catch {[System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Zombies: Dead Signal - Recovery','OK','Error') | Out-Null;exit 1}
