$ErrorActionPreference='Stop'
try {
 $metadata=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'branding.json') -Raw | ConvertFrom-Json
 $gameFile=Join-Path $PSScriptRoot 'game\index.html'
 if(-not(Test-Path -LiteralPath $gameFile)){throw 'Extract or install the complete game first.'}
 $programFiles32=${env:ProgramFiles(x86)};if(-not $programFiles32){$programFiles32=$env:ProgramFiles}
 $candidates=@((Join-Path $programFiles32 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),(Join-Path $programFiles32 'Google\Chrome\Application\chrome.exe'),(Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'))
 foreach($key in @('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')){if(Test-Path -LiteralPath $key){$candidates+=(Get-Item -LiteralPath $key).GetValue('')}}
 $browser=$candidates | Where-Object {$_ -and (Test-Path -LiteralPath $_)} | Select-Object -First 1
 if(-not $browser){throw 'Microsoft Edge or Google Chrome is required.'}
 # Keep the exact v5.1 user-data directory and local file origin.
 $profile=Join-Path $env:LOCALAPPDATA $metadata.profileFolder
 $uri=([Uri]::new([IO.Path]::GetFullPath($gameFile))).AbsoluteUri
 $arguments='"--app='+$uri+'" "--user-data-dir='+$profile+'" --no-first-run --no-default-browser-check --disable-background-mode --window-size=1280,800'
 Start-Process -FilePath $browser -ArgumentList $arguments | Out-Null
 try {
  Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'WindowBranding.cs') -Raw)
  $seen=$false;$idle=0;$known=@{}
  while($idle -lt 30){
   # Scope branding to browser processes in this game's dedicated profile only.
   $owned=@(Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" | Where-Object {$_.CommandLine -and $_.CommandLine.IndexOf($profile,[StringComparison]::OrdinalIgnoreCase) -ge 0} | ForEach-Object {$_.ProcessId})
   if(-not $owned.Count){$idle++;Start-Sleep -Seconds 1;continue}
   $windows=@(Get-Process -Id $owned -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowHandle -ne 0 -and $_.MainWindowTitle.IndexOf($metadata.productName,[StringComparison]::OrdinalIgnoreCase) -ge 0})
   if($windows.Count){$seen=$true;$idle=0;foreach($window in $windows){$h=$window.MainWindowHandle.ToInt64();if(-not $known.ContainsKey($h)){[DeadSignalWindow]::Apply($window.MainWindowHandle,$metadata.productName,(Join-Path $PSScriptRoot $metadata.icon),$metadata.appId,(Join-Path $PSScriptRoot $metadata.executable));$known[$h]=$true}}}
   else {$idle++;if($seen -and $idle -ge 3){break}}
   Start-Sleep -Seconds 1
  }
 } catch {($_.Exception.Message) | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Branding-Diagnostic.txt')}
} catch {
 Add-Type -AssemblyName System.Windows.Forms
 [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Zombies: Dead Signal - Launch','OK','Error') | Out-Null
 exit 1
}
