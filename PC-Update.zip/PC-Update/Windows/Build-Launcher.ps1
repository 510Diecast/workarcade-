param([Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference='Stop'
$metadata=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'branding.json') -Raw | ConvertFrom-Json
$source=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Launcher.cs') -Raw
$fileVersion=$metadata.fileVersion
$source=$source.Replace('__FILE_VERSION__',$fileVersion)
$source=$source.Replace('__PRODUCT_NAME__',$metadata.productName.Replace('\','\\').Replace('"','\"')).Replace('__APP_ID__',$metadata.appId)
$icon=Join-Path $PSScriptRoot $metadata.icon
$output=Join-Path $Destination $metadata.executable
if(-not(Test-Path -LiteralPath $icon)){throw 'The complete icon payload is required.'}
# Explicitly invoked by powershell.exe (Windows PowerShell 5.1), not pwsh.
$compiler=New-Object Microsoft.CSharp.CSharpCodeProvider
$options=New-Object System.CodeDom.Compiler.CompilerParameters
$options.GenerateExecutable=$true;$options.GenerateInMemory=$false;$options.OutputAssembly=$output
$options.CompilerOptions='/target:winexe /win32icon:"'+$icon+'"'
$options.ReferencedAssemblies.Add('System.dll') | Out-Null
$options.ReferencedAssemblies.Add('System.Windows.Forms.dll') | Out-Null
$result=$compiler.CompileAssemblyFromSource($options,$source)
$compiler.Dispose()
if($result.Errors.HasErrors){throw ('Launcher compilation failed: '+(($result.Errors | ForEach-Object {$_.ErrorText}) -join '; '))}
if(-not(Test-Path -LiteralPath $output)){throw 'Launcher compilation produced no executable.'}
$info=(Get-Item -LiteralPath $output).VersionInfo
if($info.FileVersion -ne $fileVersion -or $info.ProductName -ne $metadata.productName){throw 'Compiled launcher metadata did not match the release.'}
