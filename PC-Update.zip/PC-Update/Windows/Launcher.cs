using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
[assembly: AssemblyTitle("__PRODUCT_NAME__")]
[assembly: AssemblyProduct("__PRODUCT_NAME__")]
[assembly: AssemblyDescription("Offline browser-powered game launcher")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyVersion("__FILE_VERSION__")]
[assembly: AssemblyFileVersion("__FILE_VERSION__")]
internal static class DeadSignalLauncher {
 [DllImport("shell32.dll", CharSet=CharSet.Unicode)] static extern int SetCurrentProcessExplicitAppUserModelID(string id);
 [STAThread] static void Main() {
  try {
   string root=Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
   string launch=Path.Combine(root,"Launch.ps1");
   if(!File.Exists(launch)||!File.Exists(Path.Combine(root,"game","index.html")))throw new IOException("Extract or install the complete game first.");
   SetCurrentProcessExplicitAppUserModelID("__APP_ID__");
   var info=new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"WindowsPowerShell","v1.0","powershell.exe"));
   info.Arguments="-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \""+launch+"\"";
   info.WorkingDirectory=root;info.UseShellExecute=false;info.CreateNoWindow=true;
   Process.Start(info);
  } catch(Exception error) {MessageBox.Show(error.Message,"__PRODUCT_NAME__",MessageBoxButtons.OK,MessageBoxIcon.Error);}
 }
}
