param([switch]$UpdateOnly)
. (Join-Path $PSScriptRoot 'Common.ps1')
$stage=$null;$backup=$null;$changed=$false;$fresh=$false
try {
 $metadata=Read-Brand $PSScriptRoot
 if($metadata.appId -ne 'DeadFrequency.ZombiesDeadSignal' -or $metadata.installationFolder -ne 'DeadFrequency' -or $metadata.profileFolder -ne 'DeadFrequencyProfile'){throw 'Release identity is invalid.'}
 $target=Join-Path $env:LOCALAPPDATA $metadata.installationFolder;$fresh=-not(Test-Path -LiteralPath $target)
 if($UpdateOnly -and $fresh){throw 'The installed game was not found. Use PC-Install/Install.cmd for a fresh installation.'}
 Confirm-GameIdentity $target
 $installedVersion=Read-InstalledVersion $target
 if($installedVersion -and [version]$installedVersion -gt [version]$metadata.version){throw 'A newer release is already installed. Use the explicit rollback tool to restore a backed-up application.'}
 $desktop=[Environment]::GetFolderPath('Desktop');$programs=[Environment]::GetFolderPath('Programs');$menu=Join-Path $programs $metadata.shortcutName
 $newLinks=@((Join-Path $desktop ($metadata.shortcutName+'.lnk')),(Join-Path $menu ($metadata.shortcutName+'.lnk')))
 foreach($path in $newLinks){if((Test-Path -LiteralPath $path) -and -not(Is-GameShortcut $path $target)){throw 'The proposed shortcut belongs to a different application. Nothing was changed.'}}
 $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\'+$metadata.uninstallRegistryName
 if((Test-Path -LiteralPath $key) -and (Get-ItemProperty -LiteralPath $key).InstallLocation -ne $target){throw 'The registry identity belongs to another installation. Nothing was changed.'}
 Confirm-GameClosed (Join-Path $env:LOCALAPPDATA $metadata.profileFolder)
 $answer=[System.Windows.Forms.MessageBox]::Show(('Install '+$metadata.productName+' '+$metadata.version+'? Close the game first. Existing saves/settings stay in their current profile. A recoverable application backup will be kept.'),$metadata.productName,'OKCancel','Information')
 if($answer -ne 'OK'){exit 0}
 $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'hashes.json') -Raw | ConvertFrom-Json
 foreach($entry in $manifest.PSObject.Properties){$path=Join-Path $PSScriptRoot $entry.Name;if(-not(Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() -ne $entry.Value){throw ('Release verification failed: '+$entry.Name)}}
 $stage=Join-Path $env:TEMP ('DeadSignalStage-'+[Guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $stage | Out-Null
 foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -File){Copy-Item -LiteralPath $file.FullName -Destination $stage}
 New-Item -ItemType Directory -Path (Join-Path $stage 'game') | Out-Null
 $sourceGame=Join-Path (Split-Path $PSScriptRoot -Parent) 'game'
 foreach($file in Get-ChildItem -LiteralPath $sourceGame -File){Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $stage 'game')}
 & (Join-Path $stage 'Build-Launcher.ps1') -Destination $stage
 if(-not $fresh){
  $backup=Join-Path $target ('UpdateBackups\'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $backup -Force | Out-Null
  foreach($file in Get-ChildItem -LiteralPath $target -File){Copy-Item -LiteralPath $file.FullName -Destination $backup}
  Copy-Item -LiteralPath (Join-Path $target 'game') -Destination $backup -Recurse
  $profile=Join-Path $env:LOCALAPPDATA $metadata.profileFolder
  if(Test-Path -LiteralPath $profile){Copy-Item -LiteralPath $profile -Destination (Join-Path $backup 'ProfileSnapshot') -Recurse}
  $key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\'+$metadata.uninstallRegistryName
  if(Test-Path -LiteralPath $key){Get-ItemProperty -LiteralPath $key | Select-Object DisplayName,DisplayVersion,DisplayIcon,InstallLocation,UninstallString,Publisher,NoModify,NoRepair | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backup 'RegistryBackup.json')}
  $links=@();$index=0
  foreach($path in @($newLinks)+@((Join-Path $desktop 'Dead Frequency.lnk'),(Join-Path $programs 'Dead Frequency\Dead Frequency.lnk'),(Join-Path $desktop 'Dead Regiment.lnk'))){
   $present=Test-Path -LiteralPath $path
   if($present -and -not(Is-GameShortcut $path $target)){continue}
   $saved='Shortcut-'+$index+'.lnk';if($present){Copy-Item -LiteralPath $path -Destination (Join-Path $backup $saved)}
   $links+=@{path=$path;present=[bool]$present;backup=$saved};$index++
  }
  @{originalFiles=@(Get-ChildItem -LiteralPath $target -File | ForEach-Object {$_.Name});shortcuts=$links;registryPresent=[bool](Test-Path -LiteralPath $key);createdFiles=@((Get-ChildItem -LiteralPath $stage -File | ForEach-Object {$_.Name}))+@('DeadFrequency.ico','InstallReceipt.json')} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backup 'RecoveryManifest.json')
 }
 New-Item -ItemType Directory -Path $target -Force | Out-Null;$changed=$true
 foreach($file in Get-ChildItem -LiteralPath $stage -File){Copy-Item -LiteralPath $file.FullName -Destination $target -Force}
 New-Item -ItemType Directory -Path (Join-Path $target 'game') -Force | Out-Null
 foreach($file in Get-ChildItem -LiteralPath (Join-Path $stage 'game') -File){Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $target 'game') -Force}
 # Keep a compatibility icon for already-pinned legacy shortcuts.
 Copy-Item -LiteralPath (Join-Path $target $metadata.icon) -Destination (Join-Path $target 'DeadFrequency.ico') -Force
 Update-GameShortcuts $target $metadata;Register-Game $target $metadata
 @{version=$metadata.version;installedAt=[DateTime]::UtcNow.ToString('o');backup=$backup;profile=(Join-Path $env:LOCALAPPDATA $metadata.profileFolder);signed=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $target 'InstallReceipt.json')
 [System.Windows.Forms.MessageBox]::Show(('Installed '+$metadata.productName+' '+$metadata.version+'. Use the new desktop/Start menu shortcut. Old pinned icons may need to be unpinned and pinned again. Your game profile was not moved.'),$metadata.productName,'OK','Information') | Out-Null
} catch {
 $installationError=$_.Exception.Message
 if($changed){
  if($backup -and (Test-Path -LiteralPath $backup)){try{Restore-GameBackup $target $backup $metadata}catch{[System.Windows.Forms.MessageBox]::Show(('Automatic recovery could not finish. Backup retained at '+$backup),'Zombies: Dead Signal','OK','Warning') | Out-Null}}
  elseif($fresh){foreach($path in $newLinks){if(Is-GameShortcut $path $target){Remove-Item -LiteralPath $path -ErrorAction SilentlyContinue}};if((Test-Path -LiteralPath $key) -and (Get-ItemProperty -LiteralPath $key).InstallLocation -eq $target){Remove-Item -LiteralPath $key -Recurse -ErrorAction SilentlyContinue};Remove-Item -LiteralPath $target -Force -Recurse -ErrorAction SilentlyContinue}
 }
 [System.Windows.Forms.MessageBox]::Show($installationError,'Zombies: Dead Signal - Installation','OK','Error') | Out-Null;exit 1
} finally {if($stage -and (Test-Path -LiteralPath $stage)){Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}}
