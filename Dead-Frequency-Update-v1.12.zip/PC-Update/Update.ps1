﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
try {
 $target = Join-Path $env:LOCALAPPDATA 'DeadFrequency'
 if (-not (Test-Path -LiteralPath (Join-Path $target 'Launch.vbs'))) { throw 'Installed Dead Frequency was not found. This patch is for the installed PC app. For portable play, copy the game folder over your existing game folder.' }
 $answer = [System.Windows.Forms.MessageBox]::Show('Close Dead Frequency before continuing. Apply game update v1.12 now?', 'Dead Frequency Update', 'OKCancel', 'Information')
 if ($answer -ne 'OK') { exit 0 }
 $names = @('index.html','graphics.js','renderer3d.js','controllers.js','game.js')
 $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'hashes.json') -Raw | ConvertFrom-Json
 foreach ($name in $names) {
  $path = Join-Path (Join-Path $PSScriptRoot 'game') $name
  if (-not (Test-Path -LiteralPath $path)) { throw 'Extract the entire update ZIP first.' }
  if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() -ne $manifest.$name) { throw "Update file failed verification: $name" }
 }
 $game = Join-Path $target 'game'
 $backup = Join-Path $target ('UpdateBackup-' + [Guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory -Path $backup | Out-Null
 foreach ($name in $names) { if (Test-Path -LiteralPath (Join-Path $game $name)) { Copy-Item -LiteralPath (Join-Path $game $name) -Destination $backup } }
 try {
  foreach ($name in $names) { Copy-Item -LiteralPath (Join-Path (Join-Path $PSScriptRoot 'game') $name) -Destination (Join-Path $game $name) -Force }
 } catch {
  foreach ($name in $names) { if (Test-Path -LiteralPath (Join-Path $backup $name)) { Copy-Item -LiteralPath (Join-Path $backup $name) -Destination (Join-Path $game $name) -Force } else { Remove-Item -LiteralPath (Join-Path $game $name) -Force -ErrorAction SilentlyContinue } }
  throw
 }
 Remove-Item -LiteralPath $backup -Recurse -Force
 [System.Windows.Forms.MessageBox]::Show('Updated! Open your existing Dead Frequency desktop shortcut. Scores and controller settings were kept.', 'Dead Frequency', 'OK', 'Information') | Out-Null
} catch {
 [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Dead Frequency Update', 'OK', 'Error') | Out-Null
 exit 1
}
