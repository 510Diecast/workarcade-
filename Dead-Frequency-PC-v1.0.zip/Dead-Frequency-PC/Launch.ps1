﻿$ErrorActionPreference = 'Stop'
try {
    $gameFile = Join-Path $PSScriptRoot 'game\index.html'
    if (-not (Test-Path -LiteralPath $gameFile)) { throw 'Game files are missing. Extract the entire ZIP first.' }
    $programFiles32 = ${env:ProgramFiles(x86)}
    if (-not $programFiles32) { $programFiles32 = $env:ProgramFiles }
    $candidates = @(
        (Join-Path $programFiles32 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $programFiles32 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach ($key in @('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')) {
        if (Test-Path -LiteralPath $key) { $candidates += (Get-Item -LiteralPath $key).GetValue('') }
    }
    $browser = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
    if (-not $browser) { throw 'Install Microsoft Edge or Google Chrome, then launch again.' }
    $profile = Join-Path $env:LOCALAPPDATA 'DeadFrequencyProfile'
    $gameUri = ([System.Uri]::new([System.IO.Path]::GetFullPath($gameFile))).AbsoluteUri
    $browserArgs = '"--app=' + $gameUri + '" "--user-data-dir=' + $profile + '" --no-first-run --no-default-browser-check --disable-background-mode --window-size=1280,800'
    Start-Process -FilePath $browser -ArgumentList $browserArgs
} catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Dead Frequency - Launch', 'OK', 'Error') | Out-Null
    exit 1
}
