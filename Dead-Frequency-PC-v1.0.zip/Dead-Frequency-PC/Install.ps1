﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
try {
    $destination = Join-Path $env:LOCALAPPDATA 'DeadFrequency'
    if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'game\index.html'))) { throw 'Extract the whole ZIP before installing.' }
    if ([System.IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') -ne [System.IO.Path]::GetFullPath($destination).TrimEnd('\')) {
        New-Item -ItemType Directory -Path $destination -Force | Out-Null
        foreach ($item in Get-ChildItem -LiteralPath $PSScriptRoot) { Copy-Item -LiteralPath $item.FullName -Destination $destination -Recurse -Force }
    }
    $shell = New-Object -ComObject WScript.Shell
    $startMenu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Dead Frequency'
    New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
    foreach ($shortcutPath in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Dead Frequency.lnk'),(Join-Path $startMenu 'Dead Frequency.lnk'))) {
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
        $shortcut.Arguments = '"' + (Join-Path $destination 'Launch.vbs') + '"'
        $shortcut.WorkingDirectory = $destination
        $shortcut.IconLocation = (Join-Path $destination 'DeadFrequency.ico') + ',0'
        $shortcut.Description = 'Dead Frequency - offline factory zombie survival'
        $shortcut.Save()
    }
    $answer = [System.Windows.Forms.MessageBox]::Show('Installed! Use Dead Frequency on your desktop or Start menu. Launch now?', 'Dead Frequency', 'YesNo', 'Information')
    if ($answer -eq 'Yes') { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $destination 'Launch.vbs') + '"') }
} catch {
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Dead Frequency - Installer', 'OK', 'Error') | Out-Null
    exit 1
}
