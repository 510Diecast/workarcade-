﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$answer = [System.Windows.Forms.MessageBox]::Show('Remove the Dead Frequency installation and shortcuts? Your saved scores and controller settings will be kept.', 'Dead Frequency', 'YesNo', 'Question')
if ($answer -ne 'Yes') { exit }
try {
    $desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Dead Frequency.lnk'
    if (Test-Path -LiteralPath $desktopShortcut) { Remove-Item -LiteralPath $desktopShortcut }
    $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Dead Frequency'
    if (Test-Path -LiteralPath $menu) { Remove-Item -LiteralPath $menu -Recurse }
    $app = Join-Path $env:LOCALAPPDATA 'DeadFrequency'
    if (Test-Path -LiteralPath $app) { Remove-Item -LiteralPath $app -Recurse }
    [System.Windows.Forms.MessageBox]::Show('Dead Frequency removed. Scores remain in your app profile.', 'Dead Frequency') | Out-Null
} catch {
    [System.Windows.Forms.MessageBox]::Show('Close Dead Frequency, then try uninstalling again. ' + $_.Exception.Message, 'Dead Frequency') | Out-Null
    exit 1
}
