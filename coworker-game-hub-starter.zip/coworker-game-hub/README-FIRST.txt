AFTERHOURS GAME HUB - QUICK START
=================================

1) Unzip this package.
2) Open index.html in Chrome/Edge to preview the home page.
3) Add your existing games:
   ZOMBIES:
   - Replace games/zombies/index.html with your REAL Zombies HTML file.
   - If the game filename is something else (like zombies.html), rename it to index.html.
   - Copy all its JS, CSS, images, sounds, and other asset folders into games/zombies/, preserving their relative layout.
   DRIFT:
   - Replace games/drift/index.html with the real game and include its assets similarly.
   - If not ready, the slot can remain as a placeholder.

4) Test both Play buttons locally. Some games require an HTTP server (e.g. games using fetch(), ES modules, or special browser APIs). They may fail when opened from file:// but work from a real https:// host.

5) PUBLISH WITHOUT POWERSHELL:
   - Go to https://github.com/new and create a PUBLIC repository named 'coworker-game-hub'.
   - Click Add file > Upload files and DRAG the CONTENTS of this unzipped folder (index.html, games folder, .nojekyll), NOT the outer folder or ZIP.
   - Commit changes.
   - Repository > Settings > Pages > Build and deployment: Deploy from a branch > main > /(root) > Save.
   - Your URL should follow: https://YOUR-GITHUB-USERNAME.github.io/coworker-game-hub/
   - GitHub will display the actual live URL on Settings > Pages.

6) UPDATES:
   - In the GitHub repository, upload updated game files at the same paths and commit the changes.
   - Ask coworkers to refresh the page after the site updates.

CAUTION:
- GitHub Pages websites are PUBLIC and aren't password-protected on regular GitHub accounts. Do not upload confidential employer info, access tokens, passwords, private game assets, or files you don't have permission to distribute.
- Follow your workplace's device/network rules.
- External assets linked to file:/// or C:/ paths, local servers, or localhost WILL NOT work for coworkers. Use paths relative to each game's index.html.
- This is static HTML hosting: multiplayer scores and synchronized progress require a separate backend.
- The existing game is NOT included in this starter ZIP. You must add it.
