'use strict';
// Dependency-free WebGL scene. Gameplay coordinates stay shared with hit detection.
function createSolidRenderer(){
const surface=document.createElement('canvas'),gl=surface.getContext('webgl',{alpha:false,antialias:true,powerPreference:'high-performance'});if(!gl)return null;
surface.id='scene3d';surface.style.cssText='position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:0';document.body.insertBefore(surface,cv);cv.style.cssText='position:fixed;inset:0;z-index:1;pointer-events:auto';$('hud').style.zIndex=2;$('overlay').style.zIndex=3;
let lost=false;surface.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true});surface.addEventListener('webglcontextrestored',()=>location.reload());
const vs=`precision highp float;attribute vec3 aPosition;attribute vec3 aNormal;attribute vec3 aColor;attribute float aKind;uniform mat4 uModel;uniform mat3 uNormal;uniform vec3 uEye;uniform vec2 uYaw;uniform vec3 uProjection;uniform vec3 uTint;uniform float uKind;varying vec2 vUV;varying vec3 vWorld;varying vec3 vNormal;varying vec3 vColor;varying float vKind;varying float vDepth;void main(){vec3 p=(uModel*vec4(aPosition,1.0)).xyz;vec3 d=p-uEye;float depth=dot(d.xz,uYaw);float side=dot(d.xz,vec2(-uYaw.y,uYaw.x));gl_Position=vec4(side*uProjection.x,(d.y-uProjection.z*depth)*uProjection.y,depth*1.002-0.1001,depth);vUV=aPosition.xy+vec2(.5);vWorld=p;vNormal=normalize(uNormal*aNormal);vColor=aColor*uTint;vKind=uKind<0.0?aKind:uKind;vDepth=depth;}`;
const fs=`precision highp float;varying vec2 vUV;varying vec3 vWorld;varying vec3 vNormal;varying vec3 vColor;varying float vKind;varying float vDepth;uniform sampler2D uTexture;uniform vec3 uEye;uniform vec2 uYaw;uniform float uPower;uniform float uTime;uniform float uFlash;float noise(vec3 p){return fract(sin(dot(floor(p),vec3(12.9898,78.233,39.425)))*43758.5453);}void main(){vec3 n=normalize(vNormal),c=vColor;if(vKind>5.5&&vKind<6.5){float h=clamp((vWorld.y-uEye.y)/35.0,0.0,1.0);gl_FragColor=vec4(mix(vec3(.29,.28,.25),vec3(.08,.12,.18),h),1.0);return;}if(vKind>4.5&&vKind<5.5){vec4 tex=texture2D(uTexture,vUV);if(tex.a<.2)discard;c=tex.rgb;}float grain=noise(vWorld*95.0);if(vKind<1.5){vec2 uv=abs(n.y)>.5?vWorld.xz:abs(n.x)>.5?vWorld.zy:vWorld.xy;if(vKind<.5){vec2 tile=fract(uv*1.6);float seam=step(.025,tile.x)*step(.025,tile.y);c*=mix(.5,1.0,seam);c*=.86+grain*.20;float crack=abs(sin(uv.x*6.4+sin(uv.y*11.0)*.10));c*=mix(.43,1.0,smoothstep(.008,.027,crack));float wet=smoothstep(.73,.96,sin(vWorld.x*1.9+sin(vWorld.z*1.2))*.5+.5);c=mix(c,c*vec3(.82,1.05,1.14),wet*.22);}else{float row=floor(uv.y*7.0);vec2 brick=vec2(fract(uv.x*3.5+mod(row,2.0)*.5),fract(uv.y*7.0));float mortar=step(.045,brick.x)*step(.09,brick.y);c*=mix(.47,1.0,mortar);c*=.8+grain*.28;float stain=sin(uv.x*16.0)*sin(uv.y*3.0);c*=.86+stain*.14;float runoff=smoothstep(.82,.98,sin(uv.x*27.0))*smoothstep(.6,1.5,uv.y);c*=1.0-runoff*.22;float peeling=smoothstep(.7,.96,sin(uv.x*19.0+sin(uv.y*13.0))*sin(uv.y*17.0));c=mix(c,vec3(.37,.38,.34),peeling*.22);}}else if(vKind<2.5){c*=.8+grain*.25;float stripe=step(.94,fract(vWorld.y*20.0));c*=1.0-stripe*.13;}else if(vKind<3.5){float patches=sin(vWorld.x*37.0+sin(vWorld.y*29.0))*sin(vWorld.z*31.0);c*=.85+grain*.13+patches*.085;}if(vKind>7.5){float grainWood=sin(vWorld.y*65.0+sin(vWorld.x*14.0)*2.0+vWorld.z*7.0);c*=.8+grainWood*.13+grain*.12;}else if(vKind>6.5){vec2 weave=fract(vWorld.xy*170.0);c*=.88+.10*step(.25,weave.x)*step(.25,weave.y);c*=.94+.06*sin(vWorld.y*65.0);}vec3 sun=normalize(vec3(-.45,.8,.35));float diffuse=max(0.0,dot(n,sun));float ambient=.29+uPower*.1;vec3 lit=c*(ambient+diffuse*.65);float lamp=0.0;for(int i=0;i<4;i++){vec3 light=vec3(i==0?11.0:i==1?21.0:i==2?4.0:28.0,1.35,i<2?18.0:17.0);vec3 delta=light-vWorld;float dist=length(delta);lamp+=max(0.0,dot(n,normalize(delta)))/(1.0+dist*dist*1.5);}lit+=c*vec3(1.0,.79,.48)*lamp*uPower*(.94+.06*sin(uTime*15.0));vec3 view=normalize(uEye-vWorld);float spec=pow(max(0.0,dot(reflect(-sun,n),view)),24.0);if(vKind>1.5&&vKind<2.5)lit+=vec3(.23)*spec;if(vKind<.5){float damp=smoothstep(.62,.95,sin(vWorld.x*1.9+sin(vWorld.z*1.2))*.5+.5);lit+=vec3(.16,.20,.22)*spec*damp;}vec3 to=vWorld-uEye;float cone=smoothstep(.83,.97,dot(normalize(to.xz),uYaw));lit+=c*cone/(1.0+dot(to,to)*.35)*(.26+uFlash*1.3);if(vKind>3.5&&vKind<4.5)lit=c;float fog=1.0-exp(-max(0.0,vDepth)*.028);gl_FragColor=vec4(mix(lit,vec3(.105,.137,.15),min(.76,fog)),1.0);}`;
function shader(type,code){let sh=gl.createShader(type);gl.shaderSource(sh,code);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));return sh}
const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vs));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
let white=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,white);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
const uniform={};for(let name of ['Model','Normal','Eye','Yaw','Projection','Tint','Kind','Power','Time','Flash'])uniform[name]=gl.getUniformLocation(program,'u'+name);const attrs=['Position','Normal','Color','Kind'].map(n=>gl.getAttribLocation(program,'a'+n));
function buffer(data){let b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);return {b,count:data.length/10}}
function bind(b){gl.bindBuffer(gl.ARRAY_BUFFER,b.b);for(let i=0;i<4;i++){gl.enableVertexAttribArray(attrs[i]);gl.vertexAttribPointer(attrs[i],i===3?1:3,gl.FLOAT,false,40,[0,12,24,36][i])}}
const faces=[[[1,0,0],[[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5],[.5,-.5,.5]]],[[-1,0,0],[[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5],[-.5,-.5,-.5]]],[[0,1,0],[[-.5,.5,-.5],[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5]]],[[0,-1,0],[[-.5,-.5,.5],[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5]]],[[0,0,1],[[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5],[-.5,-.5,.5]]],[[0,0,-1],[[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5],[.5,-.5,-.5]]]];
function addCube(data,x,y,z,sx,sy,sz,color,kind){for(let [n,pts] of faces)for(let i of [0,1,2,0,2,3]){let p=pts[i];data.push(x+p[0]*sx,y+p[1]*sy,z+p[2]*sz,...n,...color,kind)}}let data=[];addCube(data,0,0,0,1,1,1,[1,1,1],2);const cube=buffer(data);data=[];const rings=10,segs=14;function spherePoint(a,b){let t=a/rings*Math.PI,p=b/segs*Math.PI*2;return [Math.sin(t)*Math.cos(p),Math.cos(t),Math.sin(t)*Math.sin(p)]}for(let a=0;a<rings;a++)for(let b=0;b<segs;b++)for(let [aa,bb] of [[a,b],[a+1,b],[a+1,b+1],[a,b],[a+1,b+1],[a,b+1]]){let p=spherePoint(aa,bb);data.push(...p,...p,1,1,1,3)}const sphere=buffer(data);
const textureUniform=gl.getUniformLocation(program,'uTexture'),textureCache=new WeakMap();function plaque(image,x,y,z,width,height,rotation){let texture=textureCache.get(image);if(!texture){texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);textureCache.set(image,texture)}gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.uniform1i(textureUniform,0);block(x,y,z,width,height,.015,[1,1,1],5,rotation)}
// Joined, faceted anatomy replaces the inflated oval limb/torso silhouette.
function loft(rows,segs=10){let out=[];function point(row,i){let a=i/segs*Math.PI*2;return [Math.cos(a)*row[1],row[0],Math.sin(a)*row[2]+(row[3]||0)]}for(let j=0;j<rows.length-1;j++)for(let i=0;i<segs;i++){let a=point(rows[j],i),b=point(rows[j+1],i),c=point(rows[j+1],i+1),d=point(rows[j],i+1);for(let tri of [[a,b,c],[a,c,d]]){let u=tri[1].map((n,k)=>n-tri[0][k]),w=tri[2].map((n,k)=>n-tri[0][k]),n=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]],l=Math.hypot(...n);if(l<1e-8)continue;n=n.map(q=>q/l);if(n[0]*tri[0][0]+n[2]*tri[0][2]<0)n=n.map(q=>-q);for(let q of tri)out.push(...q,...n,1,1,1,3)}}return buffer(out)}
const torso=loft([[-1,.76,.72],[-.70,.77,.76],[-.25,.66,.70],[.25,.87,.80],[.7,1.08,.76],[1,.50,.50]],12);
const tendon=loft([[-1,.30,.30],[-.90,.58,.58],[-.40,.85,.74],[.25,.95,.83],[.78,.72,.65],[1,.45,.45]],8);
const canineBody=loft([[-1,.28,.35],[-.72,.80,.82],[-.25,.63,.67],[.35,.87,1],[.72,1,.95],[1,.50,.50]],10);
// Anatomical skull silhouette: tapered chin, angular jaw, cheekbones and narrower brow.
function skullMesh(){let rows=[[-1,.28,.30,.16],[-.82,.62,.49,.18],[-.48,.80,.67,.10],[-.12,.94,.73,.02],[.25,.91,.79,-.06],[.64,.83,.79,-.09],[.91,.54,.53,-.08],[1,.02,.02,-.08]],v=[];function point(row,i){let a=i/20*Math.PI*2;return [Math.cos(a)*row[1],row[0],Math.sin(a)*row[2]+row[3]]}for(let j=0;j<rows.length-1;j++)for(let i=0;i<20;i++){let a=point(rows[j],i),b=point(rows[j+1],i),c=point(rows[j+1],i+1),d=point(rows[j],i+1);for(let tri of [[a,b,c],[a,c,d]]){let u=tri[1].map((n,k)=>n-tri[0][k]),w=tri[2].map((n,k)=>n-tri[0][k]),n=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]],l=Math.hypot(...n);n=n.map(q=>q/l);if(n[0]*tri[0][0]+n[2]*tri[0][2]<0)n=n.map(q=>-q);for(let q of tri)v.push(...q,...n,1,1,1,3)}}return buffer(v)}const skull=skullMesh();
let earVertices=[];for(let tri of [[[-.5,0,-.5],[.5,0,-.5],[0,1,.1]],[[.5,0,-.5],[.5,0,.5],[0,1,.1]],[[.5,0,.5],[-.5,0,.5],[0,1,.1]],[[-.5,0,.5],[-.5,0,-.5],[0,1,.1]]]){let a=tri[0],b=tri[1],c=tri[2],u=b.map((v,i)=>v-a[i]),w=c.map((v,i)=>v-a[i]),n=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]],l=Math.hypot(...n);for(let q of tri)earVertices.push(...q,...n.map(v=>v/l),1,1,1,3)}const ear=buffer(earVertices);
const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];let wallBuffer=null,worldKey='';
function mesh(b,x,y,z,sx,sy,sz,color,kind=2,rotation=0){let c=Math.cos(rotation),s=Math.sin(rotation);gl.uniformMatrix4fv(uniform.Model,false,new Float32Array([c*sx,0,-s*sx,0,0,sy,0,0,s*sz,0,c*sz,0,x,y,z,1]));gl.uniformMatrix3fv(uniform.Normal,false,new Float32Array([c/sx,0,-s/sx,0,1/sy,0,s/sz,0,c/sz]));gl.uniform3fv(uniform.Tint,color);gl.uniform1f(uniform.Kind,kind);bind(b);gl.drawArrays(gl.TRIANGLES,0,b.count)}
function block(x,y,z,sx,sy,sz,c,kind=2,r=0){mesh(cube,x,y,z,sx,sy,sz,c,kind,r)}function oval(x,y,z,sx,sy,sz,c,kind=3){mesh(sphere,x,y,z,sx,sy,sz,c,kind)}
function limb(a,b,r,color){let d=b.map((v,i)=>v-a[i]),l=Math.hypot(...d),v=d.map(n=>n/l),axis=Math.abs(v[1])>.9?[1,0,0]:[0,1,0],u=[v[1]*axis[2]-v[2]*axis[1],v[2]*axis[0]-v[0]*axis[2],v[0]*axis[1]-v[1]*axis[0]],ul=Math.hypot(...u);u=u.map(n=>n/ul);let w=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],sc=[r,l*.5,r],axes=[u,v,w];gl.uniformMatrix4fv(uniform.Model,false,new Float32Array([...u.map(n=>n*sc[0]),0,...v.map(n=>n*sc[1]),0,...w.map(n=>n*sc[2]),0,...a.map((n,i)=>(n+b[i])*.5),1]));gl.uniformMatrix3fv(uniform.Normal,false,new Float32Array(axes.flatMap((ax,i)=>ax.map(n=>n/sc[i]))));gl.uniform3fv(uniform.Tint,color);gl.uniform1f(uniform.Kind,3);bind(tendon);gl.drawArrays(gl.TRIANGLES,0,tendon.count)}
function rebuild(){let key=world.map(r=>r.join('')).join();if(key===worldKey)return;worldKey=key;data=[];for(let y=0;y<28;y++)for(let x=0;x<32;x++)if(world[y][x]){let h=y>=15&&x>=9&&x<=22?2.2:1.6,c=world[y][x]>1?[.34,.39,.34]:x>22?[.45,.49,.45]:x<9?[.39,.34,.28]:[.43,.38,.31];addCube(data,x+.5,h/2,y+.5,1,h,1,c,world[y][x]>1?2:1)}if(wallBuffer)gl.deleteBuffer(wallBuffer.b);wallBuffer=buffer(data)}
let setBuffer=null;
function scenery(){if(!setBuffer){let a=[];
for(let [x,z] of [[5,19],[27,19],[16,5]])for(let dz of [-3,0,3]){addCube(a,x,1.50,z+dz,7,.075,.11,[.22,.27,.24],2);for(let side of [-1,1]){addCube(a,x+side*3,.75,z+dz,.07,1.5,.10,[.24,.28,.25],2);addCube(a,x+side*3,.045,z+dz,.18,.09,.18,[.20,.22,.19],2)}}
for(let p of factoryProps.filter(p=>p.type==='crate')){addCube(a,p.x,.18,p.y,.46,.36,.40,[.44,.30,.16],8);for(let offset of [-.17,.17])addCube(a,p.x+offset,.18,p.y,.025,.38,.42,[.18,.22,.18],2);for(let h of [.07,.18,.29])addCube(a,p.x,h,p.y-.206,.43,.012,.012,[.19,.13,.08],8)}
for(let y of [.22,.42])addCube(a,10.15,y,23,.08,.07,4,[.30,.37,.34],2);
for(let x of [14.625,16.375])addCube(a,x,.80,16.2,.11,1.60,.11,[.30,.34,.29],2);addCube(a,15.5,1.59,16.2,1.86,.12,.13,[.38,.42,.34],2);
// Recessed floor drains and hazard-painted borders are flush with the floor.
for(let [x,z] of [[12.5,22],[19.5,18],[5,22],[27,22]]){addCube(a,x,.007,z,.55,.01,.30,[.08,.11,.10],2);for(let i=0;i<8;i++)addCube(a,x-.23+i*.065,.015,z,.022,.009,.28,[.23,.28,.26],2)}
for(let x=14.25;x<16.9;x+=.18)addCube(a,x,.005,15.82,.10,.008,.11,[.54,.43,.17],2);
setBuffer=buffer(a)}mesh(setBuffer,0,0,0,1,1,1,[1,1,1],-1);
for(let p of factoryProps.filter(p=>p.type==='barrel')){mesh(tendon,p.x,.26,p.y,.19,.26,.19,[.32,.35,.29],2);for(let h of [.12,.40])oval(p.x,h,p.y,.198,.012,.198,[.15,.19,.17],2);oval(p.x,.52,p.y,.16,.008,.16,[.25,.28,.23],2)}
}

function chest(s){block(s.x,.23,s.y,.96,.46,.56,[.43,.28,.15]);block(s.x,.49,s.y,.99,.065,.6,[.57,.39,.21]);for(let dx of [-.36,.36])block(s.x+dx,.26,s.y,.04,.5,.59,[.22,.25,.22]);block(s.x,.27,s.y-.294,.075,.09,.024,[.71,.61,.33]);if(boxTime>0||boxOffer)block(s.x,.47,s.y,.9,.025,.5,[.5,.85,.65],4)}
function zombie(z){oval(z.x,.009,z.y,.18,.004,.13,[.06,.075,.06],4);let heading=Math.atan2(player.y-z.y,player.x-z.x),c=Math.cos(heading),s=Math.sin(heading),phase=(z.walk||0)*1.05,walk=Math.sin(phase),skin=[[.43,.42,.36],[.51,.46,.39],[.39,.42,.40]][z.appearance||0],cloth=[[.20,.25,.23],[.28,.23,.19],[.22,.25,.28]][z.appearance||0];if(z.hit>0)skin=[.72,.32,.24];function P(side,h,front){return [z.x-side*s+front*c,h,z.y+side*c+front*s]}if(z.dog){let rot=Math.PI/2-heading,fur=[.135,.115,.10],bone=[.23,.18,.13],ember=[.85,.24,.035];
// Canine silhouette: long ribcage, narrow belly, angular muzzle, pointed ears and jointed legs.
limb(P(0,.34,-.27),P(0,.355,.15),.094,fur);
mesh(torso,...P(0,.351,.13),.084,.09,.072,fur,3,rot);
limb(P(0,.35,.17),P(0,.43,.25),.066,fur);
mesh(skull,...P(0,.44,.27),.058,.06,.084,bone,3,rot);
block(...P(0,.414,.36),.067,.046,.17,fur,3,rot);
mesh(sphere,...P(0,.385,.36),.038,.014,.09,[.07,.045,.035],3,rot);
mesh(sphere,...P(0,.424,.453),.027,.022,.018,[.035,.03,.025],3,rot);
for(let side of [-1,1]){mesh(ear,...P(side*.045,.49,.247),.032,.075,.042,fur,3,rot);oval(...P(side*.06,.45,.317),.008,.006,.008,ember,4);
for(let front of [-1,1]){let stride=Math.sin(phase*1.8+(side===front?0:Math.PI))*.045,hip=P(side*.08,.32,front*.16),joint=P(side*.085,.17,front*.17+stride),ankle=P(side*.085,.055,front*.17-stride);limb(hip,joint,.027,fur);limb(joint,ankle,.017,bone);mesh(sphere,...P(side*.085,.028,front*.17-stride+.022),.025,.020,.042,fur,3,rot)}
for(let tooth=0;tooth<3;tooth++)limb(P(side*.035,.394,.32+tooth*.028),P(side*.031,.38,.32+tooth*.028),.003,[.65,.57,.42]);
limb(P(side*.094,.37,.05),P(side*.084,.32,-.06),.003,[.38,.13,.05])}
limb(P(0,.36,-.25),P(0,.29,-.36),.026,fur);limb(P(0,.29,-.36),P(Math.sin(time*5+(z.phase||0))*.025,.34,-.47),.013,fur);
for(let i=0;i<4;i++)oval(...P(0,.427,-.15+i*.075),.014,.007,.020,[.45,.12,.025],4);return}

let lean=.055+Math.sin(time*1.7+(z.phase||0))*.012,rot=Math.PI/2-heading;
// Longer legs, a narrower waist, drooping shoulders and a connected forward neck.
mesh(torso,...P(0,.606,.018),.107,.158,.065,cloth,7,rot);
mesh(torso,...P(0,.449,0),.083,.04,.053,cloth,7,rot);
limb(P(0,.746,.025),P(0,.817,lean),.025,skin);
mesh(skull,...P(0,.878,lean+.021),.055,.068,.063,skin,3,rot);
// No spherical jaw or oversized eyeballs: small sockets sit inside the skull silhouette.
for(let side of [-1,1]){
let hip=P(side*.054,.437,0),knee=P(side*.065,.245,side*walk*.060),foot=P(side*.073,.048,-side*walk*.064);
limb(hip,knee,.034,[.20,.22,.20]);limb(knee,foot,.024,[.17,.19,.18]);
oval(...P(side*.073,.025,-side*walk*.064+.024),.032,.022,.057,[.105,.12,.11]);
let reach=Math.max(0,1-Math.hypot(player.x-z.x,player.y-z.y)/1.6),shoulder=P(side*.119,.724,.018),elbow=P(side*.145,.568+reach*.08,.075+side*walk*.022),hand=P(side*.132,.475+reach*.17,.14+reach*.075);
limb(shoulder,elbow,.029,cloth);limb(elbow,hand,.020,skin);oval(...hand,.022,.032,.017,skin);
for(let finger=0;finger<3;finger++){let q=hand.slice();q[0]+=(finger-1)*.009*(-s);q[2]+=(finger-1)*.009*c;limb(q,[q[0]+c*.013,q[1]-.037,q[2]+s*.013],.0038,skin)}
oval(...P(side*.023,.891,lean+.067),.014,.010,.004,[.055,.049,.043]);
limb(P(side*.012,.904,lean+.067),P(side*.035,.900,lean+.063),.005,[.25,.24,.20]);
oval(...P(side*.023,.890,lean+.071),.0038,.0028,.002,[.86,.46,.11],4);
oval(...P(side*.053,.892,lean+.009),.0045,.012,.008,skin);
// Ragged lapels and sunken cheek shadows add detail without inflating the face.
limb(P(side*.033,.755,.073),P(side*.047,.687,.079),.009,[.17,.20,.18]);
oval(...P(side*.035,.875,lean+.062),.012,.010,.003,[.36,.32,.28]);
}
limb(P(0,.901,lean+.069),P(0,.877,lean+.080),.007,skin);
let gape=.009+Math.max(0,Math.sin(time*2.3+(z.phase||0)))*.004;
oval(...P(0,.844,lean+.062),.020,gape,.004,[.065,.029,.021]);
limb(P(-.021,.840,lean+.06),P(-.017,.815,lean+.056),.004,[.28,.065,.047]);
for(let tooth=-1;tooth<=1;tooth++)oval(...P(tooth*.008,.850,lean+.068),.0025,.004,.002,[.60,.55,.43]);
for(let button=0;button<4;button++)oval(...P(0,.701-button*.051,.082),.0035,.004,.003,[.41,.38,.29]);
limb(P(-.088,.452,.008),P(.088,.452,.008),.008,[.13,.15,.13]);
oval(...P(.041,.593,.079),.018,.027,.004,[.24,.105,.085]);
// Three worn uniforms and asymmetrical injuries replace the green mannequin appearance.
oval(...P(-.026,.916,lean+.052),.020,.015,.004,[.24,.078,.053]);
limb(P(-.039,.923,lean+.045),P(-.013,.905,lean+.065),.003,[.36,.12,.08]);
limb(P(.034,.868,lean+.062),P(.044,.847,lean+.046),.004,[.22,.065,.047]);
for(let tear=0;tear<3;tear++)limb(P(-.078+tear*.015,.548,.070),P(-.085+tear*.013,.509,.065),.005,[.08,.10,.09]);
limb(P(.119,.641,.074),P(.13,.599,.090),.007,[.28,.078,.05]);
if(z.variant==='armored')block(...P(0,.61,.015),.205,.24,.145,[.28,.32,.3],2,rot)}

function draw(){if(lost)return false;if(surface.width!==W||surface.height!==H){surface.width=W;surface.height=H;}gl.viewport(0,0,W,H);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearColor(.105,.137,.15,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(program);gl.uniform3f(uniform.Eye,player.x,eyeHeight(),player.y);gl.uniform2f(uniform.Yaw,Math.cos(player.a),Math.sin(player.a));let f=1/Math.tan(viewFov()/2);gl.uniform3f(uniform.Projection,f,f*W/H,Math.tan(player.pitch||0));gl.uniform1f(uniform.Power,power?1:0);gl.uniform1f(uniform.Time,time);gl.uniform1f(uniform.Flash,flash>0?1:0);rebuild();oval(player.x,eyeHeight(),player.y,48,48,48,[1,1,1],6);block(16,-.04,14,32,.08,28,[.31,.34,.30],0);mesh(wallBuffer,0,0,0,1,1,1,[1,1,1],-1);
for(let roof of [[5,19,8,14],[27,19,8,14],[16,5.5,14,10]])block(roof[0],1.65,roof[1],roof[2],.07,roof[3],[.15,.21,.2],2);scenery();for(let f of wallFixtures){let o=f.object,nx=o.x+f.dx*.485,nz=o.y+f.dy*.485,rot=f.dx?Math.PI/2:0;if(f.kind==='window'){block(nx,.70,nz,.86,1.12,.025,[.07,.11,.105],2,rot);for(let side of [-1,1])block(nx+(f.dy?side*.46:0),.7,nz+(f.dx?side*.46:0),.055,1.2,.065,[.35,.31,.24],2,rot);for(let i=0;i<o.boards;i++)block(nx-f.dx*.03,.25+i*.17,nz-f.dy*.03,.88,.065,.07,[.48,.35,.21],2,rot)}else plaque(o.sprite,nx-f.dx*.03,f.bottom+f.height/2,nz-f.dy*.03,f.width,f.height,rot)}
for(let st of stations){if(st.mounted)continue;if(st.type==='box'){chest(st);continue}if(['tele','base'].includes(st.type)){oval(st.x,.075,st.y,.5,.08,.5,[.22,.34,.32],2);oval(st.x,.15,st.y,.38,.014,.38,[.24,.6,.58],4);continue}let rot=st.rotation||0,dx=st.wallDX||0,dy=st.wallDY||1;function front(depth,h){return [st.x-dx*depth,h,st.y-dy*depth]}block(st.x,.5,st.y,.43,1,.33,[.22,.29,.24],2,rot);block(...front(.18,.78),.34,.21,.04,st.type==='upgrade'?[.55,.38,.64]:[.5,.65,.42],power?4:2,rot);plaque(st.sprite,...front(.183,.54),.39,.87,rot);block(...front(.20,.25),.25,.16,.025,[.065,.10,.08],2,rot);for(let n=0;n<4;n++)block(...front(.18,.08+n*.035),.26,.009,.025,[.08,.13,.10],2,rot)}

if(trapTime>0)for(let y=12.3;y<15;y+=.4)limb([14.3,.5,y],[16.7,.65+Math.sin(time*20+y)*.2,y],.012,[.45,.8,1]);for(let z of zombies)if(!z.dead)zombie(z);for(let d of drops)oval(d.x,.12,d.y,.1,.1,.1,d.type==='ammo'?[.5,.65,.27]:[.7,.24,.18]);for(let g of grenades)oval(g.x,g.z,g.y,.045,.045,.045,[.38,.44,.28]);for(let l of factoryProps.filter(p=>p.type==='lamp')){block(l.x,.04,l.y,.16,.08,.16,[.19,.23,.20]);block(l.x,.64,l.y,.028,1.28,.028,[.20,.27,.24]);block(l.x,1.32,l.y,.21,.025,.18,[.25,.29,.25]);oval(l.x,1.28,l.y,.12,.03,.1,power?[.95,.77,.43]:[.35,.37,.29],power?4:2)}
return true}
return {draw,surface,dispose(){surface.remove()}};
}
